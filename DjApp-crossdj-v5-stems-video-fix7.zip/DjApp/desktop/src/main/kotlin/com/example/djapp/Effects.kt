package com.example.djapp

/** One effect of the effects rack (the signal processing is in the audio engine, FxSlot in engine.cpp). */
class FxDef(val id: Int, val name: String, val p1: String, val p2: String, val def1: Float, val def2: Float, val about: String)

object FxCatalog {
    /** Same numbers as the engine's FxType: 1..20. */
    val all: List<FxDef> = listOf(
        FxDef(1, "ECHO", "Wet", "Time", 0.5f, 0.4f, "Repeats that follow the tempo (1/8 to 2 beats)"),
        FxDef(2, "DUB ECHO", "Wet", "Time", 0.5f, 0.4f, "Echo whose repeats get darker each time"),
        FxDef(3, "PING-PONG", "Wet", "Time", 0.5f, 0.4f, "Echo that bounces left and right"),
        FxDef(4, "REVERB", "Wet", "Room", 0.5f, 0.6f, "Space and tail"),
        FxDef(5, "FLANGER", "Mix", "Rate", 0.6f, 0.4f, "Jet sweep"),
        FxDef(6, "CHORUS", "Mix", "Rate", 0.6f, 0.4f, "Thickens the sound"),
        FxDef(7, "PHASER", "Mix", "Rate", 0.7f, 0.4f, "Swirling notches"),
        FxDef(8, "TREMOLO", "Depth", "Rate", 0.9f, 0.5f, "Volume wobble in time with the beat"),
        FxDef(9, "AUTO-PAN", "Depth", "Rate", 1.0f, 0.5f, "Sound moves left and right in time"),
        FxDef(10, "WAH-WAH", "Mix", "Rate", 0.8f, 0.5f, "Band-pass sweep in time"),
        FxDef(11, "LP SWEEP", "Cutoff", "Resonance", 0.6f, 0.3f, "Low-pass filter sweep"),
        FxDef(12, "HP SWEEP", "Cutoff", "Resonance", 0.5f, 0.3f, "High-pass filter sweep"),
        FxDef(13, "BP SWEEP", "Centre", "Resonance", 0.5f, 0.5f, "Band-pass filter sweep"),
        FxDef(14, "BITCRUSHER", "Bits", "Rate crush", 0.6f, 0.3f, "Lo-fi digital crunch"),
        FxDef(15, "DISTORTION", "Drive", "Tone", 0.6f, 0.4f, "Overdrive"),
        FxDef(16, "GATER", "Depth", "Rate", 1.0f, 0.5f, "Chops the sound in time (trance gate)"),
        FxDef(17, "STUTTER", "Mix", "Length", 1.0f, 0.4f, "Repeats the last 1/16 to 1/2 beat while on"),
        FxDef(18, "RING MOD", "Mix", "Frequency", 0.6f, 0.4f, "Metallic robot tones"),
        FxDef(19, "BRAKE", "-", "Time", 0.5f, 0.3f, "Vinyl / tape stop: slows down to a halt"),
        FxDef(20, "BACKSPIN", "-", "Time", 0.5f, 0.5f, "Spins the sound backwards, then stops")
    )
    fun byId(id: Int): FxDef = all.firstOrNull { it.id == id } ?: all[0]
}
