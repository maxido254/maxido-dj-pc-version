package com.example.djapp

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toComposeImageBitmap
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.window.WindowPlacement
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import kotlinx.coroutines.delay
import java.awt.FileDialog
import java.awt.Frame
import java.io.File

private val Bg = Color(0xFF0B0D11)
private val Panel = Color(0xFF161A20)
private val Line = Color(0xFF2A303A)
private val TextGray = Color(0xFF8FA0BD)
private val DeckBlue = Color(0xFF2BA8E0)
private val DeckRed = Color(0xFFFF4D5E)
private val Accent = Color(0xFF39D98A)
private val DeckC = Color(0xFF9B7DFF)
private val DeckD = Color(0xFFFFB347)
private val Prepared = Color(0xFFC77DFF)       // tracks whose stems are prepared
private val Btn = Color(0xFF262B33)

private fun mmss(s: Float): String { val t = s.toInt().coerceAtLeast(0); return "%d:%02d".format(t / 60, t % 60) }

private fun pickFile(): File? {
    val d = FileDialog(null as Frame?, "Load a track", FileDialog.LOAD)
    d.setFilenameFilter { _, n -> n.substringAfterLast('.', "").lowercase().let { it in setOf("mp3", "wav", "flac", "ogg", "m4a", "aac", "mxs") || it in VIDEO_EXT } }
    d.isVisible = true
    return d.file?.let { File(d.directory, it) }
}

private fun pickVideo(): File? {
    val d = FileDialog(null as Frame?, "Load a video (picture only)", FileDialog.LOAD)
    d.setFilenameFilter { _, n -> n.substringAfterLast('.', "").lowercase() in VIDEO_EXT }
    d.isVisible = true
    return d.file?.let { File(d.directory, it) }
}

private val SAMPLE_EXT = setOf("mp3", "wav", "flac", "ogg", "m4a", "aac")

/** Choose one sample; the dialog opens in your samples folder. */
private fun pickSample(): File? {
    val d = FileDialog(null as Frame?, "Choose a sample", FileDialog.LOAD)
    d.directory = Sampler.samplesDir.absolutePath
    d.setFilenameFilter { _, n -> n.substringAfterLast('.', "").lowercase().let { it in SAMPLE_EXT || it in VIDEO_EXT } }
    d.isVisible = true
    return d.file?.let { File(d.directory, it) }
}

/** Choose several files at once to add to your samples. */
private fun pickFiles(): List<File>? {
    val d = FileDialog(null as Frame?, "Add your own samples (you can pick several)", FileDialog.LOAD)
    d.isMultipleMode = true
    d.setFilenameFilter { _, n -> n.substringAfterLast('.', "").lowercase().let { it in SAMPLE_EXT || it in VIDEO_EXT } }
    d.isVisible = true
    val files = d.files
    return if (files == null || files.isEmpty()) null else files.toList()
}

private fun pickFolder(): File? {
    val c = javax.swing.JFileChooser(File(System.getProperty("user.home")))
    c.fileSelectionMode = javax.swing.JFileChooser.DIRECTORIES_ONLY
    c.dialogTitle = "Add a music / video folder to the library"
    return if (c.showOpenDialog(null) == javax.swing.JFileChooser.APPROVE_OPTION) c.selectedFile else null
}

/** Double-click in the library: the first empty deck, otherwise the deck that is not playing. */
private fun loadAuto(t: LibTrack) {
    val order = listOf(Decks.a, Decks.b, Decks.c, Decks.d)
    val target = order.firstOrNull { it.dur <= 0f } ?: listOf(Decks.b, Decks.a, Decks.d, Decks.c).firstOrNull { !it.playing } ?: Decks.b
    target.load(t.file)
}

fun main() = application {
    val lib = remember { Native_.lib }
    val a = Decks.a
    val b = Decks.b
    var level by remember { mutableFloatStateOf(0f) }
    var recording by remember { mutableStateOf(false) }
    var engineOk by remember { mutableStateOf(true) }
    var videoOpen by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var outputOpen by remember { mutableStateOf(false) }
    var frame by remember { mutableStateOf<ImageBitmap?>(null) }
    var vidRec by remember { mutableStateOf(false) }
    var blend by remember { mutableIntStateOf(0) }
    var follow by remember { mutableStateOf(true) }
    var manualX by remember { mutableFloatStateOf(0.5f) }

    LaunchedEffect(Unit) {
        engineOk = lib.dj_start() == 1
        Mix.apply()
        Controls.start()
        Library.start()
        Sampler.start()
        // 25 updates a second is plenty for a playhead and a meter (it was 30); a paused deck does not redraw at all
        val prevReady = booleanArrayOf(false, false)
        val prevPlaying = booleanArrayOf(false, false)
        val prevFile = arrayOfNulls<String>(2)
        while (true) {
            a.poll(); b.poll(); Decks.c.poll(); Decks.d.poll(); Sampler.poll(); level = lib.dj_get_level()
            // the video window pops up by itself when a video is loaded or starts to play
            val decks = Decks.all()
            for (li in 0..1) {
                val ready = VideoMixer.layers[li].ready
                val owner = decks[VideoMixer.owner[li]]
                val playingNow = ready && owner.playing
                val file = if (ready) owner.loadedFile?.path else null
                // a video was loaded (also a different one), or a video deck started playing: show the video
                if (Prefs.autoVideo && ((ready && !prevReady[li]) || (playingNow && !prevPlaying[li]) || (file != null && file != prevFile[li]))) {
                    outputOpen = true          // only the picture, in its own window you can resize and move; the main screen stays as it is
                }
                prevReady[li] = ready; prevPlaying[li] = playingNow; prevFile[li] = file
            }
            delay(40)
        }
    }
    // the mixed picture, 30 times a second, only while something looks at it or records it
    LaunchedEffect(videoOpen, outputOpen, vidRec) {
        while (videoOpen || outputOpen || vidRec) {
            val bmp = withContext(Dispatchers.Default) { VideoMixer.compose()?.toComposeImageBitmap() }
            if (bmp != null) frame = bmp
            delay(33)
        }
    }

    if (outputOpen) OutputWindow(frame) { outputOpen = false }
    if (settingsOpen) SettingsWindow { settingsOpen = false }

    Window(
        onCloseRequest = { MixRecorder.stop(); lib.dj_stop_recording(); lib.dj_stop(); exitApplication() },
        title = "MAXIDO DJ - free for PC",
        state = rememberWindowState(placement = WindowPlacement.Maximized),
        onPreviewKeyEvent = { Controls.onKey(it) }
    ) {
        MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
            Column(Modifier.fillMaxSize().background(Bg)) {
                TopBar(level, recording, videoOpen, engineOk, { videoOpen = !videoOpen }, { settingsOpen = true }) {
                    if (recording) { lib.dj_stop_recording(); recording = false }
                    else {
                        val dir = File(System.getProperty("user.home"), "Music/MAXIDO DJ").apply { mkdirs() }
                        val f = File(dir, "mix-${System.currentTimeMillis() / 1000}.wav")
                        recording = lib.dj_start_recording(f.absolutePath) == 1
                    }
                }
                WaveStrip(a, "A", DeckBlue, 12f, Modifier.fillMaxWidth().height(42.dp))
                WaveStrip(b, "B", DeckRed, 12f, Modifier.fillMaxWidth().height(42.dp))
                Row(Modifier.fillMaxWidth().weight(0.58f).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    DeckPanel(a, b, "A", DeckBlue, Modifier.weight(1f))
                    MixerPanel(
                        a, b, Mix.cross, { Mix.applyCross(it) },
                        Mix.master, { Mix.applyMaster(it) },
                        Mix.bassAmp, { Mix.applyBassAmp(it) }
                    )
                    DeckPanel(b, a, "B", DeckRed, Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    MiniDeck(Decks.c, "C", DeckC, Modifier.weight(1f))
                    MiniDeck(Decks.d, "D", DeckD, Modifier.weight(1f))
                }
                if (videoOpen) VideoPanel(
                    frame, blend, { blend = it; VideoMixer.blend = it }, follow, { follow = it; VideoMixer.followCross = it },
                    manualX, { manualX = it; VideoMixer.manualCross = it }, outputOpen, { outputOpen = !outputOpen }, vidRec
                ) {
                    if (MixRecorder.recording) { MixRecorder.stop(); vidRec = false }
                    else {
                        val dir = File(System.getProperty("user.home"), "Videos/MAXIDO DJ").apply { mkdirs() }
                        MixRecorder.start(File(dir, "videomix-${System.currentTimeMillis() / 1000}.mp4"))
                        vidRec = MixRecorder.recording
                    }
                }
                LibraryPane(Modifier.fillMaxWidth().weight(0.42f).padding(4.dp))
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------ small building blocks

@Composable
private fun SmallBtn(
    text: String, modifier: Modifier = Modifier, active: Boolean = false, activeColor: Color = Accent,
    enabled: Boolean = true, onClick: () -> Unit
) {
    Button(
        onClick = onClick, enabled = enabled, modifier = modifier.height(30.dp),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp), shape = RoundedCornerShape(4.dp),
        colors = ButtonDefaults.buttonColors(containerColor = if (active) activeColor else Btn, disabledContainerColor = Color(0xFF14171C))
    ) {
        val fg = if (!enabled) TextGray else if (active && activeColor == Accent) Color.Black else Color.White
        Text(text, fontSize = 11.sp, color = fg, maxLines = 1)
    }
}

/** A round knob: drag up / down to turn, double-click to reset. */
@Composable
private fun Knob(label: String, value: Float, min: Float, max: Float, def: Float, color: Color, onChange: (Float) -> Unit) {
    val v by rememberUpdatedState(value)
    val cb by rememberUpdatedState(onChange)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier.size(34.dp)
                .pointerInput(Unit) { detectDragGestures { change, drag -> change.consume(); cb((v - drag.y / 140f * (max - min)).coerceIn(min, max)) } }
                .pointerInput(Unit) { detectTapGestures(onDoubleTap = { cb(def) }) }
        ) {
            val frac = ((value - min) / (max - min)).coerceIn(0f, 1f)
            val pad = 4f
            val arcSize = Size(size.width - 2 * pad, size.height - 2 * pad)
            drawArc(color = Color(0xFF2A303A), startAngle = 135f, sweepAngle = 270f, useCenter = false, topLeft = Offset(pad, pad), size = arcSize, style = Stroke(width = 4f))
            drawArc(color = color, startAngle = 135f, sweepAngle = 270f * frac, useCenter = false, topLeft = Offset(pad, pad), size = arcSize, style = Stroke(width = 4f))
            val ang = Math.toRadians(135.0 + 270.0 * frac)
            val r = size.minDimension / 2f
            drawLine(
                Color.White,
                Offset(center.x + (Math.cos(ang) * r * 0.25).toFloat(), center.y + (Math.sin(ang) * r * 0.25).toFloat()),
                Offset(center.x + (Math.cos(ang) * r * 0.7).toFloat(), center.y + (Math.sin(ang) * r * 0.7).toFloat()),
                strokeWidth = 3f
            )
        }
        Text(label, color = TextGray, fontSize = 9.sp, maxLines = 1)
    }
}

/** A vertical channel fader: drag or click. */
@Composable
private fun VFader(value: Float, color: Color, modifier: Modifier, onChange: (Float) -> Unit) {
    val cb by rememberUpdatedState(onChange)
    Canvas(
        modifier.width(34.dp)
            .pointerInput(Unit) { detectDragGestures { change, _ -> change.consume(); cb((1f - change.position.y / size.height).coerceIn(0f, 1f)) } }
            .pointerInput(Unit) { detectTapGestures { o -> cb((1f - o.y / size.height).coerceIn(0f, 1f)) } }
    ) {
        drawRect(Color(0xFF07090C), topLeft = Offset(size.width / 2f - 2f, 0f), size = Size(4f, size.height))
        val y = size.height * (1f - value.coerceIn(0f, 1f))
        drawRect(color, topLeft = Offset(3f, (y - 8f).coerceIn(0f, size.height - 16f)), size = Size(size.width - 6f, 16f))
    }
}

/** A slim horizontal slider (20 dp tall): drag or click. */
@Composable
private fun HSlider(value: Float, min: Float, max: Float, color: Color, modifier: Modifier = Modifier, onChange: (Float) -> Unit) {
    val cb by rememberUpdatedState(onChange)
    Canvas(
        modifier.fillMaxWidth().height(20.dp)
            .pointerInput(Unit) { detectDragGestures { change, _ -> change.consume(); cb(min + (change.position.x / size.width).coerceIn(0f, 1f) * (max - min)) } }
            .pointerInput(Unit) { detectTapGestures { o -> cb(min + (o.x / size.width).coerceIn(0f, 1f) * (max - min)) } }
    ) {
        val frac = ((value - min) / (max - min)).coerceIn(0f, 1f)
        val cy = size.height / 2f
        drawRect(Color(0xFF07090C), topLeft = Offset(0f, cy - 2f), size = Size(size.width, 4f))
        drawRect(color, topLeft = Offset(0f, cy - 2f), size = Size(size.width * frac, 4f))
        drawRect(Color.White, topLeft = Offset((size.width * frac - 4f).coerceIn(0f, size.width - 8f), 2f), size = Size(8f, size.height - 4f))
    }
}

// ------------------------------------------------------------------------------------------------ fit to size (no scrolling)

/**
 * Lays its content out at the size the content wants and then shrinks it evenly (it is never enlarged) until everything fits
 * into the space it is given, so every control stays visible and clickable without scrolling.
 */
@Composable
private fun FitScale(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Layout(content = content, modifier = modifier.clipToBounds()) { measurables, constraints ->
        val w = if (constraints.hasBoundedWidth) constraints.maxWidth else 800
        val h = if (constraints.hasBoundedHeight) constraints.maxHeight else 600
        val m = measurables.firstOrNull()
        if (m == null) return@Layout layout(w, h) {}
        // too narrow for the content? then it is laid out wider and scaled down by the same factor
        val needW = try { m.minIntrinsicWidth(10000) } catch (_: Throwable) { 0 }
        val sw = if (needW > w) w.toFloat() / needW else 1f
        var s = sw
        var p = m.measure(Constraints(maxWidth = maxOf(1, (w / s).toInt()), maxHeight = Constraints.Infinity))
        for (i in 0 until 4) {
            val ns = minOf(sw, if (p.height > 0) h.toFloat() / p.height else 1f).coerceAtMost(1f)
            if (kotlin.math.abs(ns - s) < 0.004f) break
            s = ns
            p = m.measure(Constraints(maxWidth = maxOf(1, (w / s).toInt()), maxHeight = Constraints.Infinity))
        }
        val scale = s
        layout(w, h) { p.placeRelativeWithLayer(0, 0) { scaleX = scale; scaleY = scale; transformOrigin = TransformOrigin(0f, 0f) } }
    }
}

// ------------------------------------------------------------------------------------------------ top bar

@Composable
private fun TopBar(level: Float, recording: Boolean, videoOpen: Boolean, engineOk: Boolean, onVideo: () -> Unit, onSettings: () -> Unit, onRec: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(42.dp).background(Panel).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("MAXIDO DJ", color = Accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        if (!engineOk) Text("No audio output device found. Plug in speakers or headphones and restart.", color = DeckRed, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        Text("STEMS", color = TextGray, fontSize = 10.sp)
        SmallBtn("ECO", active = Decks.power == 0) { Decks.power = 0 }
        SmallBtn("BAL", active = Decks.power == 1) { Decks.power = 1 }
        SmallBtn("FAST", active = Decks.power == 2, activeColor = DeckRed) { Decks.power = 2 }
        Switch(Decks.autoStems, { Decks.autoStems = it })
        Text("AUTO STEMS", color = TextGray, fontSize = 10.sp)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.width(150.dp)) { Meter(level) }
        SmallBtn("VIDEO", active = videoOpen, onClick = onVideo)
        SmallBtn("SETTINGS", onClick = onSettings)
        SmallBtn(if (recording) "STOP REC" else "REC", active = recording, activeColor = DeckRed, onClick = onRec)
    }
}

// ------------------------------------------------------------------------------------------------ waveform strip

@Composable
private fun WaveStrip(d: DeckModel, label: String, color: Color, zoomSec: Float, modifier: Modifier = Modifier) {
    // zoomSec > 0: a scrolling close-up that keeps the playhead in the middle; zoomSec = 0: the whole track, click to jump.
    Box(modifier.background(Color(0xFF07090C)).padding(vertical = 1.dp)) {
        Canvas(
            Modifier.fillMaxSize().pointerInput(d, zoomSec) {
                detectTapGestures { o ->
                    if (d.dur > 0f) {
                        val target = if (zoomSec > 0f) d.pos + (o.x / size.width - 0.5f) * zoomSec else o.x / size.width * d.dur
                        d.seekTo(target.coerceIn(0f, d.dur))
                    }
                }
            }
        ) {
            val w = size.width
            val h = size.height
            val mid = h / 2f
            val pk = d.peaks
            if (pk != null && pk.isNotEmpty() && d.dur > 0f) {
                val n = pk.size
                val dim = color.copy(alpha = 0.40f)
                val cols = w.toInt().coerceAtLeast(1)
                var x = 0
                if (zoomSec > 0f) {
                    while (x < cols) {
                        val tt = d.pos + (x.toFloat() / cols - 0.5f) * zoomSec
                        if (tt >= 0f && tt < d.dur) {
                            val v = pk[(tt / d.dur * n).toInt().coerceIn(0, n - 1)]
                            val amp = (v * mid).coerceAtLeast(1f)
                            drawLine(if (x * 2 < cols) dim else color, Offset(x.toFloat(), mid - amp), Offset(x.toFloat(), mid + amp), strokeWidth = 2f)
                        }
                        x += 2
                    }
                    drawLine(Color.White, Offset(w / 2f, 0f), Offset(w / 2f, h), strokeWidth = 2f)
                } else {
                    val played = (d.pos / d.dur).coerceIn(0f, 1f)
                    while (x < cols) {
                        val v = pk[(x.toFloat() / cols * n).toInt().coerceIn(0, n - 1)]
                        val amp = (v * mid).coerceAtLeast(1f)
                        drawLine(if (x.toFloat() / w < played) dim else color, Offset(x.toFloat(), mid - amp), Offset(x.toFloat(), mid + amp), strokeWidth = 2f)
                        x += 2
                    }
                    val px = played * w
                    drawLine(Color.White, Offset(px, 0f), Offset(px, h), strokeWidth = 2f)
                }
            } else {
                drawLine(Line, Offset(0f, mid), Offset(w, mid), strokeWidth = 1f)
            }
        }
        if (label.isNotEmpty()) Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp, top = 2.dp).align(Alignment.TopStart))
    }
}

// ------------------------------------------------------------------------------------------------ deck

@Composable
private fun DeckPanel(d: DeckModel, other: DeckModel, label: String, color: Color, modifier: Modifier) {
    var tab by remember { mutableIntStateOf(0) }
    Box(modifier.fillMaxHeight().background(Panel, RoundedCornerShape(6.dp)).border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(6.dp)).padding(8.dp)) {
    FitScale(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            // jog wheel: turns while the track plays, click it to play / pause
            Canvas(Modifier.size(112.dp).pointerInput(d) { detectTapGestures { if (d.dur > 0f) d.togglePlay() } }) {
                val c = center
                val r = size.minDimension / 2f
                drawCircle(Color(0xFF0C0E12), r, c)
                drawCircle(Color(0xFF1B2027), r * 0.66f, c)
                if (d.dur > 0f) {
                    val frac = (d.pos / d.dur).coerceIn(0f, 1f)
                    drawArc(color = color, startAngle = -90f, sweepAngle = 360f * frac, useCenter = false, topLeft = Offset(4f, 4f), size = Size(size.width - 8f, size.height - 8f), style = Stroke(width = 5f))
                }
                val ang = Math.toRadians(d.pos * 200.0 - 90.0)
                drawLine(
                    Color.White,
                    Offset(c.x + (Math.cos(ang) * r * 0.30).toFloat(), c.y + (Math.sin(ang) * r * 0.30).toFloat()),
                    Offset(c.x + (Math.cos(ang) * r * 0.62).toFloat(), c.y + (Math.sin(ang) * r * 0.62).toFloat()),
                    strokeWidth = 4f
                )
                drawCircle(if (d.playing) color else Color(0xFF2A303A), r * 0.10f, c)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(24.dp).background(color, RoundedCornerShape(4.dp)), contentAlignment = Alignment.Center) { Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
                    Spacer(Modifier.width(8.dp))
                    Text(d.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (d.liveBpm > 0f) "%.1f".format(d.liveBpm) else "--", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    Text("BPM", color = TextGray, fontSize = 10.sp)
                    Text(if (d.key.isNotEmpty()) d.key else "--", color = Accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("KEY", color = TextGray, fontSize = 10.sp)
                }
                Text(
                    if (d.status.isNotEmpty()) d.status else "${mmss(d.pos)}  /  -${mmss(d.dur - d.pos)}",
                    color = TextGray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SmallBtn("LOAD", active = true, activeColor = color) { pickFile()?.let { d.load(it) } }
                    SmallBtn("CUE", enabled = d.dur > 0f) { d.cuePress() }
                    SmallBtn(if (d.playing) "PAUSE" else "PLAY", active = d.playing, activeColor = color, enabled = d.dur > 0f) { d.togglePlay() }
                    SmallBtn("SYNC", active = d.synced, enabled = d.bpm > 0f && other.bpm > 0f) { if (d.synced) d.setTempo(d.tempoPct) else d.syncTo(other) }
                }
                Labeled("TEMPO  ${"%+.1f".format(d.tempoPct * 100)}%") {
                    HSlider(d.tempoPct, -0.08f, 0.08f, color) { d.setTempo(if (kotlin.math.abs(it) < 0.002f) 0f else it) }
                }
            }
        }
        WaveStrip(d, "", color, 0f, Modifier.fillMaxWidth().height(34.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            SmallBtn("LOOPS + STEMS", modifier = Modifier.weight(1f), active = tab == 0, activeColor = color) { tab = 0 }
            SmallBtn("EFFECTS", modifier = Modifier.weight(1f), active = tab == 1, activeColor = color) { tab = 1 }
        }
        if (tab == 1) RackPanel(d, color) else {
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            SmallBtn("IN", enabled = d.dur > 0f) { d.loopIn() }
            SmallBtn("OUT", enabled = d.dur > 0f) { d.loopOut() }
            SmallBtn("<", modifier = Modifier.width(34.dp), enabled = d.dur > 0f) { d.changeLoopBeats(d.loopBeats / 2) }
            Text("${d.loopBeats}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.width(26.dp))
            SmallBtn(">", modifier = Modifier.width(34.dp), enabled = d.dur > 0f) { d.changeLoopBeats(d.loopBeats * 2) }
            SmallBtn("LOOP", active = d.loopOn, activeColor = color, enabled = d.dur > 0f) { d.toggleLoop() }
            Spacer(Modifier.weight(1f))
            SmallBtn("KEYLOCK", active = d.keylock) { d.toggleKeylock() }
        }
        // ---- stems (VOCAL / MELODY / BASS / DRUMS like the pro layouts)
        val stemOrder = intArrayOf(0, 3, 2, 1)
        val stemName = arrayOf("VOCAL", "DRUMS", "BASS", "MELODY")
        val stemColor = arrayOf(Color(0xFFD7263D), Color(0xFFE8A33D), Color(0xFFB5179E), Color(0xFF2BB673))
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            for (i in stemOrder) {
                SmallBtn(stemName[i], modifier = Modifier.weight(1f), active = d.stemsReady && d.stemOn[i], activeColor = stemColor[i], enabled = d.stemsReady) { d.toggleStem(i) }
            }
        }
        if (d.stemsReady) Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            SmallBtn("ACAPELLA", modifier = Modifier.weight(1f)) { d.stemPreset(true, false, false, false) }
            SmallBtn("NO VOCALS", modifier = Modifier.weight(1f)) { d.stemPreset(false, true, true, true) }
            SmallBtn("BEATLESS", modifier = Modifier.weight(1f)) { d.stemPreset(true, false, true, true) }
            SmallBtn("ALL", modifier = Modifier.weight(1f)) { d.stemPreset(true, true, true, true) }
        } else if (d.preparing) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LinearProgressIndicator(progress = { d.stemProgress }, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(8.dp)); Text("stems ${(d.stemProgress * 100).toInt()}%", color = TextGray, fontSize = 11.sp)
            }
        } else if (d.dur > 0f) SmallBtn("PREPARE STEMS", modifier = Modifier.fillMaxWidth()) { d.prepareStems() }
        val fxName = arrayOf("VOC ECHO", "VOC REVERB", "INST ECHO", "INST REVERB")
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            for (k in 0..3) SmallBtn(fxName[k], modifier = Modifier.weight(1f), active = d.fx[k], activeColor = Color(0xFFB04DFF), enabled = d.stemsReady) { d.toggleFx(k) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            SmallBtn("VIDEO + SOUND") { pickVideo()?.let { d.load(it) } }
            SmallBtn("SILENT LOOP") { pickVideo()?.let { VideoMixer.layers[d.id].load(it, false); VideoMixer.owner[d.id] = d.id } }
            SmallBtn("X") { VideoMixer.layers[d.id].clear() }
        }
        }
    }
    }
    }
}

// ------------------------------------------------------------------------------------------------ mixer

@Composable
private fun MixerPanel(
    a: DeckModel, b: DeckModel, cross: Float, onCross: (Float) -> Unit, master: Float, onMaster: (Float) -> Unit,
    bassAmp: Float, onBassAmp: (Float) -> Unit
) {
    fun dead(v: Float) = if (kotlin.math.abs(v) < 0.6f) 0f else v
    @Composable
    fun Channel(d: DeckModel, color: Color) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Knob("TREBLE", d.treble, -26f, 12f, 0f, color) { d.applyTreble(dead(it)) }
            Knob("MID", d.mid, -26f, 12f, 0f, color) { d.applyMid(dead(it)) }
            Knob("BASS", d.bass, -26f, 12f, 0f, color) { d.applyBass(dead(it)) }
            Knob("FILTER", d.filter, -1f, 1f, 0f, color) { d.applyFilter(it) }
        }
    }
    Box(Modifier.width(290.dp).fillMaxHeight().background(Panel, RoundedCornerShape(6.dp)).border(1.dp, Line, RoundedCornerShape(6.dp)).padding(8.dp)) {
    FitScale(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth().height(190.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Channel(a, DeckBlue)
            VFader(a.volume, DeckBlue, Modifier.fillMaxHeight()) { a.applyVolume(it) }
            VFader(b.volume, DeckRed, Modifier.fillMaxHeight()) { b.applyVolume(it) }
            Channel(b, DeckRed)
        }
        Labeled("MASTER  ${(master * 100).toInt()}%") { HSlider(master, 0.25f, 1.25f, Accent, onChange = onMaster) }
        Labeled("BASS AMP  ${(bassAmp * 100).toInt()}%") { HSlider(bassAmp, 0f, 1f, Accent, onChange = onBassAmp) }
        Labeled("CROSSFADER") { HSlider(cross, 0f, 1f, Accent, onChange = onCross) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("A", color = DeckBlue); Text("B", color = DeckRed) }
    }
    }
    }
}

// ------------------------------------------------------------------------------------------------ library

@Composable
private fun LibraryPane(modifier: Modifier) {
    var query by remember { mutableStateOf("") }
    var sortCol by remember { mutableIntStateOf(0) }
    var asc by remember { mutableStateOf(true) }
    var folder by remember { mutableStateOf<File?>(null) }
    var stemsOnly by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<LibTrack?>(null) }

    val list by remember {
        derivedStateOf {
            var l: List<LibTrack> = Library.tracks.toList()
            val f = folder
            if (f != null) l = l.filter { it.file.path.startsWith(f.path) }
            if (stemsOnly) l = l.filter { it.stems }
            val q = query.trim().lowercase()
            if (q.isNotEmpty()) l = l.filter { (it.title + " " + it.artist).lowercase().contains(q) }
            val cmp: Comparator<LibTrack> = when (sortCol) {
                0 -> compareBy<LibTrack> { it.title.lowercase() }
                1 -> compareBy<LibTrack> { it.artist.lowercase() }
                2 -> compareBy<LibTrack> { it.dur }
                3 -> compareBy<LibTrack> { it.bpm }
                else -> compareBy<LibTrack> { it.key }
            }
            l.sortedWith(if (asc) cmp else cmp.reversed())
        }
    }

    fun sortBy(c: Int) { if (sortCol == c) asc = !asc else { sortCol = c; asc = true } }

    Row(modifier, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        // ---- folders
        Column(Modifier.width(190.dp).fillMaxHeight().background(Panel, RoundedCornerShape(6.dp)).padding(6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("FOLDERS", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(
                "All files (${Library.tracks.size})", color = if (folder == null && !stemsOnly) Accent else Color.White, fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().clickable { folder = null; stemsOnly = false }.padding(vertical = 3.dp)
            )
            Text(
                "Stems", color = if (stemsOnly) Accent else Color.White, fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().clickable { stemsOnly = true; folder = null }.padding(vertical = 3.dp)
            )
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                for (f in Library.folders.toList()) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            (if (f.absolutePath == Sampler.samplesDir.absolutePath) "My Samples" else f.name.ifEmpty { f.path }), color = if (folder?.path == f.path && !stemsOnly) Accent else Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f).clickable { folder = f; stemsOnly = false }.padding(vertical = 3.dp)
                        )
                        Text("x", color = TextGray, fontSize = 12.sp, modifier = Modifier.clickable { if (folder?.path == f.path) folder = null; Library.removeFolder(f) }.padding(horizontal = 6.dp))
                    }
                }
            }
            SmallBtn("+ ADD FOLDER", modifier = Modifier.fillMaxWidth()) { pickFolder()?.let { Library.addFolder(it) } }
        }
        // ---- table
        Column(Modifier.weight(1f).fillMaxHeight().background(Panel, RoundedCornerShape(6.dp)).padding(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BasicTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 13.sp), cursorBrush = SolidColor(Accent),
                    modifier = Modifier.weight(1f).height(28.dp).background(Color(0xFF0A0C10), RoundedCornerShape(4.dp)).padding(horizontal = 8.dp, vertical = 5.dp)
                        .onFocusChanged { Controls.typing = it.isFocused },
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (query.isEmpty()) Text("Search title or artist...", color = TextGray, fontSize = 13.sp)
                            inner()
                        }
                    }
                )
                Text("${list.size} files", color = TextGray, fontSize = 11.sp)
                Text("purple = stems prepared", color = Prepared, fontSize = 11.sp)
                SmallBtn("RESCAN", enabled = !Library.scanning) { Library.scan() }
            }
            Row(Modifier.fillMaxWidth().background(Color(0xFF1D222A)).padding(horizontal = 6.dp, vertical = 3.dp)) {
                val names = listOf("Title", "Artist", "Length", "BPM", "Key")
                val weights = listOf(4f, 3f, 1f, 0.9f, 0.8f)
                for (i in names.indices) {
                    val arrow = if (sortCol == i) (if (asc) " ▲" else " ▼") else ""
                    Text(names[i] + arrow, color = if (sortCol == i) Accent else TextGray, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                        modifier = Modifier.weight(weights[i]).clickable { sortBy(i) })
                }
                Spacer(Modifier.width(146.dp))
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.file.path }) { t ->
                    val isSel = selected === t
                    Row(
                        Modifier.fillMaxWidth().height(24.dp).background(if (isSel) Color(0xFF2A3342) else Color.Transparent)
                            .pointerInput(t) { detectTapGestures(onTap = { selected = t }, onDoubleTap = { selected = t; loadAuto(t) }) }
                            .padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val onA = Decks.a.loadedFile == t.file
                        val onB = Decks.b.loadedFile == t.file
                        val onC = Decks.c.loadedFile == t.file
                        val onD = Decks.d.loadedFile == t.file
                        val col = if (onA) DeckBlue else if (onB) DeckRed else if (onC) DeckC else if (onD) DeckD else if (t.stems) Prepared else Color.White
                        Text(t.title, color = col, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(4f))
                        Text(t.artist, color = if (onA || onB || onC || onD) col else if (t.stems) Prepared.copy(alpha = 0.75f) else TextGray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(3f))
                        Text(if (t.dur > 0.5f) mmss(t.dur) else "", color = TextGray, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text(if (t.bpm > 0f) "%.1f".format(t.bpm) else "", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(0.9f))
                        Text(t.key, color = Accent, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                        Text("A", color = DeckBlue, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.clickable { Decks.a.load(t.file) }.padding(horizontal = 10.dp))
                        Text("B", color = DeckRed, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.clickable { Decks.b.load(t.file) }.padding(horizontal = 10.dp))
                        Text("C", color = DeckC, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.clickable { Decks.c.load(t.file) }.padding(horizontal = 10.dp))
                        Text("D", color = DeckD, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.clickable { Decks.d.load(t.file) }.padding(horizontal = 10.dp))
                        Text("S", color = Accent, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.clickable { Sampler.assignNext(t.file) }.padding(horizontal = 10.dp))
                    }
                }
            }
        }
        // ---- info
        Box(Modifier.width(300.dp).fillMaxHeight().background(Panel, RoundedCornerShape(6.dp)).padding(8.dp)) {
        FitScale(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            SamplerPanel()
            val s = selected
            Text(
                if (s != null) s.title + (if (s.artist.isNotEmpty()) "  -  " + s.artist else "") else "Click a track. Double-click loads it on a free deck.",
                color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (s != null) Text(
                buildString {
                    if (s.bpm > 0f) append("%.1f BPM".format(s.bpm))
                    if (s.key.isNotEmpty()) append("    KEY ${s.key}")
                    if (s.dur > 0.5f) append("    ${mmss(s.dur)}")
                }.ifEmpty { "Not analysed yet" },
                color = TextGray, fontSize = 11.sp, maxLines = 1
            )
            if (s != null && s.stems) SmallBtn("STEMS PREPARED (purple). DELETE THEM", modifier = Modifier.fillMaxWidth()) { Library.deleteStems(s) }
            if (Library.analyzing) {
                LinearProgressIndicator(progress = { if (Library.analyzeTotal > 0) Library.analyzeDone.toFloat() / Library.analyzeTotal else 0f }, modifier = Modifier.fillMaxWidth())
                SmallBtn("STOP ANALYSING ${Library.analyzeDone} / ${Library.analyzeTotal}", modifier = Modifier.fillMaxWidth(), active = true, activeColor = DeckRed) { Library.stopAnalyzing() }
            } else {
                SmallBtn(if (Library.scanning) "SCANNING FOLDERS..." else "ANALYZE ALL (BPM + KEY)", modifier = Modifier.fillMaxWidth(), enabled = !Library.scanning) { Library.analyzeAll() }
            }
        }
        }
        }
    }
}

/** A second window that shows only the mixed picture: drag it to the projector / TV, double-click for full screen. */
@Composable
private fun OutputWindow(frame: ImageBitmap?, onClose: () -> Unit) {
    val st = rememberWindowState(width = 800.dp, height = 450.dp)
    Window(onCloseRequest = onClose, title = "MAXIDO DJ - video (resize it, double-click for full screen)", state = st, resizable = true, onPreviewKeyEvent = { Controls.onKey(it) }) {
        Box(
            Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) {
                detectTapGestures(onDoubleTap = { st.placement = if (st.placement == WindowPlacement.Fullscreen) WindowPlacement.Floating else WindowPlacement.Fullscreen })
            }
        ) { if (frame != null) Image(frame, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
    }
}

@Composable
private fun VideoPanel(
    frame: ImageBitmap?, blend: Int, onBlend: (Int) -> Unit, follow: Boolean, onFollow: (Boolean) -> Unit,
    manualX: Float, onManual: (Float) -> Unit, outputOpen: Boolean, onOutput: () -> Unit, recording: Boolean, onRec: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().height(250.dp).background(Panel, RoundedCornerShape(10.dp)).border(1.dp, Line, RoundedCornerShape(10.dp)).padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(Modifier.aspectRatio(16f / 9f).fillMaxHeight().background(Color.Black)) {
            if (frame != null) Image(frame, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            else Text("Load a video on a deck", color = TextGray, modifier = Modifier.align(Alignment.Center), fontSize = 12.sp)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("VIDEO MIXER", color = Accent, fontWeight = FontWeight.Bold)
            Text("On each deck: VIDEO + SOUND plays a video file as the track (picture locked to the deck: play, cue, scratch, tempo). SILENT LOOP adds a picture-only clip.", color = TextGray, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("BLEND", "DIP TO BLACK", "CUT").forEachIndexed { i, t ->
                    Button(onClick = { onBlend(i) }, colors = ButtonDefaults.buttonColors(containerColor = if (blend == i) Accent else Color(0xFF1D222C))) { Text(t, color = if (blend == i) Color.Black else Color.White, fontSize = 11.sp) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { onFollow(true) }, colors = ButtonDefaults.buttonColors(containerColor = if (follow) Accent else Color(0xFF1D222C))) { Text("XFADER", color = if (follow) Color.Black else Color.White, fontSize = 11.sp) }
                Button(onClick = { onFollow(false) }, colors = ButtonDefaults.buttonColors(containerColor = if (!follow) Accent else Color(0xFF1D222C))) { Text("MANUAL", color = if (!follow) Color.Black else Color.White, fontSize = 11.sp) }
                if (!follow) Slider(manualX, onManual, modifier = Modifier.width(180.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onOutput, colors = ButtonDefaults.buttonColors(containerColor = if (outputOpen) Accent else Color(0xFF1D222C))) { Text("OUTPUT WINDOW", color = if (outputOpen) Color.Black else Color.White, fontSize = 11.sp) }
                Button(onClick = onRec, colors = ButtonDefaults.buttonColors(containerColor = if (recording) DeckRed else Color(0xFF1D222C))) { Text(if (recording) "STOP VIDEO REC" else "REC VIDEO MIX", color = Color.White, fontSize = 11.sp) }
            }
            Text(
                if (MixRecorder.info.isNotEmpty()) MixRecorder.info else "REC VIDEO MIX saves picture + master sound (bass amp included) as MP4 in Videos\\MAXIDO DJ. Double-click the output window for full screen.",
                color = TextGray, fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun Meter(level: Float) {
    Canvas(Modifier.fillMaxWidth().height(14.dp)) {
        drawRect(Color(0xFF131720), size = size)
        val w = size.width * level.coerceIn(0f, 1f)
        drawRect(if (level > 0.93f) DeckRed else Accent, size = Size(w, size.height))
    }
}

@Composable
private fun Labeled(label: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth()) { Text(label, color = TextGray, fontSize = 11.sp); content() }
}


// ------------------------------------------------------------------------------------------------ decks C and D, sampler

/** A compact deck for C and D (audio only): load, cue, play, sync, a progress bar you can click, and a volume slider. */
@Composable
private fun MiniDeck(d: DeckModel, label: String, color: Color, modifier: Modifier) {
    Row(
        modifier.height(56.dp).background(Panel, RoundedCornerShape(6.dp)).border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(Modifier.size(24.dp).background(color, RoundedCornerShape(4.dp)), contentAlignment = Alignment.Center) { Text(label, color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                if (d.status.isNotEmpty()) d.status else d.title + (if (d.liveBpm > 0f) "   %.1f BPM".format(d.liveBpm) else "") + (if (d.key.isNotEmpty()) "   ${d.key}" else ""),
                color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Canvas(Modifier.fillMaxWidth().height(10.dp).pointerInput(d) { detectTapGestures { o -> if (d.dur > 0f) d.seekTo(o.x / size.width * d.dur) } }) {
                drawRect(Color(0xFF0A0C10), size = size)
                if (d.dur > 0f) drawRect(color, size = Size(size.width * (d.pos / d.dur).coerceIn(0f, 1f), size.height))
            }
        }
        SmallBtn("LOAD", active = true, activeColor = color) { pickFile()?.let { d.load(it) } }
        SmallBtn("CUE", enabled = d.dur > 0f) { d.cuePress() }
        SmallBtn(if (d.playing) "PAUSE" else "PLAY", active = d.playing, activeColor = color, enabled = d.dur > 0f) { d.togglePlay() }
        SmallBtn("SYNC", active = d.synced, enabled = d.bpm > 0f) {
            if (d.synced) d.setTempo(d.tempoPct)
            else (Decks.all().firstOrNull { it !== d && it.playing && it.bpm > 0f } ?: Decks.all().firstOrNull { it !== d && it.bpm > 0f })?.let { d.syncTo(it) }
        }
        HSlider(d.volume, 0f, 1f, color, Modifier.width(90.dp)) { d.applyVolume(it) }
    }
}

@Composable
private fun Pad(name: String, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val bg = if (on) Accent else if (name.isEmpty()) Color(0xFF1A1E24) else Color(0xFF20362B)
    Box(modifier.height(34.dp).background(bg, RoundedCornerShape(4.dp)).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Text(
            if (name.isEmpty()) "+" else name,
            color = if (on) Color.Black else if (name.isEmpty()) TextGray else Color.White,
            fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 3.dp)
        )
    }
}

@Composable
private fun SamplerPanel() {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("SAMPLER", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            for (i in 0..3) SmallBtn("${i + 1}", modifier = Modifier.width(30.dp), active = Sampler.bank == i) { Sampler.bank = i }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            SmallBtn("PLAY", modifier = Modifier.weight(1f), active = Sampler.mode == 0) { Sampler.mode = 0 }
            SmallBtn("LOAD", modifier = Modifier.weight(1f), active = Sampler.mode == 1) { Sampler.mode = 1 }
            SmallBtn("CLEAR", modifier = Modifier.weight(1f), active = Sampler.mode == 2, activeColor = DeckRed) { Sampler.mode = 2 }
            SmallBtn("LOOP", modifier = Modifier.weight(1f), active = Sampler.loop) { Sampler.loop = !Sampler.loop }
        }
        SmallBtn("+ ADD MY SAMPLES (copies the files in)", modifier = Modifier.fillMaxWidth()) { pickFiles()?.let { Sampler.importFiles(it) } }
        for (row in 0..1) {
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                for (col in 0..3) {
                    val slot = Sampler.bank * 8 + row * 4 + col
                    Pad(Sampler.names[slot], Sampler.active[slot], Modifier.weight(1f)) {
                        when (Sampler.mode) {
                            0 -> if (Sampler.names[slot].isEmpty()) { pickSample()?.let { Sampler.assign(slot, it) } } else Sampler.press(slot)
                            1 -> pickSample()?.let { Sampler.assign(slot, it) }
                            else -> Sampler.clear(slot)
                        }
                    }
                }
            }
        }
        Labeled("SAMPLER VOLUME") { HSlider(Sampler.volume, 0f, 1f, Accent) { Sampler.applyVolume(it) } }
    }
}

// ------------------------------------------------------------------------------------------------ settings

private object Prefs {
    var curve by mutableIntStateOf(0)            // crossfader curve: 0 smooth, 1 sharp cut, 2 linear
    var autoVideo by mutableStateOf(true)        // pop up the video window when a video is loaded / played
}

private fun dirBytes(dir: File): Long = try { dir.walkTopDown().filter { it.isFile }.sumOf { it.length() } } catch (_: Throwable) { 0L }
private fun mb(bytes: Long): String = "%.0f MB".format(bytes / 1048576.0)

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(8.dp)).border(1.dp, Line, RoundedCornerShape(8.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        content()
    }
}

@Composable
private fun SettingsWindow(onClose: () -> Unit) {
    Window(
        onCloseRequest = onClose, title = "MAXIDO DJ - settings", state = rememberWindowState(width = 700.dp, height = 800.dp),
        onPreviewKeyEvent = { Controls.onKey(it) }
    ) {
        MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
            var cacheBytes by remember { mutableLongStateOf(dirBytes(TrackCache.dir)) }
            var freed by remember { mutableStateOf("") }
            Column(
                Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Settings", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)

                SettingsSection("PERFORMANCE AND HEAT") {
                    Text("Splitting a song into vocal / drums / bass / melody with the AI model is the heaviest job. ECO keeps the laptop cool and quiet but takes longer.", color = TextGray, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SmallBtn("ECO (2 threads, rests)", modifier = Modifier.weight(1f), active = Decks.power == 0) { Decks.power = 0 }
                        SmallBtn("BALANCED", modifier = Modifier.weight(1f), active = Decks.power == 1) { Decks.power = 1 }
                        SmallBtn("FAST (up to 8 threads)", modifier = Modifier.weight(1f), active = Decks.power == 2, activeColor = DeckRed) { Decks.power = 2 }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(Decks.autoStems, { Decks.autoStems = it })
                        Spacer(Modifier.width(8.dp))
                        Text("Prepare stems automatically when a track is loaded (uses the CPU for every track)", color = Color.White, fontSize = 12.sp)
                    }
                }

                SettingsSection("MIXER") {
                    Text("Crossfader curve", color = TextGray, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SmallBtn("SMOOTH", modifier = Modifier.weight(1f), active = Prefs.curve == 0) { Prefs.curve = 0; Native_.lib.dj_set_crossfader_curve(0) }
                        SmallBtn("SHARP CUT", modifier = Modifier.weight(1f), active = Prefs.curve == 1) { Prefs.curve = 1; Native_.lib.dj_set_crossfader_curve(1) }
                        SmallBtn("LINEAR", modifier = Modifier.weight(1f), active = Prefs.curve == 2) { Prefs.curve = 2; Native_.lib.dj_set_crossfader_curve(2) }
                    }
                    Text("A and C sit on the left of the crossfader, B and D on the right.", color = TextGray, fontSize = 12.sp)
                    Text("Key lock (keep the pitch when the tempo changes)", color = TextGray, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SmallBtn("ALL DECKS ON", modifier = Modifier.weight(1f)) { Decks.all().forEach { it.applyKeylock(true) } }
                        SmallBtn("ALL DECKS OFF", modifier = Modifier.weight(1f)) { Decks.all().forEach { it.applyKeylock(false) } }
                    }
                }

                SettingsSection("LIBRARY") {
                    Text("Folders that are scanned for music and video (${Library.tracks.size} files found):", color = TextGray, fontSize = 12.sp)
                    for (f in Library.folders.toList()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(f.absolutePath, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            SmallBtn("REMOVE") { Library.removeFolder(f) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SmallBtn("+ ADD FOLDER", modifier = Modifier.weight(1f)) { pickFolder()?.let { Library.addFolder(it) } }
                        SmallBtn("RESCAN", modifier = Modifier.weight(1f), enabled = !Library.scanning) { Library.scan() }
                        SmallBtn(if (Library.analyzing) "ANALYSING ${Library.analyzeDone}/${Library.analyzeTotal}" else "ANALYZE ALL", modifier = Modifier.weight(1f), enabled = !Library.analyzing) { Library.analyzeAll() }
                    }
                }

                SettingsSection("VIDEO") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(Prefs.autoVideo, { Prefs.autoVideo = it })
                        Spacer(Modifier.width(8.dp))
                        Text("Pop up the video in its own window when a video is loaded or starts playing (resize it, drag it to a TV, double-click for full screen)", color = Color.White, fontSize = 12.sp)
                    }
                }

                SettingsSection("CONTROLLERS: KEYBOARD AND MIDI") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(MidiService.enabled, { MidiService.enabled = it; MidiService.rescan() })
                        Spacer(Modifier.width(8.dp))
                        Text("Use MIDI controllers", color = Color.White, fontSize = 12.sp)
                    }
                    Text(
                        if (MidiService.devices.isEmpty()) "No MIDI controller found. Plug it in and press RESCAN MIDI." else "Connected: " + MidiService.devices.joinToString(", "),
                        color = TextGray, fontSize = 12.sp
                    )
                    Text("Last input: " + Controls.lastInput.ifEmpty { "(nothing yet: press a key or touch a control)" }, color = Accent, fontSize = 12.sp)
                    Text("To map: pick a tab, press LEARN next to a function, then press the key or touch the pad / knob / fader on your controller. ESC cancels. Knobs and faders need a MIDI knob or fader.", color = TextGray, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SmallBtn("RESCAN MIDI", modifier = Modifier.weight(1f)) { MidiService.rescan() }
                        SmallBtn("KEYBOARD DEFAULTS", modifier = Modifier.weight(1f)) { Controls.resetKeyboard() }
                        SmallBtn("CLEAR ALL", modifier = Modifier.weight(1f), active = true, activeColor = DeckRed) { Controls.clearAll() }
                    }
                    MappingEditor()
                }

                SettingsSection("SAMPLER") {
                    Labeled("VOLUME  ${(Sampler.volume * 100).toInt()}%") { HSlider(Sampler.volume, 0f, 1f, Accent) { Sampler.applyVolume(it) } }
                    Text("Your own samples: + ADD MY SAMPLES copies files into ${Sampler.samplesDir.absolutePath} (they also show in the library as My Samples; S puts one on the next free pad). Pads are remembered between sessions. LOAD mode puts a file on a pad, CLEAR mode empties one.", color = TextGray, fontSize = 12.sp)
                }

                SettingsSection("RECORDINGS") {
                    Text("Audio mixes (REC): " + File(System.getProperty("user.home"), "Music/MAXIDO DJ").absolutePath, color = Color.White, fontSize = 12.sp)
                    Text("Video mixes: " + File(System.getProperty("user.home"), "Videos/MAXIDO DJ").absolutePath, color = Color.White, fontSize = 12.sp)
                }

                SettingsSection("STORAGE") {
                    Text("Working files (decoded tracks and prepared stems): ${mb(cacheBytes)} in ${TrackCache.dir.absolutePath}", color = Color.White, fontSize = 12.sp)
                    Text("Prepared stems are stored as one .mxs file per song (about 170 MB) in the stems folder inside that path. They are listed in the library under Stems and load instantly; a .mxs can also be opened with LOAD. Eject tracks from the decks before clearing, because files in use cannot be deleted.", color = TextGray, fontSize = 12.sp)
                    var keepSel by remember { mutableIntStateOf(StemCache.keep) }
                    Text("How many prepared songs to keep (the oldest are removed after the next preparation):", color = TextGray, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (n in listOf(8, 20, 50)) SmallBtn("$n songs (about ${n * 170 / 1000.0} GB)".replace(".0 GB", " GB"), modifier = Modifier.weight(1f), active = keepSel == n) { keepSel = n; StemCache.keep = n }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        SmallBtn("DELETE PREPARED STEMS", active = true, activeColor = DeckRed) {
                            val before = dirBytes(TrackCache.dir)
                            File(TrackCache.dir, "stems").deleteRecursively()
                            Library.refreshStems()
                            cacheBytes = dirBytes(TrackCache.dir)
                            freed = "Freed " + mb((before - cacheBytes).coerceAtLeast(0L))
                        }
                        SmallBtn("REFRESH") { cacheBytes = dirBytes(TrackCache.dir) }
                        Text(freed, color = TextGray, fontSize = 12.sp)
                    }
                }

                SettingsSection("ABOUT") {
                    Text("MAXIDO DJ for PC. 4 decks, 4-stem AI separation, sampler, loops, video mixing, library with BPM and key detection.", color = Color.White, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun MappingEditor() {
    var grp by remember { mutableStateOf("A") }
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        for (g in Controls.groups) SmallBtn(g, modifier = Modifier.weight(1f), active = grp == g) { grp = g }
    }
    val list = Controls.actions.filter { it.group == grp }
    Box(Modifier.fillMaxWidth().height(330.dp).background(Color(0xFF0A0C10), RoundedCornerShape(6.dp))) {
        LazyColumn(Modifier.fillMaxSize().padding(6.dp)) {
            items(list, key = { it.id }) { act ->
                val boundCodes = Controls.bindings.entries.filter { it.value == act.id }.map { it.key }
                val isLearning = Controls.learning == act.id
                Row(Modifier.fillMaxWidth().height(34.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(act.label + (if (act.knob) "  (knob / fader)" else ""), color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Text(
                        if (isLearning) (if (act.knob) "move a knob..." else "press a key / pad...") else if (boundCodes.isEmpty()) "-" else boundCodes.joinToString("  /  ") { Controls.describe(it) },
                        color = if (isLearning) Accent else TextGray, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.width(210.dp)
                    )
                    SmallBtn(if (isLearning) "CANCEL" else "LEARN", active = isLearning) { Controls.learning = if (isLearning) null else act.id }
                    SmallBtn("CLEAR") { Controls.unbindAction(act.id) }
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------ effects rack

/** The effects tab of a deck: 3 slots, each with an effect chooser (< >), an ON switch and two parameters. */
@Composable
private fun RackPanel(d: DeckModel, color: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        for (s in 0..2) {
            val def = FxCatalog.byId(d.rackType[s])
            Column(
                Modifier.fillMaxWidth().background(Color(0xFF10131A), RoundedCornerShape(6.dp)).border(1.dp, if (d.rackOn[s]) color else Line, RoundedCornerShape(6.dp)).padding(5.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    SmallBtn("<", modifier = Modifier.width(34.dp)) { d.rackStep(s, -1) }
                    Text(def.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, modifier = Modifier.weight(1f))
                    SmallBtn(">", modifier = Modifier.width(34.dp)) { d.rackStep(s, 1) }
                    SmallBtn(if (d.rackOn[s]) "ON" else "OFF", modifier = Modifier.width(56.dp), active = d.rackOn[s], activeColor = color) { d.rackToggle(s) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(def.p1.uppercase(), color = TextGray, fontSize = 9.sp, maxLines = 1)
                        HSlider(d.rackP1[s], 0f, 1f, color) { d.rackParam(s, 0, it) }
                    }
                    Column(Modifier.weight(1f)) {
                        Text(def.p2.uppercase(), color = TextGray, fontSize = 9.sp, maxLines = 1)
                        HSlider(d.rackP2[s], 0f, 1f, color) { d.rackParam(s, 1, it) }
                    }
                }
            }
        }
        Text(FxCatalog.all.size.toString() + " effects. Pick one with < >, switch it on, move the two sliders. They follow the tempo.", color = TextGray, fontSize = 10.sp)
    }
}
