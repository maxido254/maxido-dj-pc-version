package com.example.djapp

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File
import javax.sound.midi.MidiDevice
import javax.sound.midi.MidiMessage
import javax.sound.midi.MidiSystem
import javax.sound.midi.Receiver
import javax.sound.midi.Sequencer
import javax.sound.midi.ShortMessage
import javax.sound.midi.Synthesizer
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type

/** Crossfader, master volume and bass amp live here, so the on-screen sliders, the keyboard and MIDI controllers all move the same thing. */
object Mix {
    var cross by mutableFloatStateOf(0.5f)
    var master by mutableFloatStateOf(1f)
    var bassAmp by mutableFloatStateOf(0.5f)

    fun apply() {
        val l = Native_.lib
        l.dj_set_master_gain(master); l.dj_set_bass_amp(bassAmp); l.dj_set_crossfader(cross)
        Decks.all().forEach { it.initRack() }
        VideoMixer.audioCross = cross
    }
    fun applyCross(v: Float) { cross = v.coerceIn(0f, 1f); Native_.lib.dj_set_crossfader(cross); VideoMixer.audioCross = cross }
    fun applyMaster(v: Float) { master = v.coerceIn(0.25f, 1.25f); Native_.lib.dj_set_master_gain(master) }
    fun applyBassAmp(v: Float) { bassAmp = v.coerceIn(0f, 1f); Native_.lib.dj_set_bass_amp(bassAmp) }
}

/** One thing a key or a MIDI control can do. Buttons run once per press; knobs get 0..1. */
class Action(val id: String, val group: String, val label: String, val knob: Boolean, val run: (Float) -> Unit)

/**
 * Keyboard + MIDI mapping. An input has a code: "K:<key>" (computer key), "N:<channel>:<note>" (MIDI pad / button),
 * "C:<channel>:<controller>" (MIDI knob / fader / button sending CC), "P:<channel>" (MIDI pitch fader).
 * LEARN: pick a function, press the key or touch the control, done. Mappings are saved in ~/.maxido-dj/controls.txt.
 */
object Controls {
    val groups = listOf("A", "B", "C", "D", "MIXER", "SAMPLER")
    val actions: List<Action> by lazy { buildActions() }
    private val byId: Map<String, Action> by lazy { actions.associateBy { it.id } }

    val bindings = mutableStateMapOf<String, String>()      // input code -> action id
    var learning by mutableStateOf<String?>(null)            // the action waiting for an input
    var lastInput by mutableStateOf("")
    @Volatile var typing = false                             // a text box has the focus: keys are typing, not shortcuts

    private val down: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()
    private val saveFile = File(System.getProperty("user.home"), ".maxido-dj/controls.txt")
    private var started = false

    fun start() {
        if (started) return
        started = true
        var loaded = false
        try {
            if (saveFile.exists()) {
                saveFile.readLines().forEach { line ->
                    val p = line.split('\t')
                    if (p.size >= 2 && byId.containsKey(p[1])) bindings[p[0]] = p[1]
                }
                loaded = bindings.isNotEmpty()
            }
        } catch (_: Throwable) {}
        if (!loaded) { bindings.putAll(defaultKeys()); save() }
        MidiService.rescan()
    }

    private fun eq(v: Float): Float {                          // knob centre = flat, left = cut, right = boost
        val db = if (v < 0.5f) -26f * (1f - v * 2f) else 12f * (v - 0.5f) * 2f
        return if (kotlin.math.abs(db) < 1.0f) 0f else db
    }

    private fun buildActions(): List<Action> {
        val out = ArrayList<Action>()
        val ds = Decks.all()
        val names = listOf("A", "B", "C", "D")
        for (i in 0..3) {
            val d = ds[i]; val g = names[i]; val p = "d$i"
            out.add(Action("$p.play", g, "Play / pause", false) { if (d.dur > 0f) d.togglePlay() })
            out.add(Action("$p.cue", g, "Cue", false) { if (d.dur > 0f) d.cuePress() })
            out.add(Action("$p.sync", g, "Sync to the other deck", false) {
                if (d.bpm > 0f) {
                    val o = ds.firstOrNull { it !== d && it.playing && it.bpm > 0f } ?: ds.firstOrNull { it !== d && it.bpm > 0f }
                    if (o != null) d.syncTo(o)
                }
            })
            out.add(Action("$p.loop", g, "Loop on / off", false) { d.toggleLoop() })
            out.add(Action("$p.loopin", g, "Loop IN", false) { d.loopIn() })
            out.add(Action("$p.loopout", g, "Loop OUT", false) { d.loopOut() })
            out.add(Action("$p.loopless", g, "Loop shorter (halve)", false) { d.changeLoopBeats(d.loopBeats / 2) })
            out.add(Action("$p.loopmore", g, "Loop longer (double)", false) { d.changeLoopBeats(d.loopBeats * 2) })
            out.add(Action("$p.keylock", g, "Key lock", false) { d.toggleKeylock() })
            val sn = listOf("Vocal", "Melody", "Bass", "Drums")
            val si = intArrayOf(0, 3, 2, 1)                    // button order -> stem index (0 vocal, 1 drums, 2 bass, 3 melody)
            for (k in 0..3) out.add(Action("$p.stem$k", g, "Stem on / off: ${sn[k]}", false) { d.toggleStem(si[k]) })
            val fn = listOf("Voc Echo", "Voc Reverb", "Instr Echo", "Instr Reverb")
            for (k in 0..3) out.add(Action("$p.fx$k", g, "Stem effect: ${fn[k]}", false) { d.toggleFx(k) })
            for (s in 0..2) {
                out.add(Action("$p.rack$s.on", g, "Effect slot ${s + 1}: on / off", false) { d.rackToggle(s) })
                out.add(Action("$p.rack$s.next", g, "Effect slot ${s + 1}: next effect", false) { d.rackStep(s, 1) })
                out.add(Action("$p.rack$s.prev", g, "Effect slot ${s + 1}: previous effect", false) { d.rackStep(s, -1) })
                out.add(Action("$p.rack$s.p1", g, "Effect slot ${s + 1}: first knob", true) { d.rackParam(s, 0, it) })
                out.add(Action("$p.rack$s.p2", g, "Effect slot ${s + 1}: second knob", true) { d.rackParam(s, 1, it) })
            }
            out.add(Action("$p.vol", g, "Channel volume", true) { d.applyVolume(it) })
            out.add(Action("$p.treble", g, "Treble knob", true) { d.applyTreble(eq(it)) })
            out.add(Action("$p.mid", g, "Mid knob", true) { d.applyMid(eq(it)) })
            out.add(Action("$p.bass", g, "Bass knob", true) { d.applyBass(eq(it)) })
            out.add(Action("$p.filter", g, "Filter knob", true) { d.applyFilter(it * 2f - 1f) })
            out.add(Action("$p.tempo", g, "Tempo fader", true) {
                val v = (it * 2f - 1f) * 0.08f
                d.setTempo(if (kotlin.math.abs(v) < 0.002f) 0f else v)
            })
        }
        out.add(Action("mix.cross", "MIXER", "Crossfader", true) { Mix.applyCross(it) })
        out.add(Action("mix.cross.a", "MIXER", "Crossfader to the A / C side", false) { Mix.applyCross(0f) })
        out.add(Action("mix.cross.mid", "MIXER", "Crossfader to the centre", false) { Mix.applyCross(0.5f) })
        out.add(Action("mix.cross.b", "MIXER", "Crossfader to the B / D side", false) { Mix.applyCross(1f) })
        out.add(Action("mix.cross.l", "MIXER", "Crossfader nudge left", false) { Mix.applyCross(Mix.cross - 0.1f) })
        out.add(Action("mix.cross.r", "MIXER", "Crossfader nudge right", false) { Mix.applyCross(Mix.cross + 0.1f) })
        out.add(Action("mix.master", "MIXER", "Master volume", true) { Mix.applyMaster(0.25f + it) })
        out.add(Action("mix.bassamp", "MIXER", "Bass amp", true) { Mix.applyBassAmp(it) })
        for (i in 0..7) out.add(Action("smp.pad$i", "SAMPLER", "Pad ${i + 1} of the current bank", false) { Sampler.padPress(i) })
        for (b in 0..3) out.add(Action("smp.bank$b", "SAMPLER", "Bank ${b + 1}", false) { Sampler.bank = b })
        out.add(Action("smp.prev", "SAMPLER", "Previous bank", false) { Sampler.bank = (Sampler.bank + 3) % 4 })
        out.add(Action("smp.next", "SAMPLER", "Next bank", false) { Sampler.bank = (Sampler.bank + 1) % 4 })
        out.add(Action("smp.vol", "SAMPLER", "Sampler volume", true) { Sampler.applyVolume(it) })
        return out
    }

    /** Default keyboard layout: left hand = deck A, right hand = deck B, Z X / N M = decks C and D. */
    private fun defaultKeys(): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        fun k(key: Key, id: String) { m["K:" + key.keyCode] = id }
        // deck A
        k(Key.Q, "d0.play"); k(Key.W, "d0.cue"); k(Key.E, "d0.sync"); k(Key.R, "d0.loop"); k(Key.T, "d0.keylock")
        k(Key.G, "d0.loopin"); k(Key.H, "d0.loopout"); k(Key.Minus, "d0.loopless"); k(Key.Equals, "d0.loopmore")
        k(Key.One, "d0.stem0"); k(Key.Two, "d0.stem1"); k(Key.Three, "d0.stem2"); k(Key.Four, "d0.stem3")
        k(Key.A, "d0.fx0"); k(Key.S, "d0.fx1"); k(Key.D, "d0.fx2"); k(Key.F, "d0.fx3")
        k(Key.V, "d0.rack0.on"); k(Key.B, "d0.rack1.on"); k(Key.C, "d0.rack2.on")
        // deck B
        k(Key.U, "d1.play"); k(Key.I, "d1.cue"); k(Key.O, "d1.sync"); k(Key.P, "d1.loop"); k(Key.LeftBracket, "d1.keylock")
        k(Key.Comma, "d1.loopless"); k(Key.Period, "d1.loopmore")
        k(Key.Seven, "d1.stem0"); k(Key.Eight, "d1.stem1"); k(Key.Nine, "d1.stem2"); k(Key.Zero, "d1.stem3")
        k(Key.J, "d1.fx0"); k(Key.K, "d1.fx1"); k(Key.L, "d1.fx2"); k(Key.Semicolon, "d1.fx3")
        // decks C and D
        k(Key.Z, "d2.play"); k(Key.X, "d2.cue"); k(Key.N, "d3.play"); k(Key.M, "d3.cue")
        // crossfader and sampler
        k(Key.DirectionLeft, "mix.cross.l"); k(Key.DirectionRight, "mix.cross.r"); k(Key.DirectionDown, "mix.cross.mid")
        k(Key.MoveHome, "mix.cross.a"); k(Key.MoveEnd, "mix.cross.b")
        val fkeys = listOf(Key.F1, Key.F2, Key.F3, Key.F4, Key.F5, Key.F6, Key.F7, Key.F8)
        for (i in 0..7) k(fkeys[i], "smp.pad$i")
        k(Key.PageUp, "smp.prev"); k(Key.PageDown, "smp.next")
        return m
    }

    fun describe(code: String): String {
        val p = code.split(':')
        return when (p[0]) {
            "K" -> "Key " + Key(p[1].toLongOrNull() ?: 0L).toString().removePrefix("Key: ")
            "N" -> "MIDI pad / note ${p.getOrNull(2)} (ch ${p.getOrNull(1)})"
            "C" -> "MIDI knob / CC ${p.getOrNull(2)} (ch ${p.getOrNull(1)})"
            "P" -> "MIDI pitch fader (ch ${p.getOrNull(1)})"
            else -> code
        }
    }

    fun save() {
        try {
            saveFile.parentFile?.mkdirs()
            saveFile.writeText(bindings.entries.joinToString("\n") { it.key + "\t" + it.value })
        } catch (_: Throwable) {}
    }

    private fun isKey(code: String) = code.startsWith("K:")

    private fun bind(code: String, id: String) {
        // one computer key and one MIDI control per function; an input can only do one thing
        bindings.entries.filter { it.value == id && isKey(it.key) == isKey(code) }.map { it.key }.forEach { bindings.remove(it) }
        bindings[code] = id
        save()
    }

    fun unbindAction(id: String) { bindings.entries.filter { it.value == id }.map { it.key }.forEach { bindings.remove(it) }; save() }
    fun resetKeyboard() {
        val midi = bindings.entries.filter { !isKey(it.key) }.map { Pair(it.key, it.value) }
        bindings.clear(); bindings.putAll(defaultKeys()); midi.forEach { bindings[it.first] = it.second }
        save()
    }
    fun clearAll() { bindings.clear(); save() }

    /** Every key press and every MIDI message arrives here. Returns true when it was used. */
    fun dispatch(code: String, value: Float, continuous: Boolean): Boolean {
        lastInput = describe(code)
        val l = learning
        if (l != null) {
            val act = byId[l]
            if (act != null && act.knob && !continuous) return true          // a knob needs a MIDI knob or fader
            if (continuous || value > 0.5f) { bind(code, l); learning = null }
            return true
        }
        val id = bindings[code]
        if (id == null) { if (value <= 0.5f) down.remove(code); return false }
        val act = byId[id] ?: return false
        if (act.knob) { if (continuous) act.run(value.coerceIn(0f, 1f)); return true }
        if (value > 0.5f) { if (down.add(code)) act.run(1f) } else down.remove(code)     // buttons fire once per press
        return true
    }

    /** Computer keyboard (attached to the program's windows). */
    fun onKey(ev: androidx.compose.ui.input.key.KeyEvent): Boolean {
        val k = ev.key
        val code = "K:" + k.keyCode
        if (ev.type == KeyEventType.KeyUp) { down.remove(code); return false }
        if (ev.type != KeyEventType.KeyDown) return false
        if (typing) return false
        if (k == Key.ShiftLeft || k == Key.ShiftRight || k == Key.CtrlLeft || k == Key.CtrlRight ||
            k == Key.AltLeft || k == Key.AltRight || k == Key.MetaLeft || k == Key.MetaRight) return false
        if (learning != null && k == Key.Escape) { learning = null; return true }
        return dispatch(code, 1f, false)
    }
}

/** Opens every connected MIDI input and feeds it to Controls. */
object MidiService {
    val devices = mutableStateListOf<String>()
    var enabled by mutableStateOf(true)
    private val opened = ArrayList<MidiDevice>()

    @Synchronized fun rescan() {
        for (d in opened) { try { d.close() } catch (_: Throwable) {} }
        opened.clear(); devices.clear()
        if (!enabled) return
        for (info in MidiSystem.getMidiDeviceInfo()) {
            try {
                val dev = MidiSystem.getMidiDevice(info)
                if (dev is Sequencer || dev is Synthesizer) continue
                if (dev.maxTransmitters == 0) continue
                dev.open()
                dev.transmitter.receiver = Rcv()
                opened.add(dev); devices.add(info.name)
            } catch (_: Throwable) {}
        }
    }

    private class Rcv : Receiver {
        override fun send(message: MidiMessage, timeStamp: Long) {
            if (message !is ShortMessage) return
            val ch = message.channel + 1
            when (message.command) {
                ShortMessage.NOTE_ON -> Controls.dispatch("N:$ch:${message.data1}", if (message.data2 > 0) 1f else 0f, false)
                ShortMessage.NOTE_OFF -> Controls.dispatch("N:$ch:${message.data1}", 0f, false)
                ShortMessage.CONTROL_CHANGE -> Controls.dispatch("C:$ch:${message.data1}", message.data2 / 127f, true)
                ShortMessage.PITCH_BEND -> Controls.dispatch("P:$ch", ((message.data2 shl 7) or message.data1) / 16383f, true)
                else -> {}
            }
        }
        override fun close() {}
    }
}
