package com.example.djapp

import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * .mxs = MAXIDO stems: ONE file with the four stems of a song (vocal, drums, bass, melody) as 16-bit stereo audio.
 *
 *   0      "MXS1"                      magic
 *   4      int   version (1)
 *   8      int   sample rate
 *   12     int   flags (bit 0: the original is a video file)
 *   16     long  frames per stem
 *   24     long  size of the original file in bytes
 *   32     long  last-modified time of the original file
 *   40     4 x (long offset, long length)   where each stem starts and how many bytes it has
 *   104    int   length of the original file's path, then the path in UTF-8 (at most 4000 bytes)
 *   65536  the stems, each starting on a multiple of 65536 so the audio engine can map it straight from this file
 *
 * Little endian. The stems are stored uncompressed (as the engine plays them), so a .mxs is about 170 MB for a 5 minute song.
 */
class MxsInfo(
    val file: File, val rate: Int, val frames: Long, val flags: Int,
    val offsets: LongArray, val lengths: LongArray, val source: String?
) {
    val isVideo: Boolean get() = (flags and 1) != 0
}

object Mxs {
    const val ALIGN = 65536L
    private const val VERSION = 1
    private const val MAX_PATH = 4000

    /** Packs four raw 16-bit stereo files (vocal, drums, bass, melody) into one .mxs file. */
    fun write(dst: File, parts: List<File>, rate: Int, source: File?): Boolean {
        if (parts.size != 4) return false
        val len = (parts.minOf { it.length() } / 4) * 4          // all four stems must have the same length: whole frames
        if (len < 8) return false
        val offs = LongArray(4)
        val lens = LongArray(4) { len }
        var pos = ALIGN
        for (i in 0 until 4) { offs[i] = pos; pos += ((len + ALIGN - 1) / ALIGN) * ALIGN }

        val hdr = ByteBuffer.allocate(ALIGN.toInt()).order(ByteOrder.LITTLE_ENDIAN)
        hdr.put('M'.code.toByte()).put('X'.code.toByte()).put('S'.code.toByte()).put('1'.code.toByte())
        hdr.putInt(VERSION).putInt(rate).putInt(if (source != null && isVideoFile(source)) 1 else 0)
        hdr.putLong(len / 4)
        hdr.putLong(source?.length() ?: 0L).putLong(source?.lastModified() ?: 0L)
        for (i in 0 until 4) hdr.putLong(offs[i]).putLong(lens[i])
        val sp = (source?.absolutePath ?: "").toByteArray(Charsets.UTF_8).let { if (it.size > MAX_PATH) it.copyOf(MAX_PATH) else it }
        hdr.putInt(sp.size).put(sp)

        val tmp = File(dst.path + ".tmp")
        try {
            RandomAccessFile(tmp, "rw").use { raf ->
                raf.setLength(pos)
                raf.seek(0); raf.write(hdr.array(), 0, ALIGN.toInt())
                val out = raf.channel
                for (i in 0 until 4) {
                    FileInputStream(parts[i]).channel.use { inp ->
                        out.position(offs[i])
                        var done = 0L
                        while (done < len) {
                            val n = inp.transferTo(done, len - done, out)
                            if (n <= 0) return false.also { tmp.delete() }
                            done += n
                        }
                    }
                }
            }
            dst.delete()
            return tmp.renameTo(dst)
        } catch (_: Throwable) {
            tmp.delete()
            return false
        }
    }

    /** Reads the header of a .mxs file; null if it is not a complete, valid .mxs. */
    fun read(f: File): MxsInfo? {
        try {
            if (!f.isFile || f.length() < ALIGN) return null
            val hdr = ByteArray(ALIGN.toInt())
            RandomAccessFile(f, "r").use { it.readFully(hdr) }
            val b = ByteBuffer.wrap(hdr).order(ByteOrder.LITTLE_ENDIAN)
            if (b.get().toInt() != 'M'.code || b.get().toInt() != 'X'.code || b.get().toInt() != 'S'.code || b.get().toInt() != '1'.code) return null
            if (b.getInt() != VERSION) return null
            val rate = b.getInt()
            val flags = b.getInt()
            val frames = b.getLong()
            b.getLong(); b.getLong()                                // original size / time (not needed here)
            val offs = LongArray(4); val lens = LongArray(4)
            for (i in 0 until 4) { offs[i] = b.getLong(); lens[i] = b.getLong() }
            val n = b.getInt()
            val path = if (n in 0..MAX_PATH) ByteArray(n).also { b.get(it) }.toString(Charsets.UTF_8) else ""
            if (rate <= 0 || frames <= 0) return null
            for (i in 0 until 4) {
                if (offs[i] < ALIGN || offs[i] % ALIGN != 0L || lens[i] < 8 || offs[i] + lens[i] > f.length()) return null
            }
            return MxsInfo(f, rate, frames, flags, offs, lens, path.ifEmpty { null })
        } catch (_: Throwable) {
            return null
        }
    }
}
