package com.example.djapp

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

private val samplerLib get() = Native_.lib

/** The 32-pad sampler of the engine (4 banks x 8 pads). The pad -> file assignments are remembered in ~/.maxido-dj/sampler.txt. */
object Sampler {
    const val SLOTS = 32
    private val saveFile = File(System.getProperty("user.home"), ".maxido-dj/sampler.txt")
    /** The DJ's own samples: files added with ADD MY SAMPLES are copied here and show up in the library as My Samples. */
    val samplesDir: File = File(System.getProperty("user.home"), ".maxido-dj/samples").apply { mkdirs() }

    val names = mutableStateListOf<String>().apply { repeat(SLOTS) { add("") } }
    val active = mutableStateListOf<Boolean>().apply { repeat(SLOTS) { add(false) } }
    private val files = arrayOfNulls<File>(SLOTS)

    var bank by mutableIntStateOf(0)
    var mode by mutableIntStateOf(0)          // 0 = PLAY, 1 = LOAD (click a pad to choose a file), 2 = CLEAR
    var loop by mutableStateOf(false)
    var volume by mutableFloatStateOf(0.8f)
    private var started = false

    fun start() {
        if (started) return
        started = true
        samplerLib.dj_set_sample_volume(volume)
        Thread {
            try {
                if (saveFile.exists()) saveFile.readLines().forEach { line ->
                    val p = line.split('\t')
                    val slot = p.getOrNull(0)?.toIntOrNull()
                    val f = p.getOrNull(1)?.let { File(it) }
                    if (slot != null && slot in 0 until SLOTS && f != null && f.isFile) loadInto(slot, f)
                }
            } catch (_: Throwable) {}
        }.apply { isDaemon = true; priority = Thread.MIN_PRIORITY; name = "sampler-restore" }.start()
    }

    fun applyVolume(v: Float) { volume = v; samplerLib.dj_set_sample_volume(v) }

    private fun decode(f: File): Pair<File, Int>? {
        val raw = TrackCache.rawFor(f)
        val rf = File(raw.path + ".rate")
        var rate = if (raw.exists() && raw.length() > 1000) (try { rf.readText().trim().toInt() } catch (_: Exception) { 0 }) else 0
        if (rate <= 0) {
            rate = if (isVideoFile(f)) 0 else samplerLib.dj_decode_to_raw(f.absolutePath, raw.absolutePath)
            if (rate <= 0) rate = Ffmpeg.audioToRaw(f, raw)
            if (rate > 0) rf.writeText(rate.toString())
        }
        return if (rate > 0) Pair(raw, rate) else null
    }

    private fun loadInto(slot: Int, f: File): Boolean {
        val dec = decode(f) ?: return false
        if (samplerLib.dj_load_sample(slot, dec.first.absolutePath, dec.second) != 1) return false
        files[slot] = f
        names[slot] = f.nameWithoutExtension
        return true
    }

    /** Puts a file on a pad (decoding takes a moment, so it runs in the background). */
    fun assign(slot: Int, f: File) {
        names[slot] = "loading..."
        Thread {
            val ok = try { loadInto(slot, f) } catch (_: Throwable) { false }
            if (!ok) { names[slot] = ""; files[slot] = null } else save()
        }.apply { isDaemon = true; name = "sampler-load" }.start()
    }

    /** Copies the chosen files into the samples folder (so they stay even if the originals move) and refreshes the library. */
    fun importFiles(list: List<File>) {
        Thread {
            for (f in list) {
                try {
                    if (!f.isFile) continue
                    var dst = File(samplesDir, f.name)
                    var n = 2
                    while (dst.exists()) {
                        dst = File(samplesDir, f.nameWithoutExtension + " (" + n + ")" + (if (f.extension.isEmpty()) "" else "." + f.extension))
                        n++
                    }
                    f.copyTo(dst)
                } catch (_: Throwable) {}
            }
            var waited = 0
            while (Library.scanning && waited < 100) { Thread.sleep(50); waited++ }
            Library.scan()
        }.apply { isDaemon = true; name = "sampler-import" }.start()
    }

    /** Puts a file on the next empty pad (starting at the current bank) and shows that bank. False if all 32 pads are taken. */
    fun assignNext(f: File): Boolean {
        for (i in 0 until SLOTS) {
            val s = (bank * 8 + i) % SLOTS
            if (names[s].isEmpty()) { bank = s / 8; assign(s, f); return true }
        }
        return false
    }

    fun clear(slot: Int) {
        samplerLib.dj_stop_sample(slot); samplerLib.dj_clear_sample(slot)
        files[slot] = null; names[slot] = ""; active[slot] = false
        save()
    }

    /** PLAY mode: a tap plays the pad; with LOOP on, a tap starts it looping and the next tap stops it. */
    fun press(slot: Int) {
        if (names[slot].isEmpty()) return
        if (loop && active[slot]) samplerLib.dj_stop_sample(slot)
        else samplerLib.dj_trigger_sample(slot, if (loop) 1 else 0)
    }

    /** For keyboard / MIDI: plays pad i (0..7) of the current bank. */
    fun padPress(i: Int) { val s = bank * 8 + i; if (s in 0 until SLOTS) press(s) }

    fun poll() {
        val base = bank * 8
        for (i in 0 until 8) {
            val on = samplerLib.dj_is_sample_playing(base + i) != 0
            if (active[base + i] != on) active[base + i] = on
        }
    }

    @Synchronized private fun save() {
        try {
            saveFile.parentFile?.mkdirs()
            saveFile.writeText((0 until SLOTS).filter { files[it] != null }.joinToString("\n") { "$it\t${files[it]!!.absolutePath}" })
        } catch (_: Throwable) {}
    }
}
