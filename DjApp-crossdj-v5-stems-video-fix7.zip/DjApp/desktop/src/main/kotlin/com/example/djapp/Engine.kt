package com.example.djapp

import com.sun.jna.Library
import com.sun.jna.Native
import java.io.File

/** The native audio engine (engine.cpp built as djengine.dll / libdjengine.dylib / libdjengine.so). One function per dj_xxx export. */
interface DjLib : Library {
    fun dj_start(): Int
    fun dj_stop()
    fun dj_decode_to_raw(inPath: String, outPath: String): Int
    fun dj_load_deck(d: Int, path: String, rate: Int)
    fun dj_load_deck_stems(d: Int, paths: Array<String>, rate: Int): Int
    /** Swaps a playing deck over to its 4 stems without losing the position (vocals, drums, bass, other). */
    fun dj_set_stems(d: Int, paths: Array<String>)
    /** Stems straight from a .mxs file: offsets / lengths (4 each) of the stems inside it. */
    fun dj_set_stems_mxs(d: Int, path: String, offsets: LongArray, lengths: LongArray)
    fun dj_set_stem_volume(d: Int, s: Int, v: Float)
    fun dj_set_playing(d: Int, p: Int)
    fun dj_is_playing(d: Int): Int
    fun dj_set_volume(d: Int, v: Float)
    fun dj_set_tempo(d: Int, t: Float)
    fun dj_set_crossfader(x: Float)
    fun dj_get_position(d: Int): Double
    fun dj_get_duration(d: Int): Double
    fun dj_seek(d: Int, sec: Double)
    fun dj_get_level(): Float
    fun dj_set_jog(d: Int, active: Int, targetSec: Double)
    fun dj_set_keylock(d: Int, on: Int)
    fun dj_set_audio_mode(m: Int): Int
    fun dj_set_loop(d: Int, s: Double, e: Double, on: Int)
    fun dj_set_eq(d: Int, band: Int, db: Float)
    fun dj_set_filter(d: Int, v: Float)
    fun dj_set_reverb(d: Int, wet: Float, room: Float)
    fun dj_set_phaser(d: Int, amt: Float, rateHz: Float)
    /** Stem effects. bus 0 = vocal stem, 1 = instrumental stems; kind 0 = echo, 1 = reverb; amount 0 = off .. 1; param = echo time in seconds. */
    fun dj_set_stem_fx(d: Int, bus: Int, kind: Int, amount: Float, param: Float)
    /** Effects rack: 3 slots per deck. type 0 = empty, 1..20 = effect (see Effects.kt); p1, p2 = 0..1. */
    fun dj_fx_slot(d: Int, slot: Int, type: Int, p1: Float, p2: Float)
    fun dj_fx_on(d: Int, slot: Int, on: Int)
    fun dj_fx_beat(d: Int, sec: Float)
    fun dj_start_recording(path: String): Int
    fun dj_stop_recording()
    fun dj_load_sample(slot: Int, path: String, rate: Int): Int
    fun dj_trigger_sample(slot: Int, loop: Int)
    fun dj_clear_sample(slot: Int)
    fun dj_stop_sample(slot: Int)
    fun dj_is_sample_playing(slot: Int): Int
    fun dj_set_sample_volume(v: Float)
    fun dj_set_master_gain(v: Float)
    fun dj_set_bass_amp(v: Float)
    fun dj_set_crossfader_curve(c: Int)
    fun dj_tap_start()
    fun dj_tap_stop()
    /** Copies up to maxFrames of finished master output (float stereo interleaved) into out. Returns frames copied. */
    fun dj_tap_read(out: FloatArray, maxFrames: Int): Int
    fun dj_get_sample_rate(): Int
}

object Native_ {
    /** Where the installer put djengine.dll (Compose sets this property inside an installed app), or the dev folder when run from Gradle. */
    fun resDir(): String = libDir()
    /** Folder with scnet-large.int8.onnx: inside the installed app, or resources/common/models when run from the source tree. */
    fun modelDir(): File = File(libDir(), "models").takeIf { it.isDirectory } ?: File("resources/common/models").absoluteFile
    private fun libDir(): String {
        System.getProperty("compose.application.resources.dir")?.let { if (File(it).isDirectory) return it }
        val os = System.getProperty("os.name").lowercase()
        val sub = if (os.contains("win")) "windows-x64" else if (os.contains("mac")) "macos-arm64" else "linux-x64"
        return File("resources/$sub").absolutePath
    }

    val lib: DjLib by lazy {
        System.setProperty("jna.encoding", "UTF-8")            // the engine reads paths as UTF-8 (accents, non-Latin names)
        System.setProperty("jna.library.path", libDir())
        Native.load("djengine", DjLib::class.java)
    }
}
