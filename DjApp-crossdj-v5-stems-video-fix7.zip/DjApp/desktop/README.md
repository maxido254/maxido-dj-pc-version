# MAXIDO DJ for PC (free)

Windows / macOS / Linux desktop version. Same C++ audio engine as the Android app (decks, key-lock tempo, EQ, filter, BASS AMP,
limiter, REC), with a Compose Desktop screen. No paywall, no server: everything is unlocked.

## Get the installer (no Windows PC or developer tools needed)
Push this project to GitHub, open Actions > "Build Windows (free PC app)" > Run workflow, then download the `MAXIDO-DJ-Windows` artifact
(a .msi and an .exe installer).

## Build it yourself on Windows
1. Install Visual Studio Build Tools (C++), CMake, JDK 17.
2. `cmake -S ..\app\src\main\cpp -B build -A x64 && cmake --build build --config Release`
3. Copy `build\Release\djengine.dll` to `resources\windows-x64\`
4. `gradle run` (or `gradle packageMsi`)

## Stems, video mixing, video recording
* **Stems**: VOCAL / DRUMS / BASS / MELODY buttons, ACAPELLA, NO VOCALS, BEATLESS. AUTO STEMS (mixer panel) separates each track in the background with the
  AI model (SCNet-large, int8, the same one as the phone app) and swaps the deck over without a gap. It uses 10 threads when no deck is playing and 4 while one
  plays, which suits a 6-core / 12-thread Ryzen 5 7640HS (AVX-512 + VNNI). Stems are cached in `~/.maxido-dj/cache`. The model (45 MB) is downloaded by Gradle at build time.
* **Video mixer** (VIDEO button): VIDEO + SOUND loads a video file as the track (picture locked to the deck), SILENT LOOP adds a picture-only clip.
  Blend / dip to black / cut, crossfader or manual, OUTPUT WINDOW for a projector or TV (double-click = full screen).
* **REC VIDEO MIX**: records exactly what the preview shows plus the master sound (bass amp and limiter included) to `Videos\MAXIDO DJ\*.mp4`
  (H.264 + AAC when the bundled FFmpeg has an H.264 encoder, otherwise MPEG-4 + AAC). REC (audio only) still saves a WAV.

Supported audio: MP3, WAV, FLAC (fast built-in decoder), OGG, M4A, AAC and video files (FFmpeg). Recordings go to Music\MAXIDO DJ.

## Layout, library and keeping the laptop cool
* **Layout**: waveform strips on top, deck A | mixer | deck B in the middle, library at the bottom. Mixer: TREBLE / MID / BASS / FILTER knobs (drag up/down, double-click resets), channel faders, master, BASS AMP, crossfader.
* **Library**: folders on the left (Music and Videos are added automatically, `+ ADD FOLDER` adds more), search box, sortable columns (Title, Artist, Length, BPM, Key). Double-click a track = load on a free deck; the **A** / **B** buttons load on a chosen deck.
  `ANALYZE ALL` fills in BPM, key and length one track at a time with short rests (the decoded copy is deleted afterwards). Results are remembered in `~/.maxido-dj/library.tsv`.
* **Heat**: the AI stem separation is the heaviest job. `STEMS CPU` in the top bar: **ECO** (2 threads + rests, default), **BALANCED**, **FAST**. AUTO STEMS is off by default: press PREPARE STEMS on the deck you need.
  ONNX Runtime spin-waiting is switched off, so idle worker threads no longer burn 100 % of a core.

## Decks C and D, sampler, loops, settings
* **4 decks.** A and B are the big decks with video. C and D are compact audio-only decks under them (A and C sit on the left of the crossfader, B and D on the right).
* **Zoomed waveforms** scroll across the top (playhead in the middle, click to jump); every big deck also has a whole-track overview.
* **Loops:** IN / OUT set a loop by hand, `<` `>` halve / double a beat loop (1 to 64 beats), LOOP turns it on and off. KEYLOCK keeps the pitch when you change the tempo.
* **Sampler:** 32 pads in 4 banks. PLAY mode plays a pad (an empty pad asks for a file), LOAD mode puts a track or video on a pad, CLEAR empties it, LOOP makes pads loop. Pads are remembered.
* **SETTINGS** (top bar): stems CPU mode, crossfader curve, key lock, library folders, sampler volume, recording folders, and a button to delete the prepared stems to free disk space.

## Stem effects, keyboard + MIDI, video pop-up, Stems folder
* **Stem effects** (deck buttons under the stems, need prepared stems): VOC ECHO, VOC REVERB, INST ECHO, INST REVERB. The vocal and the instrumental are effected separately, also with key lock and tempo changes. The echo is one beat long.
* **Keyboard and MIDI** (Settings > Controllers): every function can be mapped. Pick a tab (A, B, C, D, MIXER, SAMPLER), press LEARN, then press the key or touch the pad / knob / fader. One key and one MIDI control per function; ESC cancels. Mappings are saved in `~/.maxido-dj/controls.txt`.
  Default keys: A = Q play, W cue, E sync, R loop, T key lock, 1-4 stems, A S D F stem effects. B = U I O P [ and 7 8 9 0, J K L ;. C = Z X, D = N M. Crossfader = left / right / down / Home / End. Sampler pads = F1-F8, Page Up / Down = bank.
  Keys are ignored while you type in the library search box.
* **Video**: the video panel opens by itself when a video is loaded or starts playing (Settings > Video can turn this off, or also open the output window).
* **Stems folder**: in the library, `Stems` lists every track whose stems are already prepared (there is also a Stems column). Loading such a track brings its stems in at once with no CPU use. Settings > Storage sets how many prepared songs are kept (8, 20 or 50; about 170 MB each).

### Stems and video together
* Every prepared stem set remembers the original file it was made from. In the library, the `Stems` folder lists them (also tracks that were opened with LOAD from outside your library folders), and they are shown in purple.
* Loading such a track brings the stems in at once and plays the original's video with them; the video panel pops up by itself. The video is not copied into the stems folder (that would duplicate big files); if you move or delete the original file, its entry disappears from the list.
* Decks C and D can show video too: A and C share the left picture, B and D the right one (the deck loaded last with a video drives it).

### The .mxs stem format
* Prepared stems are saved as **one `.mxs` file per song** (MAXIDO stems) in `~/.maxido-dj/cache/stems`, instead of a folder of loose files. It holds the vocal, drums, bass and melody stems plus the path of the original file (so the library can list it under Stems and open the original's video with it). The layout is documented at the top of `Mxs.kt`.
* The stems are stored uncompressed, each at a 64 KiB aligned position, so the audio engine plays them straight from the `.mxs` with no unpacking (about 170 MB for a 5 minute song).
* LOAD accepts `.mxs` files: the original file is opened (with its video) and these stems are used.
