package com.example.djapp

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import java.io.File

/**
 * The MAXIDO STEMS folder: prepared stems live in a normal folder on the phone (not inside the app), so they survive
 * updates, reinstalls and a changed app name. Any version of the app that finds the folder sees the same prepared songs,
 * so nothing has to be exported or imported. Needs "All files access" (asked once). Without it the app keeps working
 * and stores stems inside its own private storage, then moves them to the folder as soon as access is given.
 */
object StemFolder {
    const val NAME = "MAXIDO STEMS"
    var granted by mutableStateOf(false)
    var asking by mutableStateOf(false)

    fun dir(): File = File(Environment.getExternalStorageDirectory(), NAME)

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    /** Call on start and every time the app comes back to the front. */
    fun refresh(ctx: Context) {
        val g = try { hasAccess(ctx) } catch (_: Exception) { false }
        val was = granted
        granted = g
        if (g && !was) {
            Thread({
                try {
                    val d = dir(); d.mkdirs(); File(d, ".nomedia").createNewFile()       // keeps the big raw files out of the gallery
                    // Move stems made before access was given into the folder.
                    File(ctx.filesDir, "prep").listFiles()?.forEach { p ->
                        val target = File(d, p.name)
                        if (p.isDirectory && !p.name.endsWith(".tmp") && !target.exists() && File(p, "meta.json").exists()) {
                            try { p.copyRecursively(target, overwrite = true); p.deleteRecursively() } catch (_: Exception) { target.deleteRecursively() }
                        }
                    }
                } catch (_: Exception) { }
                Prepared.rescan(ctx)
            }, "stem-folder").start()
        } else if (g) Prepared.rescan(ctx)
    }

    fun openSettings(ctx: Context) {
        try {
            val i = if (Build.VERSION.SDK_INT >= 30)
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName))
            else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            try { ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
        }
    }
}

@Composable
fun StemFolderHost() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { StemFolder.refresh(ctx) }
    LaunchedEffect(Unit) {
        StemFolder.refresh(ctx)
        if (!StemFolder.granted) StemFolder.asking = true
    }
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) StemFolder.refresh(ctx) }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    if (StemFolder.asking && !StemFolder.granted) {
        AlertDialog(
            onDismissRequest = { StemFolder.asking = false },
            containerColor = PanelBg,
            title = { Text("Keep your stems safe", fontSize = 16.sp, color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("MAXXIDO DJ will create a folder called ${StemFolder.NAME} on your phone and keep every prepared song there.", color = TextGray, fontSize = 12.sp)
                    Text("The folder stays when you update or reinstall the app, and any version of the app sees it, so there is nothing to export or import.", color = TextGray, fontSize = 12.sp)
                    Text(if (Build.VERSION.SDK_INT >= 30) "Android will ask you to allow \"All files access\" once. Switch it on for MAXXIDO DJ, then come back." else "Android will ask for storage access once.", color = TextGray, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    StemFolder.asking = false
                    if (Build.VERSION.SDK_INT >= 30) StemFolder.openSettings(ctx) else perm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                }) { Text("CREATE THE FOLDER") }
            },
            dismissButton = { TextButton(onClick = { StemFolder.asking = false }) { Text("NOT NOW") } }
        )
    }
}
