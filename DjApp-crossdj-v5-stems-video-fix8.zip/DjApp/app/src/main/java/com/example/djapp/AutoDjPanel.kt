package com.example.djapp

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** AUTO DJ screen: start / stop, fade length, the queue, and the library to pick tracks from. */
@Composable
fun AutoDjPanel() {
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(Modifier.weight(1f).fillMaxHeight()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                PadButton(if (AutoDj.on) "STOP AUTO DJ" else "START AUTO DJ", Modifier.weight(2f), active = AutoDj.on, color = DeckALight) {
                    if (AutoDj.on) AutoDj.stop() else AutoDj.start()
                }
                PadButton("NEXT ▶▶", Modifier.weight(1f), enabled = AutoDj.on) { AutoDj.skip() }
            }
            Text(AutoDj.status, color = if (AutoDj.on) DeckALight else TextGray, fontSize = 10.sp, maxLines = 2, modifier = Modifier.padding(vertical = 4.dp))
            FxSlider("FADE LENGTH", AutoDj.fadeSec, 2f..30f, DeckALight, "%.0f s".format(AutoDj.fadeSec)) { AutoDj.fadeSec = it }
            Text("QUEUE (${AutoDj.queue.size})", color = TextGray, fontSize = 9.sp, modifier = Modifier.padding(top = 6.dp, bottom = 2.dp))
            if (AutoDj.queue.isEmpty()) Text("Tap tracks on the right to add them.", color = TextGray, fontSize = 11.sp)
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                itemsIndexed(AutoDj.queue) { i, t ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}", color = TextGray, fontSize = 11.sp, modifier = Modifier.width(22.dp))
                        Text(t.title, color = Color.White, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f))
                        Text("▲", color = TextGray, fontSize = 14.sp, modifier = Modifier.clickable { AutoDj.moveUp(i) }.padding(horizontal = 8.dp, vertical = 4.dp))
                        Text("✕", color = TextGray, fontSize = 14.sp, modifier = Modifier.clickable { AutoDj.removeAt(i) }.padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight()) {
            Text("LIBRARY (tap to add)", color = TextGray, fontSize = 9.sp, modifier = Modifier.padding(bottom = 4.dp))
            val tracks = Library.tracks.filter { !it.isVideo }
            if (tracks.isEmpty()) Text("Open LIB once so the library is scanned, then come back.", color = TextGray, fontSize = 11.sp)
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(tracks) { t ->
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).clickable { AutoDj.add(t) }.padding(vertical = 5.dp, horizontal = 4.dp)
                    ) {
                        Text(t.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                        Text(
                            listOf(t.artist, if (t.bpm > 0f) "%.0f BPM".format(t.bpm) else "", t.camelot).filter { it.isNotBlank() }.joinToString("  ·  "),
                            color = TextGray, fontSize = 10.sp, maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
