package com.example.djapp

import android.app.ActivityManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Tutorial shown when someone taps a stem pad on a song that has no stems yet, on a budget phone (5 GB of memory or less).
 * Budget phones can't split a song live without stuttering, so the guide explains how to PREPARE songs ahead of time.
 */
object StemGuide {
    var show by mutableStateOf(false)
    var deck: DeckState? = null
    private const val KEY = "stemGuideHide"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("maxxidodj", Context.MODE_PRIVATE)
    fun hidden(ctx: Context) = prefs(ctx).getBoolean(KEY, false)
    fun setHidden(ctx: Context, v: Boolean) { prefs(ctx).edit().putBoolean(KEY, v).apply() }

    /** Phone memory in GB, as Android reports it (a "6 GB" phone reports about 5.5). */
    fun ramGb(ctx: Context): Double {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi.totalMem / 1_000_000_000.0
    }

    /** Budget phone: 5 GB of memory or less (Android reports a little under the label, so the cut-off is 5.3 GB). */
    fun budget(ctx: Context): Boolean {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return am.isLowRamDevice || ramGb(ctx) <= 5.3
    }

    /** Call when a stem pad is tapped and the deck has no ready stems. */
    fun tap(ctx: Context, d: DeckState) {
        val app = ctx.applicationContext
        when {
            d.stemProg in 0f..1.0f && d.stemProg >= 0f && d.stemProg < 2f ->
                Toast.makeText(app, "Preparing stems… ${(d.stemProg * 100).toInt()}%. The full mix keeps playing.", Toast.LENGTH_SHORT).show()
            budget(ctx) && !hidden(ctx) -> { deck = d; show = true }
            budget(ctx) -> Toast.makeText(app, "No stems yet. Prepare this song from the library (P button).", Toast.LENGTH_LONG).show()
            else -> Toast.makeText(app, "Stems for this song aren't ready yet.", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
fun StemGuideDialog() {
    if (!StemGuide.show) return
    val ctx = LocalContext.current
    val d = StemGuide.deck
    val gb = remember { StemGuide.ramGb(ctx) }
    var never by remember { mutableStateOf(false) }
    val close = { if (never) StemGuide.setHidden(ctx, true); StemGuide.show = false }
    val uri = d?.curUri
    val canPrep = d != null && d.loaded && uri != null
    AlertDialog(
        onDismissRequest = { close() },
        containerColor = PanelBg,
        title = { Text("Stems on this phone", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "This song has no stems yet, and your phone has about ${"%.1f".format(gb)} GB of memory. " +
                        "Splitting a song live would make the music stutter, so on phones like this you prepare the song first. " +
                        "Prepared songs load instantly and use almost no power while you play.",
                    color = TextGray, fontSize = 12.sp
                )
                GuideStep(1, "Prepare the song", "Open the library, find the song and tap its P button. To do a whole folder, tap PREP ALL. Or tap PREPARE THIS SONG below.")
                GuideStep(2, "Let it work", "Preparing runs in the background and takes a few minutes per song. It pauses while a deck is playing. Plug in the charger and close other apps to make it faster.")
                GuideStep(3, "Wait for STEMS READY", "Load the song again. When the deck header says \"stems ready\", the STEMS pads light up.")
                GuideStep(4, "Play with the parts", "Tap VOCAL, MELODY, BASS or DRUMS to mute or bring back that part. The SOLO pads keep just one part.")
                GuideStep(5, "Prepare before your gig", "Prepare your whole set at home. It is saved on the phone, so on stage every song loads instantly.")
                Row(
                    Modifier.fillMaxWidth().clickable { never = !never }.padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = never, onCheckedChange = { never = it })
                    Text("Don't show this guide again", color = TextGray, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(enabled = canPrep, onClick = {
                if (canPrep) {
                    PrepQueue.add(ctx, uri!!, d!!.curTitle, urgent = true)
                    Toast.makeText(ctx.applicationContext, "Preparing \"${d.curTitle}\" in the background", Toast.LENGTH_LONG).show()
                }
                close()
            }) { Text("PREPARE THIS SONG") }
        },
        dismissButton = { TextButton(onClick = { close() }) { Text("GOT IT") } }
    )
}

@Composable
private fun GuideStep(n: Int, title: String, body: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(24.dp).clip(CircleShape).background(DeckALight), contentAlignment = Alignment.Center) {
            Text("$n", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(body, color = TextGray, fontSize = 11.sp)
        }
    }
}
