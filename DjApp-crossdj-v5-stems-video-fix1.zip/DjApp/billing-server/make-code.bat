@echo off
title Make an activation code
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is not installed. Get the LTS version from https://nodejs.org then run this again. & pause & exit /b 1)
node scripts\make-code.js
echo.
pause
