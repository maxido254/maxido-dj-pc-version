@echo off
title MAXIDO billing server (keep this window open)
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is not installed. Get the LTS version from https://nodejs.org then run this again. & pause & exit /b 1)
where ngrok >nul 2>nul || (echo ngrok is not installed or not on PATH. Run:  winget install ngrok.ngrok  then try again. & pause & exit /b 1)
node scripts\ensure-ready.js || (pause & exit /b 1)
for /f "delims=" %%H in ('node --env-file=.env -p "new URL(process.env.PUBLIC_URL).host"') do set HOST=%%H
echo Opening the internet tunnel to https://%HOST% ...
start "ngrok tunnel (keep open)" ngrok http --url=%HOST% 8080
:loop
node --env-file=.env server.js
echo Server stopped. Restarting in 5 seconds (close this window to quit)...
timeout /t 5 >nul
goto loop
