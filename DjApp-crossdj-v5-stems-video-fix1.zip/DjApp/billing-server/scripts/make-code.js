'use strict';
// Makes an ACTIVATION CODE for one customer's phone. Works offline (no server, no internet): the app checks the code with your public key.
// Run it only AFTER you have seen the payment in your Paystack dashboard (Transactions).
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { execSync } = require('child_process');
const { signToken } = require('../src/crypto');

const root = path.join(__dirname, '..');
const keyFile = path.join(root, 'keys', 'token_private.pem');
const logFile = path.join(root, 'issued-codes.jsonl');
const MAX_PHONES_PER_PAYMENT = 3;                      // a payment may be moved to a new phone twice (lost / new phone)

if (!fs.existsSync(keyFile)) { console.log('keys\\token_private.pem not found. Run start-pc.bat once first, or copy your keys folder here.'); process.exit(1); }
const priv = fs.readFileSync(keyFile, 'utf8');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const lines = []; const waiters = [];
rl.on('line', (l) => { lines.push(l); const w = waiters.shift(); if (w) w(); });
const ask = (q) => new Promise((res) => { process.stdout.write(q); const take = () => res((lines.shift() || '').trim()); if (lines.length) take(); else waiters.push(take); });

(async () => {
  console.log('\nBEFORE you continue: open Paystack dashboard > Transactions and confirm the payment is there, marked');
  console.log('successful, for KSh 150 (or more), and that its reference matches what the customer sent.\n');
  const did = (await ask('Customer Phone ID (the long one from their WhatsApp message): ')).replace(/\s+/g, '').toLowerCase();
  const ref = (await ask('Paystack payment reference: ')).replace(/\s+/g, '');
  const days = await ask('Days of PRO [Enter = for life]: ');
  rl.close();
  if (!/^[0-9a-f]{64}$/.test(did)) { console.log('\nThe Phone ID must be the full 64 letters/numbers from the WhatsApp message (not the short 8-letter one). Nothing done.'); process.exit(1); }
  if (ref.length < 6) { console.log('\nThe payment reference looks too short. Nothing done.'); process.exit(1); }

  const issued = fs.existsSync(logFile) ? fs.readFileSync(logFile, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)) : [];
  const phonesForRef = new Set(issued.filter((e) => e.ref.toLowerCase() === ref.toLowerCase()).map((e) => e.did));
  if (phonesForRef.size && !phonesForRef.has(did) && phonesForRef.size >= MAX_PHONES_PER_PAYMENT) {
    console.log('\nSTOP: this payment reference was already used for ' + phonesForRef.size + ' different phones. Do not issue another code.'); process.exit(1);
  }
  if (phonesForRef.size && !phonesForRef.has(did)) console.log('\nNote: this payment was already used for another phone (' + phonesForRef.size + ' so far). Fine only if the customer changed phone.');

  const now = Math.floor(Date.now() / 1000);
  const exp = now + (/^\d+$/.test(days) && Number(days) > 0 ? Number(days) * 86400 : 3650 * 86400);
  const code = signToken(priv, { v: 1, did, feat: ['video', 'stems'], iat: now, exp, oid: 'paystack:' + ref });
  fs.appendFileSync(logFile, JSON.stringify({ ts: new Date().toISOString(), did, ref, exp }) + '\n');
  try { if (process.platform === 'win32') execSync('clip', { input: code }); } catch { /* clipboard is a convenience only */ }
  console.log('\nACTIVATION CODE (also copied to your clipboard on Windows). Paste it into WhatsApp and send it to the customer:\n');
  console.log(code + '\n');
  console.log('It only works on that one phone. Tell them: MAXIDO DJ > open a PRO feature > paste the code > ACTIVATE PRO.');
})();
