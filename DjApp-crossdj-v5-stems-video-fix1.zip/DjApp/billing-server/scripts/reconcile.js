'use strict';
// Matches the payment claims customers sent you (WhatsApp) against the transactions exported from your Paystack dashboard.
const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, '..', 'check');
const csvFile = path.join(dir, 'paystack.csv');
const claimsFile = path.join(dir, 'claims.txt');
if (!fs.existsSync(csvFile) || !fs.existsSync(claimsFile)) {
  console.log('Missing a file. Put paystack.csv and claims.txt in the "check" folder (see check\\README.txt).');
  process.exit(1);
}
const csvLines = fs.readFileSync(csvFile, 'utf8').split(/\r?\n/).filter(Boolean);
const text = fs.readFileSync(claimsFile, 'utf8');

// one block per customer message
const blocks = text.split(/(?=Hi,?\s+I paid for MAXIDO)/i).filter((b) => /Payment reference/i.test(b));
const claims = [];
for (const b of blocks) {
  const ref = (b.match(/Payment reference:\s*([A-Za-z0-9_-]{6,60})/i) || [])[1];
  const id = (b.match(/Phone ID:\s*([0-9a-fA-F]{64})/i) || [])[1];
  if (ref) claims.push({ ref, id: id ? id.toLowerCase() : '(no phone id)' });
}
if (!claims.length) { console.log('No claims found in claims.txt. Paste the customers\' WhatsApp messages there.'); process.exit(1); }

const byRef = new Map();
for (const c of claims) { const k = c.ref.toLowerCase(); if (!byRef.has(k)) byRef.set(k, new Set()); byRef.get(k).add(c.id); }

const out = []; const ok = [], missing = [], notPaid = [], shared = [];
for (const [k, ids] of byRef) {
  const ref = claims.find((c) => c.ref.toLowerCase() === k).ref;
  const hits = csvLines.filter((l) => l.toLowerCase().includes(k));
  const phones = [...ids].map((i) => i.slice(0, 8)).join(', ');
  if (!hits.length) missing.push(`${ref}   phone ${phones}`);
  else if (!hits.some((l) => /success/i.test(l))) notPaid.push(`${ref}   phone ${phones}   | ${hits[0].slice(0, 110)}`);
  else ok.push(`${ref}   phone ${phones}`);
  if (ids.size > 1) shared.push(`${ref}   used by ${ids.size} different phones: ${phones}`);
}
out.push(`CHECKED ${claims.length} claim(s) from ${byRef.size} distinct payment reference(s)\n`);
out.push(`OK, found in Paystack as successful (${ok.length}):`); out.push(...ok.map((x) => '   ' + x), '');
out.push(`NOT FOUND in Paystack: probably NOT PAID (${missing.length}):`); out.push(...missing.map((x) => '   ' + x), '');
out.push(`FOUND but not marked successful (${notPaid.length}):`); out.push(...notPaid.map((x) => '   ' + x), '');
out.push(`SAME REFERENCE USED BY MORE THAN ONE PHONE (${shared.length}): one payment shared, or a copied reference`); out.push(...shared.map((x) => '   ' + x), '');
const report = out.join('\n');
fs.writeFileSync(path.join(dir, 'reconcile-report.txt'), report);
console.log('\n' + report + '\n\n(also saved in check\\reconcile-report.txt)');
