'use strict';
// Runs before the server starts. If a payment key is needed but missing from .env, asks for it once (paste), never again.
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { setEnv } = require('./envfile');

const envFile = path.join(__dirname, '..', '.env');
if (!fs.existsSync(envFile)) { console.log('.env is missing. Run connect.bat first.'); process.exit(1); }
const env = Object.fromEntries(fs.readFileSync(envFile, 'utf8').split(/\r?\n/).filter((l) => l.includes('=')).map((l) => [l.slice(0, l.indexOf('=')), l.slice(l.indexOf('=') + 1)]));
if (env.PAYMENT_MODE !== 'live') process.exit(0);

const needPaystack = env.PAYSTACK_ENABLED === '1' && !env.PAYSTACK_SECRET_KEY;
const needDaraja = env.MPESA_ENABLED !== '0' && !(env.MPESA_KEY && env.MPESA_SECRET);
if (!needPaystack && !needDaraja) process.exit(0);

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const lines = []; const waiters = [];
rl.on('line', (l) => { lines.push(l); const w = waiters.shift(); if (w) w(); });
const ask = (q) => new Promise((res) => { process.stdout.write(q); const take = () => res((lines.shift() || '').trim()); if (lines.length) take(); else waiters.push(take); });

(async () => {
  if (needPaystack) {
    console.log('\nOne-time step: paste your Paystack TEST key (the restricted key you created, or the Test secret key).');
    const key = await ask('Paystack key (starts with rk_test_ or sk_test_): ');
    rl.close();
    if (!/^(sk|rk)_(test|live)_[A-Za-z0-9]{20,}$/.test(key)) { console.log('\nThat is not a Paystack secret/restricted key (it should start with rk_test_, sk_test_ or the live versions). Do NOT use the pk_ one.'); process.exit(1); }
    setEnv(envFile, { PAYSTACK_SECRET_KEY: key });
    console.log('\nSaved. You will not be asked again.\n');
    return;
  }
  console.log('\nOne-time step: paste your Safaricom LIVE keys (portal > My Apps > your app > the copy buttons).\n');
  const key = await ask('Consumer Key: ');
  const secret = await ask('Consumer Secret: ');
  rl.close();
  if (!/^[A-Za-z0-9]{20,100}$/.test(key) || !/^[A-Za-z0-9]{20,100}$/.test(secret)) { console.log('\nThat does not look right. Use the copy buttons and try again.'); process.exit(1); }
  setEnv(envFile, { MPESA_KEY: key, MPESA_SECRET: secret });
  console.log('\nSaved. You will not be asked again.\n');
})();
