# MAXIDO billing server

Takes the KSh 150 payment (or the same value in the customer's currency), checks it with the payment provider, and
hands the app a signed, phone-bound token that switches on **video mixing** and **stem separation**.
No dependencies, Node 20 or newer. 13 automated tests: `npm test`.

## What makes it hard to cheat

| Attack | Why it fails |
|---|---|
| "I paid" without paying | A payment only counts when **this server** asks Safaricom / Flutterwave and they say paid. Webhooks are just a nudge to go and ask. |
| Change the price or currency | The server decides the amount when the order is created. The phone only says which method. |
| Pay less / wrong currency | Amount and currency from the provider must match the order, otherwise nothing unlocks. |
| Fake or replayed requests | Every request is signed by the phone's own Android Keystore key, valid once, for 5 minutes. |
| Copy a token to another phone | The token names one phone id; the app rejects any other. |
| Make up a token | Only the server's private key can sign one; the app holds just the public key. |
| Reuse one M-Pesa receipt twice | A receipt can unlock one order only. |
| Wind the phone clock back | The app never trusts a time earlier than the latest it has seen. |
| Edit the billing records | Every ledger line is chained with a secret HMAC. Changing, removing or reordering a line is detected and the server **refuses to start**. |
| Share one payment with friends | One payment can be moved across at most `MAX_DEVICES` phones, and the old phone is switched off. |

**What no server can stop:** someone who rewrites the APK itself and removes the checks. The app does the checks in
several places and the server logs everything, but that is a speed bump, not a wall. The real protection is that the
server only ever unlocks paid phones and the ledger shows exactly who paid.
Also: truncating the *end* of the ledger file cannot be seen from the file alone. Once a week copy `GET /admin/head`
(sequence number and hash) somewhere else; if the server's head ever has a lower sequence number, someone cut it.

## Setup

1. **Keys.** `npm run keys` creates `keys/token_private.pem` (back it up, never share it) and prints the **public key**
   plus `LEDGER_KEY`, `ADMIN_TOKEN`, `MPESA_CALLBACK_SECRET`. If you lose the private key, every paid phone must be re-issued.
2. **Try it with fake money first.**
   `PAYMENT_MODE=mock ... node server.js` (local trial only; the default is `live`)
   Mock mode has a `/mock/pay/<orderId>` button that pretends to pay. It does not exist in live mode.
3. **App.** In `Billing.kt` set `SERVER_URL` (https) and `SERVER_PUBLIC_KEY` (from step 1), then build.
4. **M-Pesa (Kenya).** Create an app on the Safaricom Daraja portal, get key, secret, passkey and your shortcode.
   Test in `sandbox`; to take real money apply for **Go Live** (needs your paybill or till). Put the values in `.env`.
   The callback address is built for you: `PUBLIC_URL/hook/stk/MPESA_CALLBACK_SECRET`.
5. **Other countries / currencies.** Create a Flutterwave account (needs business verification), set a webhook to
   `PUBLIC_URL/hook/flw` with a secret hash, and put the secret key and that hash in `.env`.
6. **Run it** somewhere with **https** and a **disk that survives restarts** (a small VPS is fine). Many free hosting tiers
   wipe the disk on restart, which would erase every customer's payment: do not use those for `DATA_DIR`.
   Put Caddy or nginx in front for https and set `TRUST_PROXY=1`.

## Pricing

`PRICE_KES` (150) is the only price. M-Pesa always charges KSh 150. Card / mobile money payers are charged the same
value converted at the live rate (cached 12 h, `open.er-api.com`), rounded **up** to a tidy number (about US$1.20, or
4,220 UGX at the time of writing the tests). Currencies Flutterwave cannot take fall back to USD. If the rate service is
down, an approximate built-in table is used and the quote is flagged.

## Customer support

* Phone lost / reinstalled: app > Settings > PRO > "Restore" with the M-Pesa SMS receipt code and the paying number.
* Callback never arrived and the customer has no receipt on file: `POST /admin/grant {deviceId, note, days}` (Phone ID is
  shown in Settings > PRO). Grants appear in the ledger.
* Refund / chargeback: `POST /admin/revoke {orderId, reason}`. The phone loses PRO at its next lease renewal
  (within `LEASE_DAYS`).
* Look at payments: `GET /admin/orders`. Check the ledger: `GET /admin/verify`. All admin calls need
  `Authorization: Bearer <ADMIN_TOKEN>`.

## API (for reference)

Unsigned: `GET /v1/config`, `GET /v1/quote?cc=KE&cur=KES`, `GET /health`.
Signed by the phone: `POST /v1/register`, `/v1/checkout`, `/v1/entitlement`, `/v1/restore`, `GET /v1/order/:id`.
Signature = ECDSA P-256/SHA-256 (DER, base64) over `METHOD \n path \n ts \n nonce \n sha256hex(body)`, sent as
`X-Device`, `X-Ts`, `X-Nonce`, `X-Sig`.

## Unlocking by hand (Pochi / Send Money)

1. Customer taps WHATSAPP US MY PHONE ID in the app, you reply with your Pochi / M-Pesa number, they pay.
2. YOU confirm in your own M-Pesa app or statement that the money arrived and the receipt code matches (a screenshot proves nothing).
3. Double-click `grant.bat`, enter the Phone ID and the receipt code. The same receipt code cannot unlock two phones.
4. Customer opens the app online and taps CHECK PRO NOW.

## Paystack (no till needed)

Set `PAYSTACK_SECRET_KEY` (Paystack dashboard > Settings > API Keys & Webhooks; `sk_test_` for fake money, `sk_live_` for real).
The server creates one Paystack checkout per order (price fixed by the server) and confirms it by calling Paystack's verify API;
a webhook is only a hint. Optional webhook URL: `PUBLIC_URL/hook/paystack`. Money settles to the bank / M-PESA wallet you set in Paystack.
Test mode needs no verification; live mode needs Paystack to approve your account.
