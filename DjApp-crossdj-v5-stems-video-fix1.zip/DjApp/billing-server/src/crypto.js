'use strict';
const crypto = require('crypto');

const b64u = (buf) => Buffer.from(buf).toString('base64url');
const sha256hex = (data) => crypto.createHash('sha256').update(data).digest('hex');

/** Device id = SHA-256 of the phone's public key (SPKI DER). The app computes the same value. */
function deviceIdOf(pubB64) {
  return sha256hex(Buffer.from(pubB64, 'base64'));
}

/** Parses a phone's public key. Only EC P-256 keys are accepted (what Android Keystore makes everywhere). */
function parseDevicePublicKey(pubB64) {
  if (typeof pubB64 !== 'string' || pubB64.length < 60 || pubB64.length > 400) throw new Error('bad key');
  const key = crypto.createPublicKey({ key: Buffer.from(pubB64, 'base64'), format: 'der', type: 'spki' });
  if (key.asymmetricKeyType !== 'ec' || key.asymmetricKeyDetails.namedCurve !== 'prime256v1') throw new Error('key must be EC P-256');
  return key;
}

/** What the phone signs for every request. */
function requestMessage(method, pathAndQuery, ts, nonce, body) {
  return `${method}\n${pathAndQuery}\n${ts}\n${nonce}\n${sha256hex(body)}`;
}

function verifyDeviceSignature(pubB64, message, sigB64) {
  try {
    const key = parseDevicePublicKey(pubB64);
    return crypto.verify('sha256', Buffer.from(message), key, Buffer.from(sigB64, 'base64'));   // DER, as Android produces
  } catch { return false; }
}

/** token = base64url(JSON payload) "." base64url(ECDSA-P256-SHA256 DER signature over the first part's ASCII bytes) */
function signToken(privateKeyPem, payload) {
  const p = b64u(JSON.stringify(payload));
  const sig = crypto.sign('sha256', Buffer.from(p), crypto.createPrivateKey(privateKeyPem));
  return p + '.' + b64u(sig);
}

function publicKeyB64(privateKeyPem) {
  return crypto.createPublicKey(crypto.createPrivateKey(privateKeyPem)).export({ type: 'spki', format: 'der' }).toString('base64');
}

function safeEqual(a, b) {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

module.exports = { b64u, sha256hex, deviceIdOf, parseDevicePublicKey, requestMessage, verifyDeviceSignature, signToken, publicKeyB64, safeEqual };
