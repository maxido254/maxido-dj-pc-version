'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

/** Deterministic JSON (sorted keys) so a hash always covers exactly the same bytes. */
function canon(o) {
  if (o === null || typeof o !== 'object') return JSON.stringify(o);
  if (Array.isArray(o)) return '[' + o.map(canon).join(',') + ']';
  return '{' + Object.keys(o).sort().map(k => JSON.stringify(k) + ':' + canon(o[k])).join(',') + '}';
}

/**
 * Append-only, hash-chained billing ledger. Every line carries an HMAC (secret key) over the previous line's
 * hash plus its own content, so editing, deleting or re-ordering any past line breaks every line after it
 * and is detected on start-up and by /admin/verify. Truncating the END of the file cannot be seen from the
 * file alone: copy the head hash (/admin/head) somewhere off the server now and then.
 */
class Ledger {
  constructor(file, key) {
    this.file = file;
    this.key = Buffer.from(key);
    this.seq = 0;
    this.head = 'GENESIS';
    fs.mkdirSync(path.dirname(file), { recursive: true });
  }
  static mac(key, prev, body) {
    return crypto.createHmac('sha256', key).update(prev + '|' + canon(body)).digest('hex');
  }
  /** Reads and verifies the whole file. Returns the entries; throws if the chain is broken. */
  static verifyFile(file, key) {
    const out = [];
    if (!fs.existsSync(file)) return { entries: out, head: 'GENESIS' };
    const k = Buffer.from(key);
    let prev = 'GENESIS';
    const lines = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean);
    lines.forEach((line, i) => {
      let e;
      try { e = JSON.parse(line); } catch { throw new Error(`ledger line ${i + 1} is not valid JSON`); }
      if (e.seq !== i + 1) throw new Error(`ledger line ${i + 1}: sequence number is ${e.seq}`);
      if (e.prev !== prev) throw new Error(`ledger line ${i + 1}: chain is broken (previous hash differs)`);
      const want = Ledger.mac(k, prev, { seq: e.seq, ts: e.ts, type: e.type, data: e.data });
      const a = Buffer.from(want), b = Buffer.from(String(e.hash));
      if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) throw new Error(`ledger line ${i + 1}: content was changed`);
      prev = e.hash;
      out.push(e);
    });
    return { entries: out, head: prev };
  }
  load() {
    const { entries, head } = Ledger.verifyFile(this.file, this.key);
    this.seq = entries.length;
    this.head = head;
    return entries;
  }
  append(type, data) {
    const body = { seq: this.seq + 1, ts: Date.now(), type, data };
    const hash = Ledger.mac(this.key, this.head, body);
    const entry = { ...body, prev: this.head, hash };
    const fd = fs.openSync(this.file, 'a', 0o600);
    try { fs.writeSync(fd, JSON.stringify(entry) + '\n'); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
    this.seq = body.seq;
    this.head = hash;
    return entry;
  }
}
module.exports = { Ledger, canon };
