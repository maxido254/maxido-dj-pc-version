import org.jetbrains.compose.desktop.application.dsl.TargetFormat
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

plugins {
    kotlin("jvm") version "1.9.24"
    id("org.jetbrains.compose") version "1.6.11"
}

kotlin { jvmToolchain(17) }

dependencies {
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    implementation("net.java.dev.jna:jna:5.14.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.8.1")
    // AI stem separation (SCNet, same model as the phone app) on the CPU: ONNX Runtime uses AVX-512 / VNNI on Ryzen 7040 chips
    implementation("com.microsoft.onnxruntime:onnxruntime:1.19.2")
    // Video: FFmpeg through JavaCV decodes the pictures, extracts sound from video files and encodes the recorded video mix
    val osName = System.getProperty("os.name").lowercase()
    val nativeCls = if (osName.contains("win")) "windows-x86_64" else if (osName.contains("mac")) "macosx-arm64" else "linux-x86_64"
    implementation("org.bytedeco:javacv:1.5.10")
    implementation("org.bytedeco:javacpp:1.5.10:$nativeCls")
    implementation("org.bytedeco:ffmpeg:6.1.1-1.5.10")
    implementation("org.bytedeco:ffmpeg:6.1.1-1.5.10:$nativeCls")
}

// ---- SCNet model (MIT licence): downloaded once at build time into resources/common/models, shipped inside the installer
val scnetFile = "scnet-large.int8.onnx"
val scnetUrl = "https://huggingface.co/audiojs/scnet-large/resolve/main/scnet-large.int8.onnx"
val scnetSha = "b2dc586a1e0e6c0afe4915e9057ea29111397b7bbf589edc3d85de91de79cd72"
val fetchScnetModel by tasks.registering {
    val dir = layout.projectDirectory.dir("resources/common/models").asFile
    outputs.dir(dir)
    doLast {
        dir.mkdirs()
        val target = File(dir, scnetFile)
        if (target.exists() && target.length() > 20_000_000L) return@doLast
        val part = File(dir, "$scnetFile.part")
        val conn = URL(scnetUrl).openConnection() as HttpURLConnection
        conn.connectTimeout = 30_000; conn.readTimeout = 60_000; conn.instanceFollowRedirects = true
        conn.inputStream.use { i -> part.outputStream().use { o -> i.copyTo(o) } }
        val md = MessageDigest.getInstance("SHA-256")
        part.inputStream().use { i -> val buf = ByteArray(1 shl 16); while (true) { val n = i.read(buf); if (n < 0) break; md.update(buf, 0, n) } }
        val got = md.digest().joinToString("") { "%02x".format(it) }
        check(got == scnetSha) { "SCNet model checksum mismatch (got $got)" }
        check(part.renameTo(target)) { "could not move the model into place" }
    }
}
tasks.matching { it.name == "prepareAppResources" }.configureEach { dependsOn(fetchScnetModel) }

compose.desktop {
    application {
        mainClass = "com.example.djapp.MainKt"
        nativeDistributions {
            // djengine.dll (built by CMake, see ../.github/workflows/windows.yml) is copied into resources/windows-x64/ and ships inside the installer
            appResourcesRootDir.set(project.layout.projectDirectory.dir("resources"))
            targetFormats(TargetFormat.Msi, TargetFormat.Exe, TargetFormat.Dmg, TargetFormat.Deb)
            packageName = "MAXIDO DJ"
            packageVersion = "1.0.0"
            vendor = "Maxido Ent."
            description = "MAXIDO DJ for PC - free"
            windows {
                menuGroup = "MAXIDO DJ"
                perUserInstall = true
                shortcut = true
                upgradeUuid = "4d2c1b58-8a6e-4f0e-9a43-6b1f3c0f5e11"
            }
        }
    }
}
