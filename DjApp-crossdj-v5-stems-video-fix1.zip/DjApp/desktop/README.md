# MAXIDO DJ for PC (free)

Windows / macOS / Linux desktop version. Same C++ audio engine as the Android app (decks, key-lock tempo, EQ, filter, BASS AMP,
limiter, REC), with a Compose Desktop screen. No paywall, no server: everything is unlocked.

## Get the installer (no Windows PC or developer tools needed)
Push this project to GitHub, open Actions > "Build Windows (free PC app)" > Run workflow, then download the `MAXIDO-DJ-Windows` artifact
(a .msi and an .exe installer).

## Build it yourself on Windows
1. Install Visual Studio Build Tools (C++), CMake, JDK 17.
2. `cmake -S ..\app\src\main\cpp -B build -A x64 && cmake --build build --config Release`
3. Copy `build\Release\djengine.dll` to `resources\windows-x64\`
4. `gradle run` (or `gradle packageMsi`)

## Stems, video mixing, video recording
* **Stems**: VOCAL / DRUMS / BASS / MELODY buttons, ACAPELLA, NO VOCALS, BEATLESS. AUTO STEMS (mixer panel) separates each track in the background with the
  AI model (SCNet-large, int8, the same one as the phone app) and swaps the deck over without a gap. It uses 10 threads when no deck is playing and 4 while one
  plays, which suits a 6-core / 12-thread Ryzen 5 7640HS (AVX-512 + VNNI). Stems are cached in `~/.maxido-dj/cache`. The model (45 MB) is downloaded by Gradle at build time.
* **Video mixer** (VIDEO button): VIDEO + SOUND loads a video file as the track (picture locked to the deck), SILENT LOOP adds a picture-only clip.
  Blend / dip to black / cut, crossfader or manual, OUTPUT WINDOW for a projector or TV (double-click = full screen).
* **REC VIDEO MIX**: records exactly what the preview shows plus the master sound (bass amp and limiter included) to `Videos\MAXIDO DJ\*.mp4`
  (H.264 + AAC when the bundled FFmpeg has an H.264 encoder, otherwise MPEG-4 + AAC). REC (audio only) still saves a WAV.

Supported audio: MP3, WAV, FLAC (fast built-in decoder), OGG, M4A, AAC and video files (FFmpeg). Recordings go to Music\MAXIDO DJ.

## Layout, library and keeping the laptop cool
* **Layout**: waveform strips on top, deck A | mixer | deck B in the middle, library at the bottom. Mixer: TREBLE / MID / BASS / FILTER knobs (drag up/down, double-click resets), channel faders, master, BASS AMP, crossfader.
* **Library**: folders on the left (Music and Videos are added automatically, `+ ADD FOLDER` adds more), search box, sortable columns (Title, Artist, Length, BPM, Key). Double-click a track = load on a free deck; the **A** / **B** buttons load on a chosen deck.
  `ANALYZE ALL` fills in BPM, key and length one track at a time with short rests (the decoded copy is deleted afterwards). Results are remembered in `~/.maxido-dj/library.tsv`.
* **Heat**: the AI stem separation is the heaviest job. `STEMS CPU` in the top bar: **ECO** (2 threads + rests, default), **BALANCED**, **FAST**. AUTO STEMS is off by default: press PREPARE STEMS on the deck you need.
  ONNX Runtime spin-waiting is switched off, so idle worker threads no longer burn 100 % of a core.
