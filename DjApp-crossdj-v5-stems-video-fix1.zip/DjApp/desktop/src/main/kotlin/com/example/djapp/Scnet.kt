package com.example.djapp

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * AI stem separation: SCNet (Sparse Compression Network, MIT licence) exported to ONNX with int8 weights, run on the
 * phone's CPU, fully offline. The large model is only ~45 MB (HT-Demucs was ~166 MB and ran out of memory on 4 GB phones such
 * as the Itel A80). It ships inside the APK (assets/scnet-large.int8.onnx, fetched at build time by the `fetchScnetModel`
 * Gradle task) and is unpacked once into app storage on first use.
 *
 * The ONNX file contains only the network between the STFT and the inverse STFT, so [ScnetDsp] does both transforms here.
 * Any failure (model missing, out of memory, ...) returns false so the caller can fall back.
 */
class ScnetSeparator(private val modelDir: File, private val threads: Int = 10, private val overlapDiv: Int = 4,
                     private val status: (String) -> Unit = {}) : StemSeparator {
    override val id = "scnet"
    // Desktop: always the large network (best quality). A Ryzen 5 7640HS (6 cores / 12 threads, AVX-512 + VNNI) runs the int8 model comfortably.
    private val lowMem = false
    private val minimal = false
    private val large = true
    private val modelName: String get() = MODEL_LARGE

    private companion object {
        const val TAG = "ScnetSeparator"
        const val MODEL_LARGE = "scnet-large.int8.onnx"     // ~45 MB
        const val MIN_MODEL_BYTES = 5_000_000L
        const val SEG = ScnetDsp.SEG          // samples per model segment @ 44.1 kHz (11 s)
        const val MODEL_RATE = 44100
        // model output order is drums, bass, other, vocals; the app wants vocals, drums, bass, other
        val MODEL_INDEX = intArrayOf(3, 0, 1, 2)
    }

    override fun separate(mix: File, rate: Int, outDir: File, progress: (Float) -> Unit, cancelled: () -> Boolean): Boolean {
        return try {
            doSeparate(mix, rate, outDir, progress, cancelled)
        } catch (t: Throwable) {
            System.err.println("$TAG: AI separation failed: $t")
            try { status("ERROR " + t.javaClass.simpleName + ": " + (t.message ?: "").take(160)) } catch (_: Throwable) {}
            false
        }
    }

    /** The model ships inside the installer (resources/common/models) and is fetched at build time by Gradle. */
    private fun ensureModel(progress: (Float) -> Unit, cancelled: () -> Boolean): File? {
        val f = File(modelDir, modelName)
        return if (f.exists() && f.length() > MIN_MODEL_BYTES) f else null
    }

    private fun resample(src: FloatArray, srcLen: Int, dstLen: Int): FloatArray {
        val out = FloatArray(dstLen)
        if (srcLen == dstLen) { System.arraycopy(src, 0, out, 0, dstLen); return out }
        val ratio = (srcLen - 1).toDouble() / max(dstLen - 1, 1)
        for (i in 0 until dstLen) {
            val x = i * ratio
            val i0 = x.toInt()
            val fr = (x - i0).toFloat()
            val i1 = min(i0 + 1, srcLen - 1)
            out[i] = src[i0] * (1f - fr) + src[i1] * fr
        }
        return out
    }

    private fun doSeparate(mix: File, rate: Int, outDir: File, progress: (Float) -> Unit, cancelled: () -> Boolean): Boolean {
        status("starting")
        val model = ensureModel(progress, cancelled)
        if (model == null) { status("ERROR model file missing or could not be unpacked"); return false }
        if (cancelled()) return false

        val totalFrames = mix.length() / 4
        if (totalFrames < 1) return false

        // Pass 1: level statistics of the mono mix (the model was run on input normalised by them).
        var sum = 0.0; var sumSq = 0.0
        RandomAccessFile(mix, "r").use { raf ->
            val bytes = ByteArray(65536 * 4)
            while (true) {
                val n = raf.read(bytes)
                if (n < 4) break
                val sb = ByteBuffer.wrap(bytes, 0, n - n % 4).order(ByteOrder.nativeOrder()).asShortBuffer()
                var i = 0
                while (i + 1 < sb.limit()) {
                    val m = (sb.get(i) + sb.get(i + 1)) * 0.5 / 32768.0
                    sum += m; sumSq += m * m
                    i += 2
                }
            }
        }
        val mean = sum / totalFrames
        val std = max(sqrt(max(sumSq / totalFrames - mean * mean, 0.0)), 1e-4).toFloat()
        val meanF = mean.toFloat()

        val env = OrtEnvironment.getEnvironment()
        val opts = OrtSession.SessionOptions()
        opts.setIntraOpNumThreads(threads.coerceIn(1, Runtime.getRuntime().availableProcessors()))
        if (lowMem) {   // trade a little speed for a much smaller memory footprint
            try { opts.setMemoryPatternOptimization(false) } catch (_: Throwable) {}
            try { opts.setCPUArenaAllocator(false) } catch (_: Throwable) {}
            try { opts.setExecutionMode(OrtSession.SessionOptions.ExecutionMode.SEQUENTIAL) } catch (_: Throwable) {}
            try { opts.addConfigEntry("session.disable_prepacking", "1") } catch (_: Throwable) {}      // no duplicate copy of the weights
            try { opts.addConfigEntry("session.intra_op.allow_spinning", "0") } catch (_: Throwable) {}
        }
        if (minimal) {  // last resort for the weakest phones: 1 thread, lightest graph optimisation
            try { opts.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.BASIC_OPT) } catch (_: Throwable) {}
        }
        status("loading " + (if (large) "large" else "small") + " model (" + (model.length() / 1_000_000) + " MB)")
        val tLoad = System.currentTimeMillis()
        val session = env.createSession(model.absolutePath, opts)
        status("model loaded in " + (System.currentTimeMillis() - tLoad) / 1000 + " s")
        val inputName = session.inputNames.iterator().next()

        val dsp = ScnetDsp()
        val specBuf: FloatBuffer = ByteBuffer.allocateDirect(ScnetDsp.IN_FLOATS * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        val inShape = longArrayOf(1, 4, ScnetDsp.BINS.toLong(), ScnetDsp.FRAMES.toLong())

        val ms = max(1, Math.round(SEG.toDouble() * rate / MODEL_RATE).toInt())   // segment length in source frames
        val os = ms / overlapDiv.coerceIn(2, 8)                                    // overlap (source frames)
        val stride = ms - os
        val tail = Array(4) { FloatArray(2 * os) }
        val nSeg = if (totalFrames <= ms) 1 else ((totalFrames - ms + stride - 1) / stride).toInt() + 1
        val outs = STEM_NAMES.map { BufferedOutputStream(File(outDir, "$it.pcm").outputStream(), 256 * 1024) }
        var ok = false
        try {
            RandomAccessFile(mix, "r").use { raf ->
                val inBytes = ByteArray(ms * 4)
                var p = 0L
                var k = 0
                while (true) {
                    if (cancelled()) return false
                    val isLast = p + ms >= totalFrames
                    val valid = min(ms.toLong(), totalFrames - p).toInt()

                    // read + de-interleave (zero padded)
                    raf.seek(p * 4)
                    java.util.Arrays.fill(inBytes, 0)
                    var read = 0
                    while (read < valid * 4) {
                        val n = raf.read(inBytes, read, valid * 4 - read)
                        if (n < 0) break
                        read += n
                    }
                    val sb = ByteBuffer.wrap(inBytes).order(ByteOrder.nativeOrder()).asShortBuffer()
                    val l = FloatArray(ms); val r = FloatArray(ms)
                    for (i in 0 until valid) { l[i] = sb.get(2 * i) / 32768f; r[i] = sb.get(2 * i + 1) / 32768f }
                    val lm = resample(l, ms, SEG); val rm = resample(r, ms, SEG)
                    for (i in 0 until SEG) { lm[i] = (lm[i] - meanF) / std; rm[i] = (rm[i] - meanF) / std }

                    dsp.stft(lm, rm, specBuf)

                    val y = Array(4) { arrayOf(FloatArray(ms), FloatArray(ms)) }
                    status("chunk " + (k + 1) + "/" + nSeg + " running")
                    val tChunk = System.currentTimeMillis()
                    val tensor = OnnxTensor.createTensor(env, specBuf, inShape)
                    try {
                        session.run(mapOf(inputName to tensor)).use { res ->
                            val outT = res.get(0) as OnnxTensor
                            val fbuf = outT.floatBuffer
                            if (fbuf.remaining() < ScnetDsp.OUT_FLOATS)
                                throw IllegalStateException("unexpected SCNet output size ${fbuf.remaining()}")
                            val ol = FloatArray(SEG); val orr = FloatArray(SEG)
                            for (s in 0 until 4) {
                                dsp.istft(fbuf, MODEL_INDEX[s] * 4, ol, orr)
                                for (i in 0 until SEG) { ol[i] *= std; orr[i] *= std }
                                y[s][0] = resample(ol, SEG, ms)
                                y[s][1] = resample(orr, SEG, ms)
                            }
                        }
                    } finally { tensor.close() }
                    status("chunk " + (k + 1) + "/" + nSeg + " done, " + (System.currentTimeMillis() - tChunk) / 1000 + " s each")

                    // overlap-add and write
                    val emit = if (isLast) valid else stride
                    var i0 = 0
                    val ob = Array(4) { ByteBuffer.allocate(4 * 4096).order(ByteOrder.nativeOrder()) }
                    while (i0 < emit) {
                        val cnt = min(4096, emit - i0)
                        for (s in 0 until 4) {
                            ob[s].clear()
                            for (j in 0 until cnt) {
                                val i = i0 + j
                                var vl = y[s][0][i]; var vr = y[s][1][i]
                                if (k > 0 && i < os) {
                                    val w = i.toFloat() / os
                                    vl = vl * w + tail[s][i]
                                    vr = vr * w + tail[s][os + i]
                                }
                                ob[s].putShort(toShort(vl)); ob[s].putShort(toShort(vr))
                            }
                            outs[s].write(ob[s].array(), 0, cnt * 4)
                        }
                        i0 += cnt
                    }
                    if (!isLast) {
                        for (s in 0 until 4) for (i in 0 until os) {
                            val w = 1f - i.toFloat() / os
                            tail[s][i] = y[s][0][stride + i] * w
                            tail[s][os + i] = y[s][1][stride + i] * w
                        }
                    }
                    p += stride
                    k++
                    progress(0.05f + 0.95f * (min(p, totalFrames).toFloat() / totalFrames))
                    if (isLast) break
                }
            }
            ok = true
        } finally {
            outs.forEach { try { it.close() } catch (_: Exception) {} }
            try { session.close() } catch (_: Exception) {}
            try { opts.close() } catch (_: Exception) {}
        }
        return ok
    }

    private fun toShort(v: Float): Short {
        val x = Math.round(v * 32768f)
        return (if (x > 32767) 32767 else if (x < -32768) -32768 else x).toShort()
    }
}

/**
 * The transforms around the SCNet network (same as `torch.stft / torch.istft` in the reference implementation):
 * n_fft 4096, hop 1024, rectangular window, scaled by 1/sqrt(n_fft), centred with reflect padding.
 * One 11 s segment (485 100 samples) is zero-padded to 486 400 samples = 476 frames x 2049 bins.
 * Network tensors are laid out as [channel][bin][frame] with channels L-re, L-im, R-re, R-im (x4 stems on the output).
 */
class ScnetDsp {
    companion object {
        const val SEG = 485100
        const val N = 4096
        const val HOP = 1024
        const val BINS = N / 2 + 1
        const val FRAMES = 476
        const val PADDED = (FRAMES - 1) * HOP                 // 486400: segment after zero padding
        const val IN_FLOATS = 4 * BINS * FRAMES
        const val OUT_FLOATS = 16 * BINS * FRAMES
        private const val PLANE = BINS * FRAMES
        private const val EXT = PADDED + N                     // padded signal incl. N/2 reflect on both sides
    }

    private val scale = 1f / sqrt(N.toFloat())
    private val cosT = FloatArray(N / 2) { Math.cos(2 * Math.PI * it / N).toFloat() }
    private val sinT = FloatArray(N / 2) { Math.sin(2 * Math.PI * it / N).toFloat() }
    private val rev = IntArray(N).also { t ->
        val bits = Integer.numberOfTrailingZeros(N)
        for (i in 0 until N) { var x = i; var r = 0; for (b in 0 until bits) { r = (r shl 1) or (x and 1); x = x shr 1 }; t[i] = r }
    }
    private val re = FloatArray(N)
    private val im = FloatArray(N)
    private val ext = Array(2) { FloatArray(EXT) }
    private val acc = Array(2) { FloatArray(EXT) }
    private val planes = Array(4) { FloatArray(PLANE) }
    /** 1 / (number of frames that cover each output sample): torch.istft divides by the window envelope. */
    private val envInv = FloatArray(SEG) { i ->
        val pe = i + N / 2
        val tMin = max(0, (pe - N + HOP) / HOP)            // ceil((pe - (N-1)) / HOP), clamped at the first frame
        val tMax = min(FRAMES - 1, pe / HOP)
        1f / (tMax - tMin + 1)
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        for (i in 0 until N) { val j = rev[i]; if (j > i) { var t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t } }
        var len = 2
        while (len <= N) {
            val half = len shr 1; val step = N / len
            var i = 0
            while (i < N) {
                var k = 0
                for (j in i until i + half) {
                    val wr = cosT[k]; val wi = -sinT[k]; k += step
                    val xr = re[j + half]; val xi = im[j + half]
                    val vr = xr * wr - xi * wi; val vi = xr * wi + xi * wr
                    re[j + half] = re[j] - vr; im[j + half] = im[j] - vi
                    re[j] += vr; im[j] += vi
                }
                i += len
            }
            len = len shl 1
        }
    }

    /** [l] and [r] hold SEG normalised samples. Fills [out] (IN_FLOATS floats) with the spectrogram for the network. */
    fun stft(l: FloatArray, r: FloatArray, out: FloatBuffer) {
        val src = arrayOf(l, r)
        for (c in 0..1) {
            val x = src[c]; val e = ext[c]
            // zero padded to PADDED, then reflect padding of N/2 on both sides (torch.stft centre=True, pad_mode="reflect")
            for (j in 0 until EXT) {
                var q = j - N / 2
                if (q < 0) q = -q else if (q >= PADDED) q = 2 * (PADDED - 1) - q
                e[j] = if (q < SEG) x[q] else 0f
            }
        }
        val el = ext[0]; val er = ext[1]
        for (t in 0 until FRAMES) {
            val base = t * HOP
            System.arraycopy(el, base, re, 0, N)       // two real signals in one complex FFT: L = real part, R = imaginary part
            System.arraycopy(er, base, im, 0, N)
            fft(re, im)
            for (k in 0 until BINS) {
                val j = (N - k) and (N - 1)
                val a = re[k]; val b = im[k]; val c = re[j]; val d = im[j]
                val o = k * FRAMES + t
                out.put(o, (a + c) * 0.5f * scale)                  // L re
                out.put(PLANE + o, (b - d) * 0.5f * scale)          // L im
                out.put(2 * PLANE + o, (b + d) * 0.5f * scale)      // R re
                out.put(3 * PLANE + o, (c - a) * 0.5f * scale)      // R im
            }
        }
    }

    /**
     * Turns one stem of the network output back into audio. [net] is the network's output tensor (16 channels),
     * [chBase] the first of that stem's 4 channels. Writes SEG samples per channel into [outL] / [outR].
     */
    fun istft(net: FloatBuffer, chBase: Int, outL: FloatArray, outR: FloatArray) {
        for (c in 0 until 4) {
            net.position((chBase + c) * PLANE)
            net.get(planes[c], 0, PLANE)
        }
        java.util.Arrays.fill(acc[0], 0f); java.util.Arrays.fill(acc[1], 0f)
        val aL = acc[0]; val aR = acc[1]
        val lr = planes[0]; val li = planes[1]; val rr = planes[2]; val ri = planes[3]
        for (t in 0 until FRAMES) {
            // Z = X_L + i X_R, using the conjugate symmetry of real signals; DC and Nyquist are real (as in irfft)
            for (k in 0 until BINS) {
                val o = k * FRAMES + t
                val a = lr[o]; val b = if (k == 0 || k == N / 2) 0f else li[o]
                val c = rr[o]; val d = if (k == 0 || k == N / 2) 0f else ri[o]
                re[k] = a - d; im[k] = b + c
                if (k in 1 until N / 2) { re[N - k] = a + d; im[N - k] = c - b }
            }
            fft(im, re)                                     // inverse FFT via the swap trick: re / im now hold N * (L / R)
            val base = t * HOP
            for (n in 0 until N) { aL[base + n] += re[n] * scale; aR[base + n] += im[n] * scale }
        }
        for (i in 0 until SEG) { outL[i] = aL[i + N / 2] * envInv[i]; outR[i] = aR[i + N / 2] * envInv[i] }
    }
}
