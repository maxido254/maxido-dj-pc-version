package com.example.djapp

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.Semaphore

private val lib get() = Native_.lib

/** Cache of decoded tracks (raw 16-bit stereo), so a track is only decoded once. */
object TrackCache {
    val dir: File = File(System.getProperty("user.home"), ".maxido-dj/cache").apply { mkdirs() }
    fun rawFor(src: File): File {
        val h = MessageDigest.getInstance("MD5").digest("${src.absolutePath}|${src.length()}|${src.lastModified()}".toByteArray())
            .joinToString("") { "%02x".format(it) }
        return File(dir, "$h.raw")
    }
}

object Decks {
    val a = DeckModel(0)
    val b = DeckModel(1)
    val c = DeckModel(2)                                  // decks C and D: audio only (the video mixer has two layers)
    val d = DeckModel(3)
    fun all(): List<DeckModel> = listOf(a, b, c, d)
    var autoStems by mutableStateOf(false)                // OFF by default: separating every loaded track keeps the CPU hot
    var power by mutableIntStateOf(0)                     // stems CPU use: 0 = ECO (cool, quiet), 1 = BALANCED, 2 = FAST
    val stemLock = Semaphore(1)                           // one separation at a time: it is the heaviest job in the app
}

/** UI state of one deck + the calls into the engine. */
class DeckModel(val id: Int) {
    var title by mutableStateOf("No track loaded")
    var status by mutableStateOf("")
    var bpm by mutableFloatStateOf(0f)
    var key by mutableStateOf("")
    var playing by mutableStateOf(false)
    var pos by mutableFloatStateOf(0f)
    var dur by mutableFloatStateOf(0f)
    var tempoPct by mutableFloatStateOf(0f)        // -0.08 .. +0.08
    var bass by mutableFloatStateOf(0f)            // dB, -26 .. +12
    var mid by mutableFloatStateOf(0f)
    var treble by mutableFloatStateOf(0f)
    var filter by mutableFloatStateOf(0f)          // -1 low-pass .. 0 off .. +1 high-pass
    var volume by mutableFloatStateOf(1f)
    var synced by mutableStateOf(false)
    var rate = 0
    var cue = 0.0
    var loading by mutableStateOf(false)
    private var loadGen = 0
    // ---- stems (engine order: 0 vocals, 1 drums, 2 bass, 3 other / melody)
    val stemOn = mutableStateListOf(true, true, true, true)
    var stemsReady by mutableStateOf(false)
    var preparing by mutableStateOf(false)
    var stemProgress by mutableFloatStateOf(0f)
    var loadedFile by mutableStateOf<File?>(null)
    var peaks by mutableStateOf<FloatArray?>(null)
    var loopOn by mutableStateOf(false)
    val fx = mutableStateListOf(false, false, false, false)     // stem effects: voc echo, voc reverb, instr echo, instr reverb
    var loopBeats by mutableIntStateOf(4)                // loop length in beats: 1 2 4 8 16 32 64
    var keylock by mutableStateOf(true)                  // keep the pitch when the tempo changes
    private var loopStart = 0.0
    private var loopEnd = 0.0
    private var rawFile: File? = null
    private var forcedMxs: MxsInfo? = null                  // set when a .mxs file was opened directly: use exactly these stems

    init { lib.dj_set_keylock(id, 1) }

    fun load(src: File, onReady: () -> Unit = {}) {
        if (src.extension.equals("mxs", ignoreCase = true)) {
            // a .mxs file: open the original it was made from (with its video) and play these stems
            val info = Mxs.read(src)
            val orig = info?.source?.let { File(it) }
            if (info == null || orig == null || !orig.isFile) { status = "Cannot open this .mxs: it is damaged or its original file is missing"; return }
            forcedMxs = info
            load(orig, onReady)
            return
        }
        val gen = ++loadGen
        loading = true; status = "Decoding..."; playing = false; synced = false
        stemsReady = false; preparing = false; for (i in 0..3) stemOn[i] = true; rawFile = null
        title = src.nameWithoutExtension
        loadedFile = src; peaks = null; loopOn = false
        for (k in 0 until 4) if (fx[k]) setFx(k, false)
        val video = isVideoFile(src)
        val li = id and 1                                    // A and C use the left picture, B and D the right one
        val layer = VideoMixer.layers[li]
        if (video) { layer.load(src, true); VideoMixer.owner[li] = id }
        else if (layer.locked && VideoMixer.owner[li] == id) layer.clear()
        Thread {
            try {
                val raw = TrackCache.rawFor(src)
                var r = if (raw.exists() && raw.length() > 1000) rateFile(raw).takeIf { it > 0 } ?: 0 else 0
                if (r == 0) {
                    // MP3 / WAV / FLAC: the fast built-in decoder. Anything else (video files, M4A, OGG, AAC ...): FFmpeg.
                    r = if (video) 0 else lib.dj_decode_to_raw(src.absolutePath, raw.absolutePath)
                    if (r <= 0) r = Ffmpeg.audioToRaw(src, raw)
                    if (r > 0) File(raw.path + ".rate").writeText(r.toString())
                }
                if (gen != loadGen) return@Thread
                if (r <= 0) { status = "Cannot read this file (WAV, MP3, FLAC are supported)"; loading = false; return@Thread }
                rate = r; rawFile = raw
                lib.dj_load_deck(id, raw.absolutePath, r)
                dur = lib.dj_get_duration(id).toFloat(); pos = 0f; cue = 0.0
                peaks = Peaks.compute(raw, (dur * 100f).toInt().coerceIn(300, 60000))   // 100 slices per second: enough to zoom in
                applyAll()
                status = "Analysing..."
                val grid = BpmDetector.grid(raw, r)
                if (gen == loadGen) {
                    bpm = grid?.bpm ?: 0f
                    key = KeyDetector.detect(raw, r)?.camelot ?: ""
                    Library.record(src, dur, bpm, key)
                    status = ""
                }
                loading = false
                onReady()
                if (gen == loadGen) {
                    // stems prepared earlier (shown in the library under Stems) come back instantly, no separation, no CPU
                    val forced = forcedMxs
                    forcedMxs = null
                    val cached = (if (forced != null && forced.rate == r && kotlin.math.abs(dur * r - forced.frames) < r) forced else null)
                        ?: StemCache.find(TrackCache.dir, raw, raw.nameWithoutExtension)
                    if (cached != null) { lib.dj_set_stems_mxs(id, cached.file.absolutePath, cached.offsets, cached.lengths); stemsReady = true; applyStems() }
                    else if (Decks.autoStems) prepareStems()
                }
            } catch (e: Throwable) { status = "Load failed: ${e.message}"; loading = false }
        }.apply { isDaemon = true }.start()
    }

    private fun rateFile(raw: File): Int = try { File(raw.path + ".rate").readText().trim().toInt() } catch (_: Exception) { 0 }

    fun applyAll() {
        lib.dj_set_volume(id, volume); lib.dj_set_tempo(id, 1f + tempoPct)
        lib.dj_set_eq(id, 0, bass); lib.dj_set_eq(id, 1, mid); lib.dj_set_eq(id, 2, treble); lib.dj_set_filter(id, filter)
    }

    fun togglePlay() { playing = !playing; lib.dj_set_playing(id, if (playing) 1 else 0) }
    /** CUE: while playing jump back to the cue point and pause; while paused set the cue to here. */
    fun cuePress() {
        if (playing) { playing = false; lib.dj_set_playing(id, 0); lib.dj_seek(id, cue) } else cue = pos.toDouble()
    }
    fun seekTo(sec: Float) { lib.dj_seek(id, sec.toDouble()); pos = sec }
    fun setTempo(p: Float) { synced = false; tempoPct = p; lib.dj_set_tempo(id, 1f + p) }
    fun applyBass(v: Float) { bass = v; lib.dj_set_eq(id, 0, v) }
    fun applyMid(v: Float) { mid = v; lib.dj_set_eq(id, 1, v) }
    fun applyTreble(v: Float) { treble = v; lib.dj_set_eq(id, 2, v) }
    fun applyFilter(v: Float) { filter = if (kotlin.math.abs(v) < 0.04f) 0f else v; lib.dj_set_filter(id, filter) }
    fun applyVolume(v: Float) { volume = v; lib.dj_set_volume(id, v) }

    /** Makes this deck play at exactly the other deck's current BPM. */
    fun syncTo(o: DeckModel) {
        if (bpm <= 0f || o.bpm <= 0f) return
        var target = o.bpm * (1f + o.tempoPct)
        while (target / bpm > 1.5f) target /= 2f           // half / double time for tracks far apart
        while (target / bpm < 0.67f) target *= 2f
        tempoPct = target / bpm - 1f; synced = true
        lib.dj_set_tempo(id, 1f + tempoPct)
    }

    // ---------------------------------------------------------------- stems
    private fun anyPlaying() = Decks.a.playing || Decks.b.playing || Decks.c.playing || Decks.d.playing
    fun applyStems() { for (i in 0..3) lib.dj_set_stem_volume(id, i, if (stemOn[i]) 1f else 0f) }
    fun toggleStem(i: Int) { if (!stemsReady) return; stemOn[i] = !stemOn[i]; applyStems() }
    /** ACAPELLA = vocal only, INSTRUMENTAL = no vocal, BEATLESS = no drums, ALL = everything. */
    fun stemPreset(v: Boolean, d: Boolean, b: Boolean, m: Boolean) {
        if (!stemsReady) return
        stemOn[0] = v; stemOn[1] = d; stemOn[2] = b; stemOn[3] = m; applyStems()
    }

    /** Separates the loaded track into vocal / drums / bass / melody in the background and swaps the deck over without a gap. */
    fun prepareStems() {
        val raw = rawFile ?: return
        if (preparing || stemsReady || rate <= 0) return
        val gen = loadGen
        preparing = true; stemProgress = 0f
        Thread {
            Decks.stemLock.acquire()
            try {
                if (gen != loadGen) return@Thread
                val modelDir = Native_.modelDir()
                val ai = File(modelDir, "scnet-large.int8.onnx").let { it.exists() && it.length() > 5_000_000L }
                // ECO = 2 threads + rests (cool and quiet), BALANCED = 4 threads (2 while playing), FAST = up to 8 threads.
                val deckPlaying = anyPlaying()
                val threads = when (Decks.power) { 0 -> 2; 1 -> if (deckPlaying) 2 else 4; else -> if (deckPlaying) 4 else 8 }
                val rest = when (Decks.power) { 0 -> 0.5; 1 -> 0.2; else -> 0.0 }
                val overlap = if (Decks.power >= 2) 4 else 8
                val sep: StemSeparator = if (ai) ScnetSeparator(modelDir, threads, overlap, rest) { status = it } else ProSeparator()
                status = if (ai) "Stems (AI)..." else "Stems..."
                val info = StemCache.prepare(TrackCache.dir, raw, rate, raw.nameWithoutExtension, loadedFile, { stemProgress = it }, { gen != loadGen }, sep)
                if (info != null && gen == loadGen) {
                    lib.dj_set_stems_mxs(id, info.file.absolutePath, info.offsets, info.lengths)
                    stemsReady = true; applyStems(); status = ""
                    Library.refreshStems()
                } else if (gen == loadGen) status = "Stems failed"
            } catch (t: Throwable) { status = "Stems failed: ${t.message}" }
            finally { if (gen == loadGen) preparing = false; Decks.stemLock.release() }
        }.apply { isDaemon = true; priority = Thread.MIN_PRIORITY; name = "stems-$id" }.start()
    }

    private fun beatSec(): Double = if (bpm > 0f) 60.0 / bpm else 0.5
    private fun applyLoop() { lib.dj_set_loop(id, loopStart, loopEnd, 1); loopOn = true }
    fun loopIn() { loopStart = pos.toDouble(); if (loopOn) { lib.dj_set_loop(id, 0.0, 0.0, 0); loopOn = false } }
    fun loopOut() { val e = pos.toDouble(); if (e > loopStart + 0.05) { loopEnd = e; applyLoop() } }
    fun toggleLoop() {
        if (loopOn) { lib.dj_set_loop(id, 0.0, 0.0, 0); loopOn = false }
        else if (dur > 0f) { loopStart = pos.toDouble(); loopEnd = loopStart + loopBeats * beatSec(); applyLoop() }
    }
    fun setLoopBeats(n: Int) {
        loopBeats = n.coerceIn(1, 64)
        if (loopOn) { loopEnd = loopStart + loopBeats * beatSec(); applyLoop() }
    }
    /** Stem effects (need prepared stems): 0 = vocal echo, 1 = vocal reverb, 2 = instrumental echo, 3 = instrumental reverb. */
    fun setFx(k: Int, on: Boolean) {
        fx[k] = on
        val beat = if (liveBpm > 0f) 60f / liveBpm else 0.4f          // echo = one beat
        lib.dj_set_stem_fx(id, k / 2, k % 2, if (!on) 0f else if (k % 2 == 0) 0.6f else 0.5f, beat)
    }
    fun toggleFx(k: Int) { if (stemsReady) setFx(k, !fx[k]) }
    fun setKeylock(on: Boolean) { keylock = on; lib.dj_set_keylock(id, if (on) 1 else 0) }
    fun toggleKeylock() = setKeylock(!keylock)

    fun poll() {
        val p = lib.dj_get_position(id).toFloat()
        if (p != pos) pos = p            // paused deck: nothing changes, nothing is redrawn
        val li = id and 1
        if (VideoMixer.owner[li] == id) {
            val v = VideoMixer.layers[li]
            v.targetSec = pos.toDouble(); v.playing = playing; v.speed = (1f + tempoPct).toDouble()
        }
    }
    val liveBpm get() = if (bpm > 0f) bpm * (1f + tempoPct) else 0f
}
