package com.example.djapp

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.bytedeco.ffmpeg.global.avcodec
import org.bytedeco.ffmpeg.global.avutil
import org.bytedeco.javacv.FFmpegFrameGrabber
import org.bytedeco.javacv.FFmpegFrameRecorder
import org.bytedeco.javacv.Java2DFrameConverter
import java.awt.AlphaComposite
import java.awt.Color
import java.awt.RenderingHints
import java.awt.image.BufferedImage
import java.io.BufferedOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.ShortBuffer
import kotlin.math.abs

val VIDEO_EXT = setOf("mp4", "mkv", "avi", "mov", "webm", "m4v", "wmv")
fun isVideoFile(f: File) = f.extension.lowercase() in VIDEO_EXT

/** FFmpeg helpers (through JavaCV). */
object Ffmpeg {
    /** Decodes the sound of ANY file FFmpeg can open (video files, AAC, OGG, M4A ...) to raw 16-bit stereo. Returns the sample rate or 0. */
    fun audioToRaw(src: File, out: File): Int {
        val g = FFmpegFrameGrabber(src)
        try {
            g.audioChannels = 2
            g.sampleFormat = avutil.AV_SAMPLE_FMT_S16
            g.start()
            val rate = g.sampleRate
            if (rate <= 0) return 0
            var wrote = 0L
            BufferedOutputStream(out.outputStream(), 256 * 1024).use { os ->
                while (true) {
                    val f = g.grabSamples() ?: break
                    val sb = (f.samples?.firstOrNull() as? ShortBuffer)?.duplicate() ?: continue
                    val n = sb.remaining()
                    if (n <= 0) continue
                    val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.nativeOrder())
                    bb.asShortBuffer().put(sb)
                    os.write(bb.array(), 0, n * 2)
                    wrote += n * 2L
                }
            }
            return if (wrote > 1000) rate else 0
        } catch (_: Throwable) { return 0 } finally { try { g.stop(); g.release() } catch (_: Throwable) {} }
    }
}

/** One video per deck, decoded on its own thread into ready-to-blend 1280x720 pictures. */
class VideoLayer(val id: Int) {
    var name by mutableStateOf("")
    @Volatile var ready = false
    @Volatile var locked = false              // true: picture follows the deck's track position (video with its sound); false: silent loop
    @Volatile var targetSec = 0.0             // deck position (locked mode)
    @Volatile var playing = false             // deck is playing
    @Volatile var speed = 1.0                 // deck tempo factor (free loops follow it)
    @Volatile var latest: BufferedImage? = null
    @Volatile var forcePlay = false
    private var gen = 0

    fun load(file: File, lock: Boolean) {
        clear()
        val my = ++gen
        locked = lock; name = file.nameWithoutExtension
        Thread { run(file, my) }.apply { isDaemon = true; priority = Thread.NORM_PRIORITY - 1; name = "video-$id" }.start()
    }

    fun clear() { gen++; ready = false; latest = null; name = "" }

    private fun fit(src: BufferedImage): BufferedImage {
        val out = BufferedImage(VideoMixer.W, VideoMixer.H, BufferedImage.TYPE_INT_RGB)
        val g = out.createGraphics()
        g.color = Color.BLACK; g.fillRect(0, 0, out.width, out.height)
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR)
        val s = minOf(out.width.toDouble() / src.width, out.height.toDouble() / src.height)
        val w = (src.width * s).toInt(); val h = (src.height * s).toInt()
        g.drawImage(src, (out.width - w) / 2, (out.height - h) / 2, w, h, null)
        g.dispose()
        return out
    }

    private fun run(file: File, my: Int) {
        val g = FFmpegFrameGrabber(file)
        val conv = Java2DFrameConverter()
        try {
            g.start()
            val durUs = g.lengthInTime.coerceAtLeast(1L)
            var lastTs = -1L
            var freeClockUs = 0.0; var lastWall = System.nanoTime()
            while (gen == my) {
                val now = System.nanoTime()
                val dtUs = (now - lastWall) / 1000.0; lastWall = now
                var advance = false
                if (locked) {
                    val want = ((targetSec * 1e6).toLong().coerceAtLeast(0L)) % durUs
                    if (lastTs < 0 || want - lastTs > 1_500_000L || lastTs - want > 400_000L) {
                        g.timestamp = want; advance = true; lastTs = -2          // jump (cue, scratch, loop, seek): land near the new position
                    } else if (lastTs + 40_000L <= want) advance = true           // behind: catch up as fast as we can decode
                } else if (playing || forcePlay) {
                    freeClockUs += dtUs * speed
                    if (lastTs < 0 || lastTs <= freeClockUs) advance = true
                }
                if (!advance) { Thread.sleep(5); continue }
                val f = g.grabImage()
                if (f == null) {                                                  // end of the file: loop
                    g.timestamp = 0; lastTs = -1; freeClockUs = 0.0; Thread.sleep(5); continue
                }
                lastTs = if (f.timestamp > 0) f.timestamp else maxOf(lastTs, 0L) + 33_000L
                val img = conv.convert(f) ?: continue
                latest = fit(img)
                ready = true
                if (!locked && !(playing || forcePlay)) Thread.sleep(10)
            }
        } catch (t: Throwable) {
            System.err.println("video ${file.name}: $t")
            if (gen == my) { ready = false }
        } finally { try { g.stop(); g.release() } catch (_: Throwable) {} }
    }
}

/** Mixes the two layers with the crossfader. The same picture goes to the preview, the output window and the recorder. */
object VideoMixer {
    const val W = 1280
    const val H = 720
    val layers = listOf(VideoLayer(0), VideoLayer(1))
    @Volatile var audioCross = 0.5f
    @Volatile var manualCross = 0.5f
    @Volatile var followCross = true
    @Volatile var blend = 0                                  // 0 blend, 1 dip to black, 2 cut
    val cross: Float get() = if (followCross) audioCross else manualCross

    fun alphas(): Pair<Float, Float> {
        val aOk = layers[0].ready; val bOk = layers[1].ready
        if (aOk && !bOk) return 1f to 0f
        if (!aOk && bOk) return 0f to 1f
        val x = cross
        return when (blend) {
            1 -> (1f - 2f * x).coerceIn(0f, 1f) to (2f * x - 1f).coerceIn(0f, 1f)
            2 -> (if (x < 0.5f) 1f else 0f) to (if (x >= 0.5f) 1f else 0f)
            else -> 1f to x                                  // A * (1-x) + B * x
        }
    }

    /** Returns null when no video is loaded. */
    fun compose(): BufferedImage? {
        val a = layers[0].latest; val b = layers[1].latest
        if (a == null && b == null) return null
        val (aa, ab) = alphas()
        val out = BufferedImage(W, H, BufferedImage.TYPE_INT_RGB)
        val g = out.createGraphics()
        g.color = Color.BLACK; g.fillRect(0, 0, W, H)
        if (a != null && aa > 0.01f) { g.composite = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, aa.coerceIn(0f, 1f)); g.drawImage(a, 0, 0, null) }
        if (b != null && ab > 0.01f) { g.composite = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, ab.coerceIn(0f, 1f)); g.drawImage(b, 0, 0, null) }
        g.dispose()
        return out
    }
}

/** Records the mixed picture together with the master sound (bass amp and limiter included) into one MP4 file. */
object MixRecorder {
    @Volatile var recording = false
    var info by mutableStateOf("")
    private var thread: Thread? = null

    private fun open(out: File, sr: Int, h264: Boolean): FFmpegFrameRecorder {
        val r = FFmpegFrameRecorder(out, VideoMixer.W, VideoMixer.H, 2)
        r.format = "mp4"
        r.frameRate = 30.0
        r.videoCodec = if (h264) avcodec.AV_CODEC_ID_H264 else avcodec.AV_CODEC_ID_MPEG4
        r.videoBitrate = if (h264) 8_000_000 else 14_000_000
        r.pixelFormat = avutil.AV_PIX_FMT_YUV420P
        r.audioCodec = avcodec.AV_CODEC_ID_AAC
        r.audioBitrate = 256_000
        r.sampleRate = sr
        r.start()
        return r
    }

    fun start(outFile: File) {
        if (recording) return
        val lib = Native_.lib
        val sr = lib.dj_get_sample_rate().takeIf { it > 0 } ?: 48000
        val rec = try { open(outFile, sr, true) } catch (_: Throwable) {
            try { open(outFile, sr, false) } catch (t: Throwable) { info = "Cannot start recording: ${t.message}"; return }
        }
        recording = true; info = "Recording ${outFile.name}"
        lib.dj_tap_start()
        thread = Thread {
            val conv = Java2DFrameConverter()
            val black = BufferedImage(VideoMixer.W, VideoMixer.H, BufferedImage.TYPE_INT_RGB)
            val chunk = FloatArray(2 * 4800)
            val t0 = System.nanoTime()
            var frameNo = 0L
            try {
                while (recording) {
                    val due = t0 + frameNo * 33_333_333L
                    val wait = (due - System.nanoTime()) / 1_000_000
                    if (wait > 0) Thread.sleep(wait)
                    val img = VideoMixer.compose() ?: black
                    rec.timestamp = frameNo * 33_333L
                    rec.record(conv.convert(img))
                    frameNo++
                    drain(lib, rec, sr, chunk)
                }
                drain(lib, rec, sr, chunk)
            } catch (t: Throwable) { info = "Recording stopped: ${t.message}" }
            finally { lib.dj_tap_stop(); try { rec.stop(); rec.release() } catch (_: Throwable) {}; recording = false; info = "Saved ${outFile.name}" }
        }.apply { isDaemon = false; name = "mix-recorder"; start() }
    }

    private fun drain(lib: DjLib, rec: FFmpegFrameRecorder, sr: Int, chunk: FloatArray) {
        while (true) {
            val n = lib.dj_tap_read(chunk, 4800)
            if (n <= 0) break
            val bb = ByteBuffer.allocateDirect(n * 8).order(ByteOrder.nativeOrder())
            bb.asFloatBuffer().put(chunk, 0, n * 2)
            rec.recordSamples(sr, 2, bb.asFloatBuffer())
        }
    }

    fun stop() { recording = false; thread?.join(8000) }
}
