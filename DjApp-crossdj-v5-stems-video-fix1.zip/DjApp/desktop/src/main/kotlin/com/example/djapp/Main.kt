package com.example.djapp

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.toComposeImageBitmap
import androidx.compose.ui.window.WindowPlacement
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import kotlinx.coroutines.delay
import java.awt.FileDialog
import java.awt.Frame
import java.io.File

private val Bg = Color(0xFF05070B)
private val Panel = Color(0xFF0B0F17)
private val Line = Color(0xFF2A303C)
private val TextGray = Color(0xFF8FA0BD)
private val DeckBlue = Color(0xFF3D8BFF)
private val DeckRed = Color(0xFFFF4D5E)
private val Accent = Color(0xFF39D98A)

private fun mmss(s: Float): String { val t = s.toInt().coerceAtLeast(0); return "%d:%02d".format(t / 60, t % 60) }

private fun pickFile(): File? {
    val d = FileDialog(null as Frame?, "Load a track", FileDialog.LOAD)
    d.setFilenameFilter { _, n -> n.substringAfterLast('.', "").lowercase().let { it in setOf("mp3", "wav", "flac", "ogg", "m4a", "aac") || it in VIDEO_EXT } }
    d.isVisible = true
    return d.file?.let { File(d.directory, it) }
}

private fun pickVideo(): File? {
    val d = FileDialog(null as Frame?, "Load a video (picture only)", FileDialog.LOAD)
    d.setFilenameFilter { _, n -> n.substringAfterLast('.', "").lowercase() in VIDEO_EXT }
    d.isVisible = true
    return d.file?.let { File(d.directory, it) }
}

fun main() = application {
    val lib = remember { Native_.lib }
    val a = Decks.a
    val b = Decks.b
    var cross by remember { mutableFloatStateOf(0.5f) }
    var master by remember { mutableFloatStateOf(1f) }
    var bassAmp by remember { mutableFloatStateOf(0.5f) }
    var level by remember { mutableFloatStateOf(0f) }
    var recording by remember { mutableStateOf(false) }
    var engineOk by remember { mutableStateOf(true) }
    var videoOpen by remember { mutableStateOf(false) }
    var outputOpen by remember { mutableStateOf(false) }
    var frame by remember { mutableStateOf<ImageBitmap?>(null) }
    var vidRec by remember { mutableStateOf(false) }
    var blend by remember { mutableIntStateOf(0) }
    var follow by remember { mutableStateOf(true) }
    var manualX by remember { mutableFloatStateOf(0.5f) }

    LaunchedEffect(Unit) {
        engineOk = lib.dj_start() == 1
        lib.dj_set_master_gain(master); lib.dj_set_bass_amp(bassAmp); lib.dj_set_crossfader(cross)
        while (true) { a.poll(); b.poll(); level = lib.dj_get_level(); delay(33) }
    }
    // the mixed picture, 30 times a second, only while something looks at it or records it
    LaunchedEffect(videoOpen, outputOpen, vidRec) {
        while (videoOpen || outputOpen || vidRec) {
            val bmp = withContext(Dispatchers.Default) { VideoMixer.compose()?.toComposeImageBitmap() }
            if (bmp != null) frame = bmp
            delay(33)
        }
    }

    if (outputOpen) OutputWindow(frame) { outputOpen = false }

    Window(onCloseRequest = { MixRecorder.stop(); lib.dj_stop_recording(); lib.dj_stop(); exitApplication() }, title = "MAXIDO DJ - free for PC", state = rememberWindowState(width = 1280.dp, height = 960.dp)) {
        MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
            Column(Modifier.fillMaxSize().background(Bg).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!engineOk) Text("No audio output device could be opened. Plug in speakers or headphones and restart.", color = DeckRed)
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DeckView(a, b, DeckBlue, Modifier.weight(1f))
                    Mixer(
                        cross, { cross = it; lib.dj_set_crossfader(it); VideoMixer.audioCross = it },
                        master, { master = it; lib.dj_set_master_gain(it) },
                        bassAmp, { bassAmp = it; lib.dj_set_bass_amp(it) },
                        level, recording,
                        videoOpen, { videoOpen = !videoOpen }
                    ) {
                        if (recording) { lib.dj_stop_recording(); recording = false }
                        else {
                            val dir = File(System.getProperty("user.home"), "Music/MAXIDO DJ").apply { mkdirs() }
                            val f = File(dir, "mix-${System.currentTimeMillis() / 1000}.wav")
                            recording = lib.dj_start_recording(f.absolutePath) == 1
                        }
                    }
                    DeckView(b, a, DeckRed, Modifier.weight(1f))
                }
                if (videoOpen) VideoPanel(
                    frame, blend, { blend = it; VideoMixer.blend = it }, follow, { follow = it; VideoMixer.followCross = it },
                    manualX, { manualX = it; VideoMixer.manualCross = it }, outputOpen, { outputOpen = !outputOpen }, vidRec
                ) {
                    if (MixRecorder.recording) { MixRecorder.stop(); vidRec = false }
                    else {
                        val dir = File(System.getProperty("user.home"), "Videos/MAXIDO DJ").apply { mkdirs() }
                        MixRecorder.start(File(dir, "videomix-${System.currentTimeMillis() / 1000}.mp4"))
                        vidRec = MixRecorder.recording
                    }
                }
            }
        }
    }
}

/** A second window that shows only the mixed picture: drag it to the projector / TV, double-click for full screen. */
@Composable
private fun OutputWindow(frame: ImageBitmap?, onClose: () -> Unit) {
    val st = rememberWindowState(width = 960.dp, height = 540.dp)
    Window(onCloseRequest = onClose, title = "MAXIDO DJ - video output", state = st) {
        Box(
            Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) {
                detectTapGestures(onDoubleTap = { st.placement = if (st.placement == WindowPlacement.Fullscreen) WindowPlacement.Floating else WindowPlacement.Fullscreen })
            }
        ) { if (frame != null) Image(frame, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
    }
}

@Composable
private fun VideoPanel(
    frame: ImageBitmap?, blend: Int, onBlend: (Int) -> Unit, follow: Boolean, onFollow: (Boolean) -> Unit,
    manualX: Float, onManual: (Float) -> Unit, outputOpen: Boolean, onOutput: () -> Unit, recording: Boolean, onRec: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().height(250.dp).background(Panel, RoundedCornerShape(10.dp)).border(1.dp, Line, RoundedCornerShape(10.dp)).padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(Modifier.aspectRatio(16f / 9f).fillMaxHeight().background(Color.Black)) {
            if (frame != null) Image(frame, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            else Text("Load a video on a deck", color = TextGray, modifier = Modifier.align(Alignment.Center), fontSize = 12.sp)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("VIDEO MIXER", color = Accent, fontWeight = FontWeight.Bold)
            Text("On each deck: VIDEO + SOUND plays a video file as the track (picture locked to the deck: play, cue, scratch, tempo). SILENT LOOP adds a picture-only clip.", color = TextGray, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("BLEND", "DIP TO BLACK", "CUT").forEachIndexed { i, t ->
                    Button(onClick = { onBlend(i) }, colors = ButtonDefaults.buttonColors(containerColor = if (blend == i) Accent else Color(0xFF1D222C))) { Text(t, color = if (blend == i) Color.Black else Color.White, fontSize = 11.sp) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { onFollow(true) }, colors = ButtonDefaults.buttonColors(containerColor = if (follow) Accent else Color(0xFF1D222C))) { Text("XFADER", color = if (follow) Color.Black else Color.White, fontSize = 11.sp) }
                Button(onClick = { onFollow(false) }, colors = ButtonDefaults.buttonColors(containerColor = if (!follow) Accent else Color(0xFF1D222C))) { Text("MANUAL", color = if (!follow) Color.Black else Color.White, fontSize = 11.sp) }
                if (!follow) Slider(manualX, onManual, modifier = Modifier.width(180.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onOutput, colors = ButtonDefaults.buttonColors(containerColor = if (outputOpen) Accent else Color(0xFF1D222C))) { Text("OUTPUT WINDOW", color = if (outputOpen) Color.Black else Color.White, fontSize = 11.sp) }
                Button(onClick = onRec, colors = ButtonDefaults.buttonColors(containerColor = if (recording) DeckRed else Color(0xFF1D222C))) { Text(if (recording) "STOP VIDEO REC" else "REC VIDEO MIX", color = Color.White, fontSize = 11.sp) }
            }
            Text(
                if (MixRecorder.info.isNotEmpty()) MixRecorder.info else "REC VIDEO MIX saves picture + master sound (bass amp included) as MP4 in Videos\\MAXIDO DJ. Double-click the output window for full screen.",
                color = TextGray, fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun Mixer(
    cross: Float, onCross: (Float) -> Unit, master: Float, onMaster: (Float) -> Unit,
    bassAmp: Float, onBassAmp: (Float) -> Unit, level: Float, recording: Boolean,
    videoOpen: Boolean, onVideo: () -> Unit, onRec: () -> Unit
) {
    Column(
        Modifier.width(210.dp).fillMaxHeight().background(Panel, RoundedCornerShape(10.dp)).border(1.dp, Line, RoundedCornerShape(10.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("MAXIDO DJ", color = Accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("FREE for PC", color = TextGray, fontSize = 11.sp)
        Spacer(Modifier.height(4.dp))
        Meter(level)
        Labeled("MASTER  ${(master * 100).toInt()}%") { Slider(master, onMaster, valueRange = 0.25f..1.25f) }
        Labeled("BASS AMP  ${(bassAmp * 100).toInt()}%") { Slider(bassAmp, onBassAmp, valueRange = 0f..1f) }
        Text("Adds punch you can hear on any speaker and removes inaudible rumble below 24 Hz.", color = TextGray, fontSize = 10.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(Decks.autoStems, { Decks.autoStems = it })
            Spacer(Modifier.width(8.dp)); Text("AUTO STEMS", color = TextGray, fontSize = 11.sp)
        }
        Button(onClick = onVideo, colors = ButtonDefaults.buttonColors(containerColor = if (videoOpen) Accent else Color(0xFF1D222C))) {
            Text("VIDEO", color = if (videoOpen) Color.Black else Color.White)
        }
        Spacer(Modifier.weight(1f))
        Labeled("CROSSFADER") { Slider(cross, onCross) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("A", color = DeckBlue); Text("B", color = DeckRed) }
        Button(onClick = onRec, colors = ButtonDefaults.buttonColors(containerColor = if (recording) DeckRed else Color(0xFF1D222C))) {
            Text(if (recording) "STOP REC" else "REC", color = Color.White)
        }
    }
}

@Composable
private fun Meter(level: Float) {
    Canvas(Modifier.fillMaxWidth().height(14.dp)) {
        drawRect(Color(0xFF131720), size = size)
        val w = size.width * level.coerceIn(0f, 1f)
        drawRect(if (level > 0.93f) DeckRed else Accent, size = Size(w, size.height))
    }
}

@Composable
private fun Labeled(label: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth()) { Text(label, color = TextGray, fontSize = 11.sp); content() }
}

@Composable
private fun DeckView(d: DeckModel, other: DeckModel, color: Color, modifier: Modifier) {
    Column(
        modifier.fillMaxHeight().background(Panel, RoundedCornerShape(10.dp)).border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(10.dp)).verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { pickFile()?.let { d.load(it) } }, colors = ButtonDefaults.buttonColors(containerColor = color)) { Text("LOAD", color = Color.White) }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(d.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(
                    if (d.status.isNotEmpty()) d.status else
                        buildString { if (d.liveBpm > 0f) append("%.1f BPM".format(d.liveBpm)); if (d.key.isNotEmpty()) append("   KEY ${d.key}") },
                    color = TextGray, fontSize = 12.sp
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(mmss(d.pos), color = TextGray, fontSize = 12.sp)
            Slider(d.pos.coerceAtMost(d.dur.coerceAtLeast(0.01f)), { d.seekTo(it) }, valueRange = 0f..d.dur.coerceAtLeast(0.01f), modifier = Modifier.weight(1f), enabled = d.dur > 0f)
            Text(mmss(d.dur), color = TextGray, fontSize = 12.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { d.cuePress() }, enabled = d.dur > 0f) { Text("CUE") }
            Button(onClick = { d.togglePlay() }, enabled = d.dur > 0f, colors = ButtonDefaults.buttonColors(containerColor = if (d.playing) color else Color(0xFF1D222C))) {
                Text(if (d.playing) "PAUSE" else "PLAY", color = Color.White)
            }
            Button(onClick = { if (d.synced) d.setTempo(d.tempoPct) else d.syncTo(other) }, enabled = d.bpm > 0f && other.bpm > 0f,
                colors = ButtonDefaults.buttonColors(containerColor = if (d.synced) Accent else Color(0xFF1D222C))) { Text("SYNC", color = if (d.synced) Color.Black else Color.White) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { pickVideo()?.let { d.load(it) } }) { Text("VIDEO + SOUND", fontSize = 10.sp) }
            Button(onClick = { pickVideo()?.let { VideoMixer.layers[d.id].load(it, false) } }) { Text("SILENT LOOP", fontSize = 10.sp) }
            Button(onClick = { VideoMixer.layers[d.id].clear() }) { Text("X", fontSize = 10.sp) }
        }
        // ---- stems
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            val labels = listOf("VOCAL", "DRUMS", "BASS", "MELODY")
            for (i in 0..3) {
                val on = d.stemOn[i]
                Button(onClick = { d.toggleStem(i) }, enabled = d.stemsReady,
                    colors = ButtonDefaults.buttonColors(containerColor = if (d.stemsReady && on) color else Color(0xFF1D222C), disabledContainerColor = Color(0xFF131720))) {
                    Text(labels[i], fontSize = 10.sp, color = if (d.stemsReady) Color.White else TextGray)
                }
            }
        }
        if (d.stemsReady) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { d.stemPreset(true, false, false, false) }) { Text("ACAPELLA", fontSize = 10.sp) }
            Button(onClick = { d.stemPreset(false, true, true, true) }) { Text("NO VOCALS", fontSize = 10.sp) }
            Button(onClick = { d.stemPreset(true, false, true, true) }) { Text("BEATLESS", fontSize = 10.sp) }
            Button(onClick = { d.stemPreset(true, true, true, true) }) { Text("ALL", fontSize = 10.sp) }
        } else if (d.preparing) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LinearProgressIndicator(progress = { d.stemProgress }, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(8.dp)); Text("stems ${(d.stemProgress * 100).toInt()}%", color = TextGray, fontSize = 11.sp)
            }
        } else if (d.dur > 0f) Button(onClick = { d.prepareStems() }) { Text("PREPARE STEMS", fontSize = 11.sp) }
        Labeled("TEMPO  ${"%+.1f".format(d.tempoPct * 100)}%") {
            Slider(d.tempoPct, { d.setTempo(if (kotlin.math.abs(it) < 0.002f) 0f else it) }, valueRange = -0.08f..0.08f)
        }
        Labeled("VOLUME") { Slider(d.volume, { d.applyVolume(it) }, valueRange = 0f..1f) }
        Labeled("BASS  ${"%+.0f".format(d.bass)} dB") { Slider(d.bass, { d.applyBass(if (kotlin.math.abs(it) < 0.6f) 0f else it) }, valueRange = -26f..12f) }
        Labeled("MID  ${"%+.0f".format(d.mid)} dB") { Slider(d.mid, { d.applyMid(if (kotlin.math.abs(it) < 0.6f) 0f else it) }, valueRange = -26f..12f) }
        Labeled("TREBLE  ${"%+.0f".format(d.treble)} dB") { Slider(d.treble, { d.applyTreble(if (kotlin.math.abs(it) < 0.6f) 0f else it) }, valueRange = -26f..12f) }
        Labeled("FILTER  ${if (d.filter < -0.02f) "low-pass" else if (d.filter > 0.02f) "high-pass" else "off"}") {
            Slider(d.filter, { d.applyFilter(it) }, valueRange = -1f..1f)
        }
    }
}
