package com.example.djapp

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toComposeImageBitmap
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.window.WindowPlacement
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import kotlinx.coroutines.delay
import java.awt.FileDialog
import java.awt.Frame
import java.io.File

private val Bg = Color(0xFF0B0D11)
private val Panel = Color(0xFF161A20)
private val Line = Color(0xFF2A303A)
private val TextGray = Color(0xFF8FA0BD)
private val DeckBlue = Color(0xFF2BA8E0)
private val DeckRed = Color(0xFFFF4D5E)
private val Accent = Color(0xFF39D98A)
private val Btn = Color(0xFF262B33)

private fun mmss(s: Float): String { val t = s.toInt().coerceAtLeast(0); return "%d:%02d".format(t / 60, t % 60) }

private fun pickFile(): File? {
    val d = FileDialog(null as Frame?, "Load a track", FileDialog.LOAD)
    d.setFilenameFilter { _, n -> n.substringAfterLast('.', "").lowercase().let { it in setOf("mp3", "wav", "flac", "ogg", "m4a", "aac") || it in VIDEO_EXT } }
    d.isVisible = true
    return d.file?.let { File(d.directory, it) }
}

private fun pickVideo(): File? {
    val d = FileDialog(null as Frame?, "Load a video (picture only)", FileDialog.LOAD)
    d.setFilenameFilter { _, n -> n.substringAfterLast('.', "").lowercase() in VIDEO_EXT }
    d.isVisible = true
    return d.file?.let { File(d.directory, it) }
}

private fun pickFolder(): File? {
    val c = javax.swing.JFileChooser(File(System.getProperty("user.home")))
    c.fileSelectionMode = javax.swing.JFileChooser.DIRECTORIES_ONLY
    c.dialogTitle = "Add a music / video folder to the library"
    return if (c.showOpenDialog(null) == javax.swing.JFileChooser.APPROVE_OPTION) c.selectedFile else null
}

/** Double-click in the library: the first empty deck, otherwise the deck that is not playing. */
private fun loadAuto(t: LibTrack) {
    val a = Decks.a; val b = Decks.b
    val target = if (a.dur <= 0f) a else if (b.dur <= 0f) b else if (a.playing && !b.playing) b else if (b.playing && !a.playing) a else b
    target.load(t.file)
}

fun main() = application {
    val lib = remember { Native_.lib }
    val a = Decks.a
    val b = Decks.b
    var cross by remember { mutableFloatStateOf(0.5f) }
    var master by remember { mutableFloatStateOf(1f) }
    var bassAmp by remember { mutableFloatStateOf(0.5f) }
    var level by remember { mutableFloatStateOf(0f) }
    var recording by remember { mutableStateOf(false) }
    var engineOk by remember { mutableStateOf(true) }
    var videoOpen by remember { mutableStateOf(false) }
    var outputOpen by remember { mutableStateOf(false) }
    var frame by remember { mutableStateOf<ImageBitmap?>(null) }
    var vidRec by remember { mutableStateOf(false) }
    var blend by remember { mutableIntStateOf(0) }
    var follow by remember { mutableStateOf(true) }
    var manualX by remember { mutableFloatStateOf(0.5f) }

    LaunchedEffect(Unit) {
        engineOk = lib.dj_start() == 1
        lib.dj_set_master_gain(master); lib.dj_set_bass_amp(bassAmp); lib.dj_set_crossfader(cross)
        Library.start()
        // 25 updates a second is plenty for a playhead and a meter (it was 30); a paused deck does not redraw at all
        while (true) { a.poll(); b.poll(); level = lib.dj_get_level(); delay(40) }
    }
    // the mixed picture, 30 times a second, only while something looks at it or records it
    LaunchedEffect(videoOpen, outputOpen, vidRec) {
        while (videoOpen || outputOpen || vidRec) {
            val bmp = withContext(Dispatchers.Default) { VideoMixer.compose()?.toComposeImageBitmap() }
            if (bmp != null) frame = bmp
            delay(33)
        }
    }

    if (outputOpen) OutputWindow(frame) { outputOpen = false }

    Window(
        onCloseRequest = { MixRecorder.stop(); lib.dj_stop_recording(); lib.dj_stop(); exitApplication() },
        title = "MAXIDO DJ - free for PC",
        state = rememberWindowState(placement = WindowPlacement.Maximized)
    ) {
        MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
            Column(Modifier.fillMaxSize().background(Bg)) {
                TopBar(level, recording, videoOpen, engineOk, { videoOpen = !videoOpen }) {
                    if (recording) { lib.dj_stop_recording(); recording = false }
                    else {
                        val dir = File(System.getProperty("user.home"), "Music/MAXIDO DJ").apply { mkdirs() }
                        val f = File(dir, "mix-${System.currentTimeMillis() / 1000}.wav")
                        recording = lib.dj_start_recording(f.absolutePath) == 1
                    }
                }
                WaveStrip(a, "A", DeckBlue)
                WaveStrip(b, "B", DeckRed)
                Row(Modifier.fillMaxWidth().weight(0.54f).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    DeckPanel(a, b, "A", DeckBlue, Modifier.weight(1f))
                    MixerPanel(
                        a, b, cross, { cross = it; lib.dj_set_crossfader(it); VideoMixer.audioCross = it },
                        master, { master = it; lib.dj_set_master_gain(it) },
                        bassAmp, { bassAmp = it; lib.dj_set_bass_amp(it) }
                    )
                    DeckPanel(b, a, "B", DeckRed, Modifier.weight(1f))
                }
                if (videoOpen) VideoPanel(
                    frame, blend, { blend = it; VideoMixer.blend = it }, follow, { follow = it; VideoMixer.followCross = it },
                    manualX, { manualX = it; VideoMixer.manualCross = it }, outputOpen, { outputOpen = !outputOpen }, vidRec
                ) {
                    if (MixRecorder.recording) { MixRecorder.stop(); vidRec = false }
                    else {
                        val dir = File(System.getProperty("user.home"), "Videos/MAXIDO DJ").apply { mkdirs() }
                        MixRecorder.start(File(dir, "videomix-${System.currentTimeMillis() / 1000}.mp4"))
                        vidRec = MixRecorder.recording
                    }
                }
                LibraryPane(Modifier.fillMaxWidth().weight(0.46f).padding(4.dp))
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------ small building blocks

@Composable
private fun SmallBtn(
    text: String, modifier: Modifier = Modifier, active: Boolean = false, activeColor: Color = Accent,
    enabled: Boolean = true, onClick: () -> Unit
) {
    Button(
        onClick = onClick, enabled = enabled, modifier = modifier.height(30.dp),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp), shape = RoundedCornerShape(4.dp),
        colors = ButtonDefaults.buttonColors(containerColor = if (active) activeColor else Btn, disabledContainerColor = Color(0xFF14171C))
    ) {
        val fg = if (!enabled) TextGray else if (active && activeColor == Accent) Color.Black else Color.White
        Text(text, fontSize = 11.sp, color = fg, maxLines = 1)
    }
}

/** A round knob: drag up / down to turn, double-click to reset. */
@Composable
private fun Knob(label: String, value: Float, min: Float, max: Float, def: Float, color: Color, onChange: (Float) -> Unit) {
    val v by rememberUpdatedState(value)
    val cb by rememberUpdatedState(onChange)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier.size(34.dp)
                .pointerInput(Unit) { detectDragGestures { change, drag -> change.consume(); cb((v - drag.y / 140f * (max - min)).coerceIn(min, max)) } }
                .pointerInput(Unit) { detectTapGestures(onDoubleTap = { cb(def) }) }
        ) {
            val frac = ((value - min) / (max - min)).coerceIn(0f, 1f)
            val pad = 4f
            val arcSize = Size(size.width - 2 * pad, size.height - 2 * pad)
            drawArc(color = Color(0xFF2A303A), startAngle = 135f, sweepAngle = 270f, useCenter = false, topLeft = Offset(pad, pad), size = arcSize, style = Stroke(width = 4f))
            drawArc(color = color, startAngle = 135f, sweepAngle = 270f * frac, useCenter = false, topLeft = Offset(pad, pad), size = arcSize, style = Stroke(width = 4f))
            val ang = Math.toRadians(135.0 + 270.0 * frac)
            val r = size.minDimension / 2f
            drawLine(
                Color.White,
                Offset(center.x + (Math.cos(ang) * r * 0.25).toFloat(), center.y + (Math.sin(ang) * r * 0.25).toFloat()),
                Offset(center.x + (Math.cos(ang) * r * 0.7).toFloat(), center.y + (Math.sin(ang) * r * 0.7).toFloat()),
                strokeWidth = 3f
            )
        }
        Text(label, color = TextGray, fontSize = 9.sp, maxLines = 1)
    }
}

/** A vertical channel fader: drag or click. */
@Composable
private fun VFader(value: Float, color: Color, modifier: Modifier, onChange: (Float) -> Unit) {
    val cb by rememberUpdatedState(onChange)
    Canvas(
        modifier.width(34.dp)
            .pointerInput(Unit) { detectDragGestures { change, _ -> change.consume(); cb((1f - change.position.y / size.height).coerceIn(0f, 1f)) } }
            .pointerInput(Unit) { detectTapGestures { o -> cb((1f - o.y / size.height).coerceIn(0f, 1f)) } }
    ) {
        drawRect(Color(0xFF07090C), topLeft = Offset(size.width / 2f - 2f, 0f), size = Size(4f, size.height))
        val y = size.height * (1f - value.coerceIn(0f, 1f))
        drawRect(color, topLeft = Offset(3f, (y - 8f).coerceIn(0f, size.height - 16f)), size = Size(size.width - 6f, 16f))
    }
}

// ------------------------------------------------------------------------------------------------ top bar

@Composable
private fun TopBar(level: Float, recording: Boolean, videoOpen: Boolean, engineOk: Boolean, onVideo: () -> Unit, onRec: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(42.dp).background(Panel).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("MAXIDO DJ", color = Accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("free for PC", color = TextGray, fontSize = 11.sp)
        if (!engineOk) Text("No audio output device found. Plug in speakers or headphones and restart.", color = DeckRed, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        Text("STEMS CPU", color = TextGray, fontSize = 10.sp)
        SmallBtn("ECO (cool)", active = Decks.power == 0) { Decks.power = 0 }
        SmallBtn("BALANCED", active = Decks.power == 1) { Decks.power = 1 }
        SmallBtn("FAST", active = Decks.power == 2, activeColor = DeckRed) { Decks.power = 2 }
        Switch(Decks.autoStems, { Decks.autoStems = it })
        Text("AUTO STEMS", color = TextGray, fontSize = 10.sp)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.width(150.dp)) { Meter(level) }
        SmallBtn("VIDEO", active = videoOpen, onClick = onVideo)
        SmallBtn(if (recording) "STOP REC" else "REC", active = recording, activeColor = DeckRed, onClick = onRec)
    }
}

// ------------------------------------------------------------------------------------------------ waveform strip

@Composable
private fun WaveStrip(d: DeckModel, label: String, color: Color) {
    Box(Modifier.fillMaxWidth().height(46.dp).background(Color(0xFF07090C)).padding(vertical = 1.dp)) {
        Canvas(Modifier.fillMaxSize().pointerInput(d) { detectTapGestures { o -> if (d.dur > 0f) d.seekTo(o.x / size.width * d.dur) } }) {
            val w = size.width
            val h = size.height
            val mid = h / 2f
            val pk = d.peaks
            if (pk != null && pk.isNotEmpty()) {
                val played = if (d.dur > 0f) (d.pos / d.dur).coerceIn(0f, 1f) else 0f
                val cols = w.toInt().coerceAtLeast(1)
                val dim = color.copy(alpha = 0.40f)
                var x = 0
                while (x < cols) {
                    val v = pk[(x.toFloat() / cols * pk.size).toInt().coerceIn(0, pk.size - 1)]
                    val amp = (v * mid).coerceAtLeast(1f)
                    drawLine(if (x.toFloat() / w < played) dim else color, Offset(x.toFloat(), mid - amp), Offset(x.toFloat(), mid + amp), strokeWidth = 2f)
                    x += 2
                }
                val px = played * w
                drawLine(Color.White, Offset(px, 0f), Offset(px, h), strokeWidth = 2f)
            } else {
                drawLine(Line, Offset(0f, mid), Offset(w, mid), strokeWidth = 1f)
            }
        }
        Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp, top = 2.dp).align(Alignment.TopStart))
    }
}

// ------------------------------------------------------------------------------------------------ deck

@Composable
private fun DeckPanel(d: DeckModel, other: DeckModel, label: String, color: Color, modifier: Modifier) {
    Column(
        modifier.fillMaxHeight().background(Panel, RoundedCornerShape(6.dp)).border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
            .verticalScroll(rememberScrollState()).padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            // jog wheel: turns while the track plays, click it to play / pause
            Canvas(Modifier.size(132.dp).pointerInput(d) { detectTapGestures { if (d.dur > 0f) d.togglePlay() } }) {
                val c = center
                val r = size.minDimension / 2f
                drawCircle(Color(0xFF0C0E12), r, c)
                drawCircle(Color(0xFF1B2027), r * 0.66f, c)
                if (d.dur > 0f) {
                    val frac = (d.pos / d.dur).coerceIn(0f, 1f)
                    drawArc(color = color, startAngle = -90f, sweepAngle = 360f * frac, useCenter = false, topLeft = Offset(4f, 4f), size = Size(size.width - 8f, size.height - 8f), style = Stroke(width = 5f))
                }
                val ang = Math.toRadians(d.pos * 200.0 - 90.0)
                drawLine(
                    Color.White,
                    Offset(c.x + (Math.cos(ang) * r * 0.30).toFloat(), c.y + (Math.sin(ang) * r * 0.30).toFloat()),
                    Offset(c.x + (Math.cos(ang) * r * 0.62).toFloat(), c.y + (Math.sin(ang) * r * 0.62).toFloat()),
                    strokeWidth = 4f
                )
                drawCircle(if (d.playing) color else Color(0xFF2A303A), r * 0.10f, c)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(24.dp).background(color, RoundedCornerShape(4.dp)), contentAlignment = Alignment.Center) { Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
                    Spacer(Modifier.width(8.dp))
                    Text(d.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (d.liveBpm > 0f) "%.1f".format(d.liveBpm) else "--", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    Text("BPM", color = TextGray, fontSize = 10.sp)
                    Text(if (d.key.isNotEmpty()) d.key else "--", color = Accent, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("KEY", color = TextGray, fontSize = 10.sp)
                }
                Text(
                    if (d.status.isNotEmpty()) d.status else "${mmss(d.pos)}  /  -${mmss(d.dur - d.pos)}",
                    color = TextGray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SmallBtn("LOAD", active = true, activeColor = color) { pickFile()?.let { d.load(it) } }
                    SmallBtn("CUE", enabled = d.dur > 0f) { d.cuePress() }
                    SmallBtn(if (d.playing) "PAUSE" else "PLAY", active = d.playing, activeColor = color, enabled = d.dur > 0f) { d.togglePlay() }
                    SmallBtn("SYNC", active = d.synced, enabled = d.bpm > 0f && other.bpm > 0f) { if (d.synced) d.setTempo(d.tempoPct) else d.syncTo(other) }
                }
                Labeled("TEMPO  ${"%+.1f".format(d.tempoPct * 100)}%") {
                    Slider(d.tempoPct, { d.setTempo(if (kotlin.math.abs(it) < 0.002f) 0f else it) }, valueRange = -0.08f..0.08f)
                }
            }
        }
        // ---- stems (VOCAL / MELODY / BASS / DRUMS like the pro layouts)
        val stemOrder = intArrayOf(0, 3, 2, 1)
        val stemName = arrayOf("VOCAL", "DRUMS", "BASS", "MELODY")
        val stemColor = arrayOf(Color(0xFFD7263D), Color(0xFFE8A33D), Color(0xFFB5179E), Color(0xFF2BB673))
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            for (i in stemOrder) {
                SmallBtn(stemName[i], modifier = Modifier.weight(1f), active = d.stemsReady && d.stemOn[i], activeColor = stemColor[i], enabled = d.stemsReady) { d.toggleStem(i) }
            }
        }
        if (d.stemsReady) Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            SmallBtn("ACAPELLA", modifier = Modifier.weight(1f)) { d.stemPreset(true, false, false, false) }
            SmallBtn("NO VOCALS", modifier = Modifier.weight(1f)) { d.stemPreset(false, true, true, true) }
            SmallBtn("BEATLESS", modifier = Modifier.weight(1f)) { d.stemPreset(true, false, true, true) }
            SmallBtn("ALL", modifier = Modifier.weight(1f)) { d.stemPreset(true, true, true, true) }
        } else if (d.preparing) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LinearProgressIndicator(progress = { d.stemProgress }, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(8.dp)); Text("stems ${(d.stemProgress * 100).toInt()}%", color = TextGray, fontSize = 11.sp)
            }
        } else if (d.dur > 0f) SmallBtn("PREPARE STEMS", modifier = Modifier.fillMaxWidth()) { d.prepareStems() }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            SmallBtn("VIDEO + SOUND") { pickVideo()?.let { d.load(it) } }
            SmallBtn("SILENT LOOP") { pickVideo()?.let { VideoMixer.layers[d.id].load(it, false) } }
            SmallBtn("X") { VideoMixer.layers[d.id].clear() }
        }
    }
}

// ------------------------------------------------------------------------------------------------ mixer

@Composable
private fun MixerPanel(
    a: DeckModel, b: DeckModel, cross: Float, onCross: (Float) -> Unit, master: Float, onMaster: (Float) -> Unit,
    bassAmp: Float, onBassAmp: (Float) -> Unit
) {
    fun dead(v: Float) = if (kotlin.math.abs(v) < 0.6f) 0f else v
    @Composable
    fun Channel(d: DeckModel, color: Color) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Knob("TREBLE", d.treble, -26f, 12f, 0f, color) { d.applyTreble(dead(it)) }
            Knob("MID", d.mid, -26f, 12f, 0f, color) { d.applyMid(dead(it)) }
            Knob("BASS", d.bass, -26f, 12f, 0f, color) { d.applyBass(dead(it)) }
            Knob("FILTER", d.filter, -1f, 1f, 0f, color) { d.applyFilter(it) }
        }
    }
    Column(
        Modifier.width(290.dp).fillMaxHeight().background(Panel, RoundedCornerShape(6.dp)).border(1.dp, Line, RoundedCornerShape(6.dp))
            .verticalScroll(rememberScrollState()).padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp), horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth().height(190.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Channel(a, DeckBlue)
            VFader(a.volume, DeckBlue, Modifier.fillMaxHeight()) { a.applyVolume(it) }
            VFader(b.volume, DeckRed, Modifier.fillMaxHeight()) { b.applyVolume(it) }
            Channel(b, DeckRed)
        }
        Labeled("MASTER  ${(master * 100).toInt()}%") { Slider(master, onMaster, valueRange = 0.25f..1.25f) }
        Labeled("BASS AMP  ${(bassAmp * 100).toInt()}%") { Slider(bassAmp, onBassAmp, valueRange = 0f..1f) }
        Labeled("CROSSFADER") { Slider(cross, onCross) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("A", color = DeckBlue); Text("B", color = DeckRed) }
    }
}

// ------------------------------------------------------------------------------------------------ library

@Composable
private fun LibraryPane(modifier: Modifier) {
    var query by remember { mutableStateOf("") }
    var sortCol by remember { mutableIntStateOf(0) }
    var asc by remember { mutableStateOf(true) }
    var folder by remember { mutableStateOf<File?>(null) }
    var selected by remember { mutableStateOf<LibTrack?>(null) }

    val list by remember {
        derivedStateOf {
            var l: List<LibTrack> = Library.tracks.toList()
            val f = folder
            if (f != null) l = l.filter { it.file.path.startsWith(f.path) }
            val q = query.trim().lowercase()
            if (q.isNotEmpty()) l = l.filter { (it.title + " " + it.artist).lowercase().contains(q) }
            val cmp: Comparator<LibTrack> = when (sortCol) {
                0 -> compareBy<LibTrack> { it.title.lowercase() }
                1 -> compareBy<LibTrack> { it.artist.lowercase() }
                2 -> compareBy<LibTrack> { it.dur }
                3 -> compareBy<LibTrack> { it.bpm }
                else -> compareBy<LibTrack> { it.key }
            }
            l.sortedWith(if (asc) cmp else cmp.reversed())
        }
    }

    fun sortBy(c: Int) { if (sortCol == c) asc = !asc else { sortCol = c; asc = true } }

    Row(modifier, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        // ---- folders
        Column(Modifier.width(190.dp).fillMaxHeight().background(Panel, RoundedCornerShape(6.dp)).padding(6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("FOLDERS", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(
                "All files (${Library.tracks.size})", color = if (folder == null) Accent else Color.White, fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().clickable { folder = null }.padding(vertical = 3.dp)
            )
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                for (f in Library.folders.toList()) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            f.name.ifEmpty { f.path }, color = if (folder?.path == f.path) Accent else Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f).clickable { folder = f }.padding(vertical = 3.dp)
                        )
                        Text("x", color = TextGray, fontSize = 12.sp, modifier = Modifier.clickable { if (folder?.path == f.path) folder = null; Library.removeFolder(f) }.padding(horizontal = 6.dp))
                    }
                }
            }
            SmallBtn("+ ADD FOLDER", modifier = Modifier.fillMaxWidth()) { pickFolder()?.let { Library.addFolder(it) } }
        }
        // ---- table
        Column(Modifier.weight(1f).fillMaxHeight().background(Panel, RoundedCornerShape(6.dp)).padding(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BasicTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 13.sp), cursorBrush = SolidColor(Accent),
                    modifier = Modifier.weight(1f).height(28.dp).background(Color(0xFF0A0C10), RoundedCornerShape(4.dp)).padding(horizontal = 8.dp, vertical = 5.dp),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (query.isEmpty()) Text("Search title or artist...", color = TextGray, fontSize = 13.sp)
                            inner()
                        }
                    }
                )
                Text("${list.size} files", color = TextGray, fontSize = 11.sp)
                SmallBtn("RESCAN", enabled = !Library.scanning) { Library.scan() }
            }
            Row(Modifier.fillMaxWidth().background(Color(0xFF1D222A)).padding(horizontal = 6.dp, vertical = 3.dp)) {
                val names = listOf("Title", "Artist", "Length", "BPM", "Key")
                val weights = listOf(4f, 3f, 1f, 0.9f, 0.8f)
                for (i in names.indices) {
                    val arrow = if (sortCol == i) (if (asc) " ▲" else " ▼") else ""
                    Text(names[i] + arrow, color = if (sortCol == i) Accent else TextGray, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                        modifier = Modifier.weight(weights[i]).clickable { sortBy(i) })
                }
                Spacer(Modifier.width(58.dp))
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.file.path }) { t ->
                    val isSel = selected === t
                    Row(
                        Modifier.fillMaxWidth().height(24.dp).background(if (isSel) Color(0xFF2A3342) else Color.Transparent)
                            .pointerInput(t) { detectTapGestures(onTap = { selected = t }, onDoubleTap = { selected = t; loadAuto(t) }) }
                            .padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val onA = Decks.a.loadedFile == t.file
                        val onB = Decks.b.loadedFile == t.file
                        val col = if (onA) DeckBlue else if (onB) DeckRed else Color.White
                        Text(t.title, color = col, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(4f))
                        Text(t.artist, color = if (onA || onB) col else TextGray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(3f))
                        Text(if (t.dur > 0.5f) mmss(t.dur) else "", color = TextGray, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text(if (t.bpm > 0f) "%.1f".format(t.bpm) else "", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(0.9f))
                        Text(t.key, color = Accent, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                        Text("A", color = DeckBlue, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.clickable { Decks.a.load(t.file) }.padding(horizontal = 10.dp))
                        Text("B", color = DeckRed, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.clickable { Decks.b.load(t.file) }.padding(horizontal = 10.dp))
                    }
                }
            }
        }
        // ---- info
        Column(Modifier.width(250.dp).fillMaxHeight().background(Panel, RoundedCornerShape(6.dp)).padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            val s = selected
            Text("INFO", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            if (s != null) {
                Text(s.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (s.artist.isNotEmpty()) Text(s.artist, color = TextGray, fontSize = 12.sp, maxLines = 1)
                Text(
                    buildString {
                        if (s.bpm > 0f) append("%.1f BPM".format(s.bpm))
                        if (s.key.isNotEmpty()) append("    KEY ${s.key}")
                        if (s.dur > 0.5f) append("    ${mmss(s.dur)}")
                    }.ifEmpty { "Not analysed yet. Load it on a deck, or press ANALYZE ALL." },
                    color = TextGray, fontSize = 12.sp
                )
            } else Text("Click a track. Double-click loads it on a free deck, or use the A / B buttons.", color = TextGray, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            if (Library.analyzing) {
                LinearProgressIndicator(progress = { if (Library.analyzeTotal > 0) Library.analyzeDone.toFloat() / Library.analyzeTotal else 0f }, modifier = Modifier.fillMaxWidth())
                Text("Analysing ${Library.analyzeDone} / ${Library.analyzeTotal} (one track at a time, easy on the CPU)", color = TextGray, fontSize = 11.sp)
                SmallBtn("STOP", modifier = Modifier.fillMaxWidth(), active = true, activeColor = DeckRed) { Library.stopAnalyzing() }
            } else {
                SmallBtn("ANALYZE ALL (BPM + KEY)", modifier = Modifier.fillMaxWidth()) { Library.analyzeAll() }
            }
            if (Library.scanning) Text("Scanning folders...", color = TextGray, fontSize = 11.sp)
        }
    }
}

/** A second window that shows only the mixed picture: drag it to the projector / TV, double-click for full screen. */
@Composable
private fun OutputWindow(frame: ImageBitmap?, onClose: () -> Unit) {
    val st = rememberWindowState(width = 960.dp, height = 540.dp)
    Window(onCloseRequest = onClose, title = "MAXIDO DJ - video output", state = st) {
        Box(
            Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) {
                detectTapGestures(onDoubleTap = { st.placement = if (st.placement == WindowPlacement.Fullscreen) WindowPlacement.Floating else WindowPlacement.Fullscreen })
            }
        ) { if (frame != null) Image(frame, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
    }
}

@Composable
private fun VideoPanel(
    frame: ImageBitmap?, blend: Int, onBlend: (Int) -> Unit, follow: Boolean, onFollow: (Boolean) -> Unit,
    manualX: Float, onManual: (Float) -> Unit, outputOpen: Boolean, onOutput: () -> Unit, recording: Boolean, onRec: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().height(250.dp).background(Panel, RoundedCornerShape(10.dp)).border(1.dp, Line, RoundedCornerShape(10.dp)).padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(Modifier.aspectRatio(16f / 9f).fillMaxHeight().background(Color.Black)) {
            if (frame != null) Image(frame, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            else Text("Load a video on a deck", color = TextGray, modifier = Modifier.align(Alignment.Center), fontSize = 12.sp)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("VIDEO MIXER", color = Accent, fontWeight = FontWeight.Bold)
            Text("On each deck: VIDEO + SOUND plays a video file as the track (picture locked to the deck: play, cue, scratch, tempo). SILENT LOOP adds a picture-only clip.", color = TextGray, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("BLEND", "DIP TO BLACK", "CUT").forEachIndexed { i, t ->
                    Button(onClick = { onBlend(i) }, colors = ButtonDefaults.buttonColors(containerColor = if (blend == i) Accent else Color(0xFF1D222C))) { Text(t, color = if (blend == i) Color.Black else Color.White, fontSize = 11.sp) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { onFollow(true) }, colors = ButtonDefaults.buttonColors(containerColor = if (follow) Accent else Color(0xFF1D222C))) { Text("XFADER", color = if (follow) Color.Black else Color.White, fontSize = 11.sp) }
                Button(onClick = { onFollow(false) }, colors = ButtonDefaults.buttonColors(containerColor = if (!follow) Accent else Color(0xFF1D222C))) { Text("MANUAL", color = if (!follow) Color.Black else Color.White, fontSize = 11.sp) }
                if (!follow) Slider(manualX, onManual, modifier = Modifier.width(180.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onOutput, colors = ButtonDefaults.buttonColors(containerColor = if (outputOpen) Accent else Color(0xFF1D222C))) { Text("OUTPUT WINDOW", color = if (outputOpen) Color.Black else Color.White, fontSize = 11.sp) }
                Button(onClick = onRec, colors = ButtonDefaults.buttonColors(containerColor = if (recording) DeckRed else Color(0xFF1D222C))) { Text(if (recording) "STOP VIDEO REC" else "REC VIDEO MIX", color = Color.White, fontSize = 11.sp) }
            }
            Text(
                if (MixRecorder.info.isNotEmpty()) MixRecorder.info else "REC VIDEO MIX saves picture + master sound (bass amp included) as MP4 in Videos\\MAXIDO DJ. Double-click the output window for full screen.",
                color = TextGray, fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun Meter(level: Float) {
    Canvas(Modifier.fillMaxWidth().height(14.dp)) {
        drawRect(Color(0xFF131720), size = size)
        val w = size.width * level.coerceIn(0f, 1f)
        drawRect(if (level > 0.93f) DeckRed else Accent, size = Size(w, size.height))
    }
}

@Composable
private fun Labeled(label: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth()) { Text(label, color = TextGray, fontSize = 11.sp); content() }
}

