package com.example.djapp

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

private val LIB_AUDIO_EXT = setOf("mp3", "wav", "flac", "ogg", "m4a", "aac")

/** One file in the library. Length / BPM / key are filled in by the analyser or when the track is loaded on a deck. */
class LibTrack(val file: File) {
    val title: String
    val artist: String

    init {
        val base = file.nameWithoutExtension.replace('_', ' ').trim()
        val i = base.indexOf(" - ")
        if (i > 0) { artist = base.substring(0, i).trim(); title = base.substring(i + 3).trim() }
        else { artist = ""; title = base }
    }

    var dur by mutableFloatStateOf(0f)
    var bpm by mutableFloatStateOf(0f)
    var key by mutableStateOf("")
}

/** The program's own library: music folders, a fast scan, and a small file that remembers every analysed BPM / key / length. */
object Library {
    private val home: File = File(System.getProperty("user.home"), ".maxido-dj").apply { mkdirs() }
    private val foldersFile = File(home, "folders.txt")
    private val dbFile = File(home, "library.tsv")

    val folders = mutableStateListOf<File>()
    val tracks = mutableStateListOf<LibTrack>()
    var scanning by mutableStateOf(false)
    var analyzing by mutableStateOf(false)
    var analyzeDone by mutableIntStateOf(0)
    var analyzeTotal by mutableIntStateOf(0)

    @Volatile private var stopAnalyze = false
    @Volatile private var byPath: Map<String, LibTrack> = emptyMap()
    // path -> [mtime, dur, bpm, key]
    private val db = java.util.concurrent.ConcurrentHashMap<String, Array<String>>()
    private var started = false

    fun start() {
        if (started) return
        started = true
        try {
            if (foldersFile.exists()) foldersFile.readLines().map { it.trim() }.filter { it.isNotEmpty() }.map { File(it) }.filter { it.isDirectory }.forEach { folders.add(it) }
        } catch (_: Exception) {}
        if (folders.isEmpty()) {
            val h = System.getProperty("user.home")
            for (n in listOf("Music", "Videos")) { val d = File(h, n); if (d.isDirectory) folders.add(d) }
            saveFolders()
        }
        try {
            if (dbFile.exists()) dbFile.readLines().forEach { line ->
                val p = line.split('\t')
                if (p.size >= 5) db[p[0]] = arrayOf(p[1], p[2], p[3], p[4])
            }
        } catch (_: Exception) {}
        scan()
    }

    private fun saveFolders() { try { foldersFile.writeText(folders.joinToString("\n") { it.absolutePath }) } catch (_: Exception) {} }

    @Synchronized private fun saveDb() {
        try { dbFile.writeText(db.entries.joinToString("\n") { (k, v) -> k + "\t" + v.joinToString("\t") }) } catch (_: Exception) {}
    }

    fun addFolder(f: File) {
        if (!f.isDirectory || folders.any { it.absolutePath == f.absolutePath }) return
        folders.add(f); saveFolders(); scan()
    }

    fun removeFolder(f: File) { folders.remove(f); saveFolders(); scan() }

    fun scan() {
        if (scanning) return
        scanning = true
        val roots = folders.toList()
        Thread {
            try {
                val out = ArrayList<LibTrack>()
                val seen = HashSet<String>()
                for (root in roots) {
                    if (!root.isDirectory) continue
                    for (f in root.walkTopDown().maxDepth(10)) {
                        if (out.size >= 50000) break
                        if (!f.isFile) continue
                        val ext = f.extension.lowercase()
                        if (ext !in LIB_AUDIO_EXT && ext !in VIDEO_EXT) continue
                        if (!seen.add(f.absolutePath)) continue
                        val t = LibTrack(f)
                        val rec = db[f.absolutePath]
                        if (rec != null && rec[0] == f.lastModified().toString()) {
                            t.dur = rec[1].toFloatOrNull() ?: 0f
                            t.bpm = rec[2].toFloatOrNull() ?: 0f
                            t.key = rec[3]
                        }
                        out.add(t)
                    }
                }
                byPath = out.associateBy { it.file.absolutePath }
                tracks.clear(); tracks.addAll(out)
            } catch (_: Throwable) {
            } finally { scanning = false }
        }.apply { isDaemon = true; priority = Thread.MIN_PRIORITY; name = "library-scan" }.start()
    }

    /** Called when a track has been analysed (on a deck or by ANALYZE ALL). */
    fun record(file: File, dur: Float, bpm: Float, key: String) {
        db[file.absolutePath] = arrayOf(file.lastModified().toString(), dur.toString(), bpm.toString(), key)
        byPath[file.absolutePath]?.let { it.dur = dur; it.bpm = bpm; it.key = key }
        saveDb()
    }

    fun stopAnalyzing() { stopAnalyze = true }

    /**
     * Analyses every track that has no length yet, one at a time, on one low-priority thread with a short rest between tracks,
     * so the laptop stays cool. The decoded copy is deleted again afterwards (it would take about 30 MB per track).
     */
    fun analyzeAll() {
        if (analyzing) return
        val todo = tracks.filter { it.dur <= 0f }
        if (todo.isEmpty()) return
        analyzing = true; stopAnalyze = false; analyzeDone = 0; analyzeTotal = todo.size
        Thread {
            try {
                for (t in todo) {
                    if (stopAnalyze) break
                    try { analyzeOne(t.file) } catch (_: Throwable) {}
                    analyzeDone++
                    var rest = 0
                    while (rest < 500 && !stopAnalyze) { Thread.sleep(50); rest += 50 }
                }
            } finally { analyzing = false }
        }.apply { isDaemon = true; priority = Thread.MIN_PRIORITY; name = "library-analyze" }.start()
    }

    private fun analyzeOne(file: File) {
        val raw = TrackCache.rawFor(file)
        val rateFile = File(raw.path + ".rate")
        val existed = raw.exists() && raw.length() > 1000
        var rate = if (existed) (try { rateFile.readText().trim().toInt() } catch (_: Exception) { 0 }) else 0
        if (rate <= 0) {
            val video = isVideoFile(file)
            rate = if (video) 0 else Native_.lib.dj_decode_to_raw(file.absolutePath, raw.absolutePath)
            if (rate <= 0) rate = Ffmpeg.audioToRaw(file, raw)
            if (rate > 0) rateFile.writeText(rate.toString())
        }
        if (rate <= 0) {
            record(file, 0.001f, 0f, "")      // unreadable: do not try it again every time
            return
        }
        val grid = BpmDetector.grid(raw, rate)
        val key = KeyDetector.detect(raw, rate)?.camelot ?: ""
        val dur = (raw.length() / 4.0 / rate).toFloat()
        record(file, dur, grid?.bpm ?: 0f, key)
        if (!existed) { raw.delete(); rateFile.delete() }
    }
}

/** Overview waveform: the loudest sample of each slice of the track (reads the decoded 16-bit stereo copy). */
object Peaks {
    fun compute(raw: File, bins: Int = 1200): FloatArray {
        val out = FloatArray(bins)
        try {
            RandomAccessFile(raw, "r").use { f ->
                val frames = f.length() / 4
                if (frames <= 0 || frames * 4 > Int.MAX_VALUE.toLong()) return out
                val mb: ByteBuffer = f.channel.map(FileChannel.MapMode.READ_ONLY, 0, frames * 4)
                mb.order(ByteOrder.LITTLE_ENDIAN)
                val per = frames.toDouble() / bins
                for (b in 0 until bins) {
                    val s = (b * per).toLong()
                    val e = minOf(frames, ((b + 1) * per).toLong()).coerceAtLeast(s + 1)
                    val step = maxOf(1L, (e - s) / 48)
                    var m = 0
                    var i = s
                    while (i < e) {
                        val v = Math.abs(mb.getShort((i * 4).toInt()).toInt())
                        if (v > m) m = v
                        i += step
                    }
                    out[b] = m / 32768f
                }
            }
        } catch (_: Throwable) {}
        return out
    }
}
