package com.example.djapp

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File
import javax.sound.midi.MidiDevice
import javax.sound.midi.MidiMessage
import javax.sound.midi.MidiSystem
import javax.sound.midi.Receiver
import javax.sound.midi.Sequencer
import javax.sound.midi.ShortMessage
import javax.sound.midi.Synthesizer
import java.awt.event.KeyEvent as AwtKey

/** Crossfader, master volume and bass amp live here, so the on-screen sliders, the keyboard and MIDI controllers all move the same thing. */
object Mix {
    var cross by mutableFloatStateOf(0.5f)
    var master by mutableFloatStateOf(1f)
    var bassAmp by mutableFloatStateOf(0.5f)

    fun apply() {
        val l = Native_.lib
        l.dj_set_master_gain(master); l.dj_set_bass_amp(bassAmp); l.dj_set_crossfader(cross)
        VideoMixer.audioCross = cross
    }
    fun setCross(v: Float) { cross = v.coerceIn(0f, 1f); Native_.lib.dj_set_crossfader(cross); VideoMixer.audioCross = cross }
    fun setMaster(v: Float) { master = v.coerceIn(0.25f, 1.25f); Native_.lib.dj_set_master_gain(master) }
    fun setBassAmp(v: Float) { bassAmp = v.coerceIn(0f, 1f); Native_.lib.dj_set_bass_amp(bassAmp) }
}

/** One thing a key or a MIDI control can do. Buttons run once per press; knobs get 0..1. */
class Action(val id: String, val group: String, val label: String, val knob: Boolean, val run: (Float) -> Unit)

/**
 * Keyboard + MIDI mapping. An input has a code: "K:<key>" (computer key), "N:<channel>:<note>" (MIDI pad / button),
 * "C:<channel>:<controller>" (MIDI knob / fader / button sending CC), "P:<channel>" (MIDI pitch fader).
 * LEARN: pick a function, press the key or touch the control, done. Mappings are saved in ~/.maxido-dj/controls.txt.
 */
object Controls {
    val groups = listOf("A", "B", "C", "D", "MIXER", "SAMPLER")
    val actions: List<Action> by lazy { buildActions() }
    private val byId: Map<String, Action> by lazy { actions.associateBy { it.id } }

    val bindings = mutableStateMapOf<String, String>()      // input code -> action id
    var learning by mutableStateOf<String?>(null)            // the action waiting for an input
    var lastInput by mutableStateOf("")
    @Volatile var typing = false                             // a text box has the focus: keys are typing, not shortcuts

    private val down: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()
    private val saveFile = File(System.getProperty("user.home"), ".maxido-dj/controls.txt")
    private var started = false

    fun start() {
        if (started) return
        started = true
        var loaded = false
        try {
            if (saveFile.exists()) {
                saveFile.readLines().forEach { line ->
                    val p = line.split('\t')
                    if (p.size >= 2 && byId.containsKey(p[1])) bindings[p[0]] = p[1]
                }
                loaded = bindings.isNotEmpty()
            }
        } catch (_: Throwable) {}
        if (!loaded) { bindings.putAll(defaultKeys()); save() }
        MidiService.rescan()
    }

    private fun eq(v: Float): Float {                          // knob centre = flat, left = cut, right = boost
        val db = if (v < 0.5f) -26f * (1f - v * 2f) else 12f * (v - 0.5f) * 2f
        return if (kotlin.math.abs(db) < 1.0f) 0f else db
    }

    private fun buildActions(): List<Action> {
        val out = ArrayList<Action>()
        val ds = Decks.all()
        val names = listOf("A", "B", "C", "D")
        for (i in 0..3) {
            val d = ds[i]; val g = names[i]; val p = "d$i"
            out.add(Action("$p.play", g, "Play / pause", false) { if (d.dur > 0f) d.togglePlay() })
            out.add(Action("$p.cue", g, "Cue", false) { if (d.dur > 0f) d.cuePress() })
            out.add(Action("$p.sync", g, "Sync to the other deck", false) {
                if (d.bpm > 0f) {
                    val o = ds.firstOrNull { it !== d && it.playing && it.bpm > 0f } ?: ds.firstOrNull { it !== d && it.bpm > 0f }
                    if (o != null) d.syncTo(o)
                }
            })
            out.add(Action("$p.loop", g, "Loop on / off", false) { d.toggleLoop() })
            out.add(Action("$p.loopin", g, "Loop IN", false) { d.loopIn() })
            out.add(Action("$p.loopout", g, "Loop OUT", false) { d.loopOut() })
            out.add(Action("$p.loopless", g, "Loop shorter (halve)", false) { d.setLoopBeats(d.loopBeats / 2) })
            out.add(Action("$p.loopmore", g, "Loop longer (double)", false) { d.setLoopBeats(d.loopBeats * 2) })
            out.add(Action("$p.keylock", g, "Key lock", false) { d.toggleKeylock() })
            val sn = listOf("Vocal", "Melody", "Bass", "Drums")
            val si = intArrayOf(0, 3, 2, 1)                    // button order -> stem index (0 vocal, 1 drums, 2 bass, 3 melody)
            for (k in 0..3) out.add(Action("$p.stem$k", g, "Stem on / off: ${sn[k]}", false) { d.toggleStem(si[k]) })
            val fn = listOf("Voc Echo", "Voc Reverb", "Instr Echo", "Instr Reverb")
            for (k in 0..3) out.add(Action("$p.fx$k", g, "Stem effect: ${fn[k]}", false) { d.toggleFx(k) })
            out.add(Action("$p.vol", g, "Channel volume", true) { d.applyVolume(it) })
            out.add(Action("$p.treble", g, "Treble knob", true) { d.applyTreble(eq(it)) })
            out.add(Action("$p.mid", g, "Mid knob", true) { d.applyMid(eq(it)) })
            out.add(Action("$p.bass", g, "Bass knob", true) { d.applyBass(eq(it)) })
            out.add(Action("$p.filter", g, "Filter knob", true) { d.applyFilter(it * 2f - 1f) })
            out.add(Action("$p.tempo", g, "Tempo fader", true) {
                val v = (it * 2f - 1f) * 0.08f
                d.setTempo(if (kotlin.math.abs(v) < 0.002f) 0f else v)
            })
        }
        out.add(Action("mix.cross", "MIXER", "Crossfader", true) { Mix.setCross(it) })
        out.add(Action("mix.cross.a", "MIXER", "Crossfader to the A / C side", false) { Mix.setCross(0f) })
        out.add(Action("mix.cross.mid", "MIXER", "Crossfader to the centre", false) { Mix.setCross(0.5f) })
        out.add(Action("mix.cross.b", "MIXER", "Crossfader to the B / D side", false) { Mix.setCross(1f) })
        out.add(Action("mix.cross.l", "MIXER", "Crossfader nudge left", false) { Mix.setCross(Mix.cross - 0.1f) })
        out.add(Action("mix.cross.r", "MIXER", "Crossfader nudge right", false) { Mix.setCross(Mix.cross + 0.1f) })
        out.add(Action("mix.master", "MIXER", "Master volume", true) { Mix.setMaster(0.25f + it) })
        out.add(Action("mix.bassamp", "MIXER", "Bass amp", true) { Mix.setBassAmp(it) })
        for (i in 0..7) out.add(Action("smp.pad$i", "SAMPLER", "Pad ${i + 1} of the current bank", false) { Sampler.padPress(i) })
        for (b in 0..3) out.add(Action("smp.bank$b", "SAMPLER", "Bank ${b + 1}", false) { Sampler.bank = b })
        out.add(Action("smp.prev", "SAMPLER", "Previous bank", false) { Sampler.bank = (Sampler.bank + 3) % 4 })
        out.add(Action("smp.next", "SAMPLER", "Next bank", false) { Sampler.bank = (Sampler.bank + 1) % 4 })
        out.add(Action("smp.vol", "SAMPLER", "Sampler volume", true) { Sampler.setVolume(it) })
        return out
    }

    /** Default keyboard layout: left hand = deck A, right hand = deck B, Z X / N M = decks C and D. */
    private fun defaultKeys(): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        fun k(vk: Int, id: String) { m["K:$vk"] = id }
        // deck A
        k(AwtKey.VK_Q, "d0.play"); k(AwtKey.VK_W, "d0.cue"); k(AwtKey.VK_E, "d0.sync"); k(AwtKey.VK_R, "d0.loop"); k(AwtKey.VK_T, "d0.keylock")
        k(AwtKey.VK_G, "d0.loopin"); k(AwtKey.VK_H, "d0.loopout"); k(AwtKey.VK_MINUS, "d0.loopless"); k(AwtKey.VK_EQUALS, "d0.loopmore")
        k(AwtKey.VK_1, "d0.stem0"); k(AwtKey.VK_2, "d0.stem1"); k(AwtKey.VK_3, "d0.stem2"); k(AwtKey.VK_4, "d0.stem3")
        k(AwtKey.VK_A, "d0.fx0"); k(AwtKey.VK_S, "d0.fx1"); k(AwtKey.VK_D, "d0.fx2"); k(AwtKey.VK_F, "d0.fx3")
        // deck B
        k(AwtKey.VK_U, "d1.play"); k(AwtKey.VK_I, "d1.cue"); k(AwtKey.VK_O, "d1.sync"); k(AwtKey.VK_P, "d1.loop"); k(AwtKey.VK_OPEN_BRACKET, "d1.keylock")
        k(AwtKey.VK_COMMA, "d1.loopless"); k(AwtKey.VK_PERIOD, "d1.loopmore")
        k(AwtKey.VK_7, "d1.stem0"); k(AwtKey.VK_8, "d1.stem1"); k(AwtKey.VK_9, "d1.stem2"); k(AwtKey.VK_0, "d1.stem3")
        k(AwtKey.VK_J, "d1.fx0"); k(AwtKey.VK_K, "d1.fx1"); k(AwtKey.VK_L, "d1.fx2"); k(AwtKey.VK_SEMICOLON, "d1.fx3")
        // decks C and D
        k(AwtKey.VK_Z, "d2.play"); k(AwtKey.VK_X, "d2.cue"); k(AwtKey.VK_N, "d3.play"); k(AwtKey.VK_M, "d3.cue")
        // crossfader and sampler
        k(AwtKey.VK_LEFT, "mix.cross.l"); k(AwtKey.VK_RIGHT, "mix.cross.r"); k(AwtKey.VK_DOWN, "mix.cross.mid")
        k(AwtKey.VK_HOME, "mix.cross.a"); k(AwtKey.VK_END, "mix.cross.b")
        val fkeys = intArrayOf(AwtKey.VK_F1, AwtKey.VK_F2, AwtKey.VK_F3, AwtKey.VK_F4, AwtKey.VK_F5, AwtKey.VK_F6, AwtKey.VK_F7, AwtKey.VK_F8)
        for (i in 0..7) k(fkeys[i], "smp.pad$i")
        k(AwtKey.VK_PAGE_UP, "smp.prev"); k(AwtKey.VK_PAGE_DOWN, "smp.next")
        return m
    }

    fun describe(code: String): String {
        val p = code.split(':')
        return when (p[0]) {
            "K" -> "Key " + AwtKey.getKeyText(p[1].toIntOrNull() ?: 0)
            "N" -> "MIDI pad / note ${p.getOrNull(2)} (ch ${p.getOrNull(1)})"
            "C" -> "MIDI knob / CC ${p.getOrNull(2)} (ch ${p.getOrNull(1)})"
            "P" -> "MIDI pitch fader (ch ${p.getOrNull(1)})"
            else -> code
        }
    }

    fun save() {
        try {
            saveFile.parentFile?.mkdirs()
            saveFile.writeText(bindings.entries.joinToString("\n") { it.key + "\t" + it.value })
        } catch (_: Throwable) {}
    }

    private fun isKey(code: String) = code.startsWith("K:")

    private fun bind(code: String, id: String) {
        // one computer key and one MIDI control per function; an input can only do one thing
        bindings.entries.filter { it.value == id && isKey(it.key) == isKey(code) }.map { it.key }.forEach { bindings.remove(it) }
        bindings[code] = id
        save()
    }

    fun unbindAction(id: String) { bindings.entries.filter { it.value == id }.map { it.key }.forEach { bindings.remove(it) }; save() }
    fun resetKeyboard() {
        val midi = bindings.entries.filter { !isKey(it.key) }.map { Pair(it.key, it.value) }
        bindings.clear(); bindings.putAll(defaultKeys()); midi.forEach { bindings[it.first] = it.second }
        save()
    }
    fun clearAll() { bindings.clear(); save() }

    /** Every key press and every MIDI message arrives here. Returns true when it was used. */
    fun dispatch(code: String, value: Float, continuous: Boolean): Boolean {
        lastInput = describe(code)
        val l = learning
        if (l != null) {
            val act = byId[l]
            if (act != null && act.knob && !continuous) return true          // a knob needs a MIDI knob or fader
            if (continuous || value > 0.5f) { bind(code, l); learning = null }
            return true
        }
        val id = bindings[code]
        if (id == null) { if (value <= 0.5f) down.remove(code); return false }
        val act = byId[id] ?: return false
        if (act.knob) { if (continuous) act.run(value.coerceIn(0f, 1f)); return true }
        if (value > 0.5f) { if (down.add(code)) act.run(1f) } else down.remove(code)     // buttons fire once per press
        return true
    }

    /** Computer keyboard (attached to the program's windows). */
    fun onKey(ev: androidx.compose.ui.input.key.KeyEvent): Boolean {
        val e = ev.nativeKeyEvent
        val code = "K:" + e.keyCode
        if (e.id == AwtKey.KEY_RELEASED) { down.remove(code); return false }
        if (e.id != AwtKey.KEY_PRESSED) return false
        if (typing) return false
        val kc = e.keyCode
        if (kc == AwtKey.VK_SHIFT || kc == AwtKey.VK_CONTROL || kc == AwtKey.VK_ALT || kc == AwtKey.VK_META || kc == AwtKey.VK_ALT_GRAPH) return false
        if (learning != null && kc == AwtKey.VK_ESCAPE) { learning = null; return true }
        return dispatch(code, 1f, false)
    }
}

/** Opens every connected MIDI input and feeds it to Controls. */
object MidiService {
    val devices = mutableStateListOf<String>()
    var enabled by mutableStateOf(true)
    private val opened = ArrayList<MidiDevice>()

    @Synchronized fun rescan() {
        for (d in opened) { try { d.close() } catch (_: Throwable) {} }
        opened.clear(); devices.clear()
        if (!enabled) return
        for (info in MidiSystem.getMidiDeviceInfo()) {
            try {
                val dev = MidiSystem.getMidiDevice(info)
                if (dev is Sequencer || dev is Synthesizer) continue
                if (dev.maxTransmitters == 0) continue
                dev.open()
                dev.transmitter.receiver = Rcv()
                opened.add(dev); devices.add(info.name)
            } catch (_: Throwable) {}
        }
    }

    private class Rcv : Receiver {
        override fun send(message: MidiMessage, timeStamp: Long) {
            if (message !is ShortMessage) return
            val ch = message.channel + 1
            when (message.command) {
                ShortMessage.NOTE_ON -> Controls.dispatch("N:$ch:${message.data1}", if (message.data2 > 0) 1f else 0f, false)
                ShortMessage.NOTE_OFF -> Controls.dispatch("N:$ch:${message.data1}", 0f, false)
                ShortMessage.CONTROL_CHANGE -> Controls.dispatch("C:$ch:${message.data1}", message.data2 / 127f, true)
                ShortMessage.PITCH_BEND -> Controls.dispatch("P:$ch", ((message.data2 shl 7) or message.data1) / 16383f, true)
                else -> {}
            }
        }
        override fun close() {}
    }
}
