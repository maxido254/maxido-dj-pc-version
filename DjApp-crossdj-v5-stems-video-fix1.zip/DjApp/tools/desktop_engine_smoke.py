# Offline test of the desktop engine (no sound card needed). Build first: cmake -S app/src/main/cpp -B bld && cmake --build bld ; run from the folder holding bld/ : python3 -I tools/desktop_engine_smoke.py
import ctypes, math, struct, wave, array, os, sys
lib = ctypes.CDLL("./bld/libdjengine.so")
for n,res,args in [("dj_decode_to_raw",ctypes.c_int,[ctypes.c_char_p,ctypes.c_char_p]),
  ("dj_load_deck",None,[ctypes.c_int,ctypes.c_char_p,ctypes.c_int]),("dj_set_playing",None,[ctypes.c_int,ctypes.c_int]),
  ("dj_offline_begin",None,[ctypes.c_int]),("dj_offline_render",None,[ctypes.POINTER(ctypes.c_float),ctypes.c_int]),
  ("dj_set_crossfader",None,[ctypes.c_float]),("dj_set_bass_amp",None,[ctypes.c_float]),("dj_get_duration",ctypes.c_double,[ctypes.c_int]),
  ("dj_get_position",ctypes.c_double,[ctypes.c_int]),("dj_set_eq",None,[ctypes.c_int,ctypes.c_int,ctypes.c_float]),("dj_set_tempo",None,[ctypes.c_int,ctypes.c_float])]:
    f=getattr(lib,n); f.restype=res; f.argtypes=args
sr=44100
w=wave.open("t.wav","wb"); w.setnchannels(2); w.setsampwidth(2); w.setframerate(sr)
a=array.array('h')
for i in range(sr*4):
    v=int(9000*math.sin(2*math.pi*50*i/sr)+3000*math.sin(2*math.pi*1000*i/sr)); a.append(v); a.append(v)
w.writeframes(a.tobytes()); w.close()
rate=lib.dj_decode_to_raw(b"t.wav",b"t.raw"); print("decoded rate",rate,"raw bytes",os.path.getsize("t.raw"))
lib.dj_offline_begin(48000)
def render(amt, eq=0.0):
    lib.dj_load_deck(0,b"t.raw",rate); lib.dj_set_crossfader(0.0); lib.dj_set_bass_amp(amt); lib.dj_set_eq(0,0,eq); lib.dj_set_playing(0,1)
    out=[]
    buf=(ctypes.c_float*(2*480))()
    for _ in range(300):
        lib.dj_offline_render(buf,480); out+=list(buf[0::2])
    return out
def amp(x,f,fs=48000,a=24000,b=None):
    b=b or len(x); c=s=0
    for i in range(a,b):
        t=2*math.pi*f*i/fs; c+=x[i]*math.cos(t); s+=x[i]*math.sin(t)
    return 2*math.hypot(c,s)/(b-a)
for amt in (0.0,1.0):
    o=render(amt); print(f"bass amp {amt}: duration {lib.dj_get_duration(0):.2f}s pos {lib.dj_get_position(0):.2f}s peak {max(abs(v) for v in o):.3f} | 50Hz {amp(o,50):.4f} 150Hz {amp(o,150):.4f} 1kHz {amp(o,1000):.4f}")
o=render(0.5,12.0); print("bass EQ +12 dB peak",round(max(abs(v) for v in o),3),"50Hz",round(amp(o,50),4))
# --- master tap
for n,res,args in [("dj_tap_start",None,[]),("dj_tap_stop",None,[]),("dj_tap_read",ctypes.c_int,[ctypes.POINTER(ctypes.c_float),ctypes.c_int]),("dj_get_sample_rate",ctypes.c_int,[])]:
    f=getattr(lib,n); f.restype=res; f.argtypes=args
lib.dj_load_deck(0,b"t.raw",rate); lib.dj_set_playing(0,1); lib.dj_tap_start()
buf=(ctypes.c_float*(2*480))(); rd=(ctypes.c_float*(2*4800))(); got=0; last=[]
for _ in range(50):
    lib.dj_offline_render(buf,480); k=lib.dj_tap_read(rd,4800); got+=k
print("tap: rendered 24000 frames, tap delivered",got,"frames, sr",lib.dj_get_sample_rate())
assert got==24000
# --- stems: 4 files (vocals 1 kHz, drums 3 kHz, bass 60 Hz, other 500 Hz); swap in while playing, mute vocals/bass
lib.dj_set_stems.argtypes=[ctypes.c_int,ctypes.POINTER(ctypes.c_char_p)]; lib.dj_set_stems.restype=None
lib.dj_set_stem_volume.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_float]; lib.dj_set_stem_volume.restype=None
names=[]
for nm,fr in zip(["vocals","drums","bass","other"],[1000,3000,60,500]):
    a=array.array('h',[int(6000*math.sin(2*math.pi*fr*(i//2)/sr)) for i in range(sr*4*2)]); open(nm+".pcm","wb").write(a.tobytes()); names.append((nm+".pcm").encode())
arr=(ctypes.c_char_p*4)(*names)
lib.dj_load_deck(0,b"t.raw",rate); lib.dj_set_playing(0,1)
buf=(ctypes.c_float*(2*480))()
for _ in range(20): lib.dj_offline_render(buf,480)
lib.dj_set_stems(0,arr)
def grab(n=100):
    o=[]
    for _ in range(n): lib.dj_offline_render(buf,480); o+=list(buf[0::2])
    return o
for _ in range(20): lib.dj_offline_render(buf,480)
o=grab(); print("all stems  : 1k %.3f 3k %.3f 60 %.4f 500 %.3f"%tuple(amp(o,f,a=2000) for f in (1000,3000,60,500)))
lib.dj_set_stem_volume(0,0,0.0); lib.dj_set_stem_volume(0,2,0.0)
for _ in range(30): lib.dj_offline_render(buf,480)
o=grab(); r=tuple(amp(o,f,a=2000) for f in (1000,3000,60,500)); print("no vocal/bass: 1k %.3f 3k %.3f 60 %.4f 500 %.3f"%r)
assert r[0]<0.01 and r[2]<0.01 and r[1]>0.05 and r[3]>0.05
print("stems OK")
