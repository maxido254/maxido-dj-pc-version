package com.example.djapp

import java.io.BufferedOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Removes leftover voice from the MELODY stem so that switching the VOCAL stem off really removes the voice.
 *
 * Any bin (time/frequency point) where the vocal stem has more energy than the melody stem is treated as voice
 * that leaked into the melody: that part of the melody is moved over to the vocal stem. The two stems still add up
 * exactly to what they added up to before, so the full mix is unchanged; only the split is cleaner.
 * Drums and bass are left alone (below ~100 Hz and above ~10 kHz nothing is moved either). Only used for the classic separators, never for AI stems.
 */
object VocalCleaner {
    private const val N = 4096
    private const val H = 1024

    private fun ss(a: Float, b: Float, x: Float): Float { val t = ((x - a) / (b - a)).coerceIn(0f, 1f); return t * t * (3 - 2 * t) }

    /** Works on vocals.pcm and other.pcm inside [dir] (interleaved stereo int16). Returns false only if cancelled. */
    fun clean(dir: File, rate: Int, cancelled: () -> Boolean): Boolean {
        val vf = File(dir, "vocals.pcm"); val of = File(dir, "other.pcm")
        if (!vf.exists() || !of.exists()) return true
        val total = minOf(vf.length(), of.length()) / 4
        if (total < N) return true

        val win = FloatArray(N) { Math.sin(Math.PI * (it + 0.5) / N).toFloat() }
        val cosT = FloatArray(N / 2) { Math.cos(2 * Math.PI * it / N).toFloat() }
        val sinT = FloatArray(N / 2) { Math.sin(2 * Math.PI * it / N).toFloat() }
        val rev = IntArray(N).also { t ->
            val bits = Integer.numberOfTrailingZeros(N)
            for (i in 0 until N) { var x = i; var r = 0; for (b in 0 until bits) { r = (r shl 1) or (x and 1); x = x shr 1 }; t[i] = r }
        }
        fun fft(re: FloatArray, im: FloatArray) {
            for (i in 0 until N) { val j = rev[i]; if (j > i) { var t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t } }
            var len = 2
            while (len <= N) {
                val half = len shr 1; val step = N / len
                var i = 0
                while (i < N) {
                    var k = 0
                    for (j in i until i + half) {
                        val wr = cosT[k]; val wi = -sinT[k]; k += step
                        val xr = re[j + half]; val xi = im[j + half]
                        val vr = xr * wr - xi * wi; val vi = xr * wi + xi * wr
                        re[j + half] = re[j] - vr; im[j + half] = im[j] - vi
                        re[j] += vr; im[j] += vi
                    }
                    i += len
                }
                len = len shl 1
            }
        }

        val fs = rate.toFloat()
        val band = FloatArray(N / 2 + 1) { k -> val f = k * fs / N; ss(100f, 220f, f) * (1f - ss(8000f, 11000f, f)) }
        val inv = 1f / (2f * N)                       // sine^2 windows at hop N/4 sum to 2; FFT scale N

        val vRaf = RandomAccessFile(vf, "r"); val oRaf = RandomAccessFile(of, "r")
        val vTmp = File(dir, "vocals.pcm.clean"); val oTmp = File(dir, "other.pcm.clean")
        val vOut = BufferedOutputStream(vTmp.outputStream(), 256 * 1024); val oOut = BufferedOutputStream(oTmp.outputStream(), 256 * 1024)

        val rb = ByteArray(N * 4)
        fun readStereo(raf: RandomAccessFile, start: Long, count: Int, l: FloatArray, r: FloatArray) {
            java.util.Arrays.fill(l, 0, count, 0f); java.util.Arrays.fill(r, 0, count, 0f)
            val from = maxOf(start, 0L); val to = minOf(start + count, total)
            if (to <= from) return
            val n = (to - from).toInt()
            raf.seek(from * 4); raf.readFully(rb, 0, n * 4)
            val sb = ByteBuffer.wrap(rb, 0, n * 4).order(ByteOrder.nativeOrder()).asShortBuffer()
            val off = (from - start).toInt()
            for (i in 0 until n) { l[off + i] = sb.get(2 * i).toFloat(); r[off + i] = sb.get(2 * i + 1).toFloat() }
        }

        val vl = FloatArray(N); val vr = FloatArray(N); val ol = FloatArray(N); val orr = FloatArray(N)
        val reV = FloatArray(N); val imV = FloatArray(N); val reO = FloatArray(N); val imO = FloatArray(N)
        val reM = FloatArray(N); val imM = FloatArray(N)
        val g = FloatArray(N / 2 + 1)
        val acc = Array(2) { FloatArray(N) }
        val vb = ByteArray(H * 4); val ob = ByteArray(H * 4)
        val vOutB = ByteArray(H * 4); val oOutB = ByteArray(H * 4)

        fun clip(x: Int) = if (x < -32768) -32768 else if (x > 32767) 32767 else x

        fun emit(f: Int) {
            val s0 = (f - 3).toLong() * H
            if (s0 in 0 until total) {
                val cnt = minOf(H.toLong(), total - s0).toInt()
                vRaf.seek(s0 * 4); vRaf.readFully(vb, 0, cnt * 4)
                oRaf.seek(s0 * 4); oRaf.readFully(ob, 0, cnt * 4)
                val vs = ByteBuffer.wrap(vb, 0, cnt * 4).order(ByteOrder.nativeOrder()).asShortBuffer()
                val os = ByteBuffer.wrap(ob, 0, cnt * 4).order(ByteOrder.nativeOrder()).asShortBuffer()
                val vo = ByteBuffer.wrap(vOutB, 0, cnt * 4).order(ByteOrder.nativeOrder()).asShortBuffer()
                val oo = ByteBuffer.wrap(oOutB, 0, cnt * 4).order(ByteOrder.nativeOrder()).asShortBuffer()
                for (i in 0 until cnt) for (ch in 0..1) {
                    val mv = Math.round(acc[ch][i])
                    val o = os.get(2 * i + ch).toInt(); val v = vs.get(2 * i + ch).toInt()
                    vo.put(2 * i + ch, clip(v + mv).toShort())
                    oo.put(2 * i + ch, clip(o - mv).toShort())
                }
                vOut.write(vOutB, 0, cnt * 4); oOut.write(oOutB, 0, cnt * 4)
            }
            for (ch in 0..1) { val a = acc[ch]; System.arraycopy(a, H, a, 0, N - H); java.util.Arrays.fill(a, N - H, N, 0f) }
        }

        var ok = false
        try {
            val frames = ((total + H - 1) / H).toInt() + 3
            for (f in 0..frames) {
                if (cancelled()) return false
                val start = (f - 3).toLong() * H
                readStereo(vRaf, start, N, vl, vr); readStereo(oRaf, start, N, ol, orr)
                for (n in 0 until N) {
                    reV[n] = vl[n] * win[n]; imV[n] = vr[n] * win[n]
                    reO[n] = ol[n] * win[n]; imO[n] = orr[n] * win[n]
                }
                fft(reV, imV); fft(reO, imO)
                for (k in 0..N / 2) {
                    val j = (N - k) and (N - 1)
                    val pv = (reV[k] * reV[k] + imV[k] * imV[k] + reV[j] * reV[j] + imV[j] * imV[j]) * 0.5f
                    val po = (reO[k] * reO[k] + imO[k] * imO[k] + reO[j] * reO[j] + imO[j] * imO[j]) * 0.5f
                    val m = pv / (pv + po + 1e-9f)
                    g[k] = ss(0.5f, 0.85f, m) * band[k]      // share of the melody that is really voice
                }
                for (n in 0 until N) {
                    val gm = g[if (n <= N / 2) n else N - n]
                    reM[n] = reO[n] * gm; imM[n] = imO[n] * gm
                }
                fft(imM, reM)                                  // inverse FFT (swap trick): reM = left * N, imM = right * N
                val aL = acc[0]; val aR = acc[1]
                for (n in 0 until N) { val w = win[n] * inv; aL[n] += reM[n] * w; aR[n] += imM[n] * w }
                emit(f)
            }
            ok = true
        } finally {
            try { vOut.close() } catch (_: Exception) {}; try { oOut.close() } catch (_: Exception) {}
            vRaf.close(); oRaf.close()
            if (!ok) { vTmp.delete(); oTmp.delete() }
        }
        // keep any tail beyond the shorter file untouched: both files are the same length in practice
        vf.delete(); of.delete()
        vTmp.renameTo(vf); oTmp.renameTo(of)
        return true
    }
}
