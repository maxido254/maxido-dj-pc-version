package com.example.djapp

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val COMPANY = "MAXIDO"
private const val SLOGAN = "BUILT BY A DJ FOR MUSIC LOVERS"

/**
 * Opening animation: a vinyl record spins in, a ring draws around it, MAXIDO appears letter by letter,
 * then the slogan fades in. It cannot be skipped (touches and Back are blocked) and fades out when it ends.
 */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val logo = remember { Animatable(0f) }
    val spin = remember { Animatable(0f) }
    val letters = remember { Animatable(0f) }
    val slogan = remember { Animatable(0f) }
    val fade = remember { Animatable(1f) }

    LaunchedEffect(Unit) {
        launch { spin.animateTo(1f, tween(4600, easing = LinearEasing)) }
        logo.animateTo(1f, tween(1000, easing = FastOutSlowInEasing))
        letters.animateTo(1f, tween(1200, easing = LinearEasing))
        slogan.animateTo(1f, tween(800))
        delay(1000)
        fade.animateTo(0f, tween(500))
        onDone()
    }
    BackHandler(true) { }   // no skipping

    Box(
        Modifier.fillMaxSize()
            .graphicsLayer { alpha = fade.value }
            .background(BgDark)
            .pointerInput(Unit) { awaitPointerEventScope { while (true) awaitPointerEvent().changes.forEach { it.consume() } } },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(Modifier.size(92.dp)) {
                val r = size.minDimension / 2f
                val c = Offset(size.width / 2f, size.height / 2f)
                scale(logo.value, c) {
                    rotate(spin.value * 900f, c) {
                        drawCircle(Color(0xFF0E1522), r * 0.9f, c)
                        for (g in 1..4) drawCircle(Color(0x22FFFFFF), r * (0.42f + g * 0.1f), c, style = Stroke(1.2f))
                        drawCircle(Brush.sweepGradient(listOf(DeckA, DeckB, DeckA), c), r * 0.36f, c)
                        drawCircle(BgDark, r * 0.06f, c)
                        drawArc(
                            Color(0x33FFFFFF), -35f, 30f, true,
                            Offset(c.x - r * 0.9f, c.y - r * 0.9f), Size(r * 1.8f, r * 1.8f)
                        )
                    }
                }
                val sw = 4.dp.toPx()
                drawArc(
                    DeckALight, -90f, 360f * logo.value, false,
                    Offset(sw / 2f, sw / 2f), Size(size.width - sw, size.height - sw),
                    style = Stroke(sw, cap = StrokeCap.Round)
                )
            }
            Spacer(Modifier.height(10.dp))
            Row {
                COMPANY.forEachIndexed { i, ch ->
                    val a = (letters.value * COMPANY.length - i).coerceIn(0f, 1f)
                    Text(
                        ch.toString(), color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp,
                        modifier = Modifier.graphicsLayer {
                            alpha = a; translationY = (1f - a) * 28f; scaleX = 0.6f + 0.4f * a; scaleY = 0.6f + 0.4f * a
                        }
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                SLOGAN, color = DeckALight, fontSize = 11.sp, letterSpacing = 3.sp,
                modifier = Modifier.graphicsLayer { alpha = slogan.value; translationY = (1f - slogan.value) * 10f }
            )
        }
    }
}
