package com.example.djapp

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * 480p video output for budget phones (Itel A80 and similar).
 *
 * A phone decoder always decodes a video at the size it was filmed in, and a 1080p picture is what makes a weak phone stutter.
 * So a bigger video is converted ONCE into a picture-only 480p copy (short side 480: 854x480, or 480x854 for portrait),
 * kept in the app cache, and that copy is what the video mixer plays. The deck's sound is untouched (it is decoded from the
 * original file by the audio engine) and the copy has the same length, so the picture stays locked to the deck.
 * The original keeps playing while the copy is made; the picture switches to the copy by itself when it is ready.
 */
@androidx.annotation.OptIn(markerClass = [UnstableApi::class])
object VideoProxy {
    const val SHORT_SIDE = 480
    private const val CACHE_LIMIT = 600L * 1024 * 1024

    private val io = Executors.newSingleThreadExecutor()       // one conversion at a time, so the phone is never overloaded
    private val main = Handler(Looper.getMainLooper())

    class Job {
        internal val cancelled = AtomicBoolean(false)
        internal val latch = CountDownLatch(1)
        @Volatile internal var transformer: Transformer? = null
        fun cancel() {
            if (!cancelled.compareAndSet(false, true)) return
            main.post { try { transformer?.cancel() } catch (_: Exception) {} }
            latch.countDown()
        }
    }

    private fun dir(ctx: Context) = File(ctx.cacheDir, "video480").also { it.mkdirs() }

    private fun keyOf(ctx: Context, uri: Uri): String {
        var size = 0L
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { if (it.moveToFirst()) size = it.getLong(0) }
        } catch (_: Exception) {}
        return Integer.toHexString(uri.toString().hashCode()) + "_" + size
    }

    /** The 480p copy of this video if it was already made (also in an earlier session), else null. */
    fun cached(ctx: Context, uri: Uri): Uri? {
        val f = File(dir(ctx), keyOf(ctx, uri) + ".mp4")
        if (!f.exists() || f.length() <= 0) return null
        f.setLastModified(System.currentTimeMillis())
        return Uri.fromFile(f)
    }

    /** Width and height of the picture as it is shown (rotation applied), or null if it cannot be read. */
    private fun probe(ctx: Context, uri: Uri): Pair<Int, Int>? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: return null
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: return null
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            if (w > 0 && h > 0) w to h else null
        } catch (_: Exception) { null } finally { try { r.release() } catch (_: Exception) {} }
    }

    private fun trim(ctx: Context) {
        try {
            val files = dir(ctx).listFiles()?.filter { it.isFile } ?: return
            var total = files.sumOf { it.length() }
            for (f in files.sortedBy { it.lastModified() }) {
                if (total <= CACHE_LIMIT) break
                total -= f.length(); f.delete()
            }
        } catch (_: Exception) {}
    }

    /**
     * Makes the 480p copy in the background. Callbacks run on the main thread.
     * onDone gets the copy, or null when none is needed (already 480p or smaller) or it could not be made (the original keeps playing).
     */
    fun request(ctx: Context, uri: Uri, onProgress: (Int) -> Unit, onDone: (Uri?) -> Unit): Job {
        val app = ctx.applicationContext
        val job = Job()
        io.execute {
            if (job.cancelled.get()) return@execute
            fun finish(u: Uri?) { main.post { if (!job.cancelled.get()) onDone(u) } }
            val out = File(dir(app), keyOf(app, uri) + ".mp4")
            if (out.exists() && out.length() > 0) { finish(Uri.fromFile(out)); return@execute }
            val dims = probe(app, uri)
            if (dims == null || min(dims.first, dims.second) <= SHORT_SIDE) { finish(null); return@execute }
            val scale = SHORT_SIDE.toFloat() / min(dims.first, dims.second)
            val tw = ((dims.first * scale).roundToInt() / 2) * 2
            val th = ((dims.second * scale).roundToInt() / 2) * 2
            trim(app)
            val part = File(out.path + ".part")
            part.delete()
            val ok = AtomicBoolean(false)
            main.post {
                if (job.cancelled.get()) { job.latch.countDown(); return@post }
                try {
                    val item = EditedMediaItem.Builder(MediaItem.fromUri(uri))
                        .setRemoveAudio(true)                              // the picture is silent, the audio engine owns the sound
                        .setEffects(Effects(emptyList(), listOf(Presentation.createForWidthAndHeight(tw, th, Presentation.LAYOUT_SCALE_TO_FIT))))
                        .build()
                    val t = Transformer.Builder(app)
                        .setVideoMimeType(MimeTypes.VIDEO_H264)
                        .addListener(object : Transformer.Listener {
                            override fun onCompleted(composition: Composition, exportResult: ExportResult) { ok.set(true); job.latch.countDown() }
                            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) { job.latch.countDown() }
                        })
                        .build()
                    job.transformer = t
                    t.start(item, part.absolutePath)
                    val holder = ProgressHolder()
                    val poll = object : Runnable {
                        override fun run() {
                            if (job.latch.count == 0L || job.cancelled.get()) return
                            try { if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) onProgress(holder.progress) } catch (_: Exception) {}
                            main.postDelayed(this, 500)
                        }
                    }
                    main.postDelayed(poll, 500)
                } catch (_: Exception) { job.latch.countDown() }
            }
            try { job.latch.await(30, TimeUnit.MINUTES) } catch (_: InterruptedException) {}
            if (ok.get() && !job.cancelled.get() && part.length() > 0 && part.renameTo(out)) finish(Uri.fromFile(out))
            else { part.delete(); finish(null) }
        }
        return job
    }
}
