package com.example.djapp

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val PAD8 = listOf(
    Color(0xFFFF5C7A), Color(0xFFFFB74D), Color(0xFFFFEE58), Color(0xFF9CCC65),
    Color(0xFF4DD0E1), Color(0xFF64B5F6), Color(0xFFBA68C8), Color(0xFFF06292)
)
private val MODE_LABELS = listOf("ONE-SHOT", "HOLD", "LOOP")

/** Sampler: always shows the 8 pads of the current bank; plays the built-in free samples. */
@Composable
fun SamplerPanel() {
    LaunchedEffect(Unit) { while (true) { Sampler.poll(); delay(80) } }
    Performance()
}

// ------------------------------------------------------------------ pads + controls
@Composable
private fun Performance() {
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(Modifier.weight(3f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            for (row in 0..1) Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (col in 0..3) PadView(row * 4 + col, Modifier.weight(1f).fillMaxHeight())
            }
        }
        Column(Modifier.weight(1.35f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                for (b in 0 until Sampler.BANKS)
                    PadButton("${b + 1}", Modifier.weight(1f).height(26.dp), active = Sampler.bank == b, color = DeckALight, fontSize = 11) { Sampler.bank = b }
            }
            PadButton(MODE_LABELS[AppSettings.padMode], Modifier.fillMaxWidth().height(26.dp), fontSize = 10) {
                AppSettings.padMode = (AppSettings.padMode + 1) % 3; AppSettings.save()
            }
            FxSlider("VOL", AppSettings.sampleVol, 0f..1f, Accent, "${(AppSettings.sampleVol * 100).toInt()}") {
                AppSettings.sampleVol = it; NativeEngine.setSampleVolume(it); AppSettings.save()
            }
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                PadButton("STOP", Modifier.weight(1f).height(26.dp), fontSize = 10) { Sampler.stopAll() }
            }
        }
    }
}

@Composable
private fun PadView(i: Int, modifier: Modifier) {
    val slot = Sampler.bank * Sampler.PER_BANK + i
    val pad = Sampler.pads[slot]
    val col = PAD8[i]
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier.clip(shape)
            .background(if (pad.playing) col else if (pad.loaded) col.copy(alpha = 0.38f) else Color(0xFF111B2E))
            .padTouch(slot),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${i + 1}", color = if (pad.playing) Color.Black else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(
                if (pad.loaded || pad.name.isNotEmpty()) pad.name else "empty",
                color = if (pad.playing) Color.Black else TextGray, fontSize = 8.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 3.dp)
            )
        }
    }
}

/** Triggers on touch-down (no tap delay). */
private fun Modifier.padTouch(slot: Int): Modifier = pointerInput(slot) {
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false)
        Sampler.down(slot)
        waitForUpOrCancellation()
        Sampler.up(slot)
    }
}
