package com.example.djapp

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Settings > STORE: download skins and sampler packs, switch between the ones you have, remove the ones you do not want. */
@Composable
fun StorePage() {
    LaunchedEffect(Unit) { if (Store.items.isEmpty()) Store.refresh() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // ---- what is on the phone right now
        Text("IN USE", color = TextGray, fontSize = 10.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Skin: " + (Skin.installed().firstOrNull { it.first == Skin.activeId }?.second ?: "Original"), color = Color.White, fontSize = 11.sp, modifier = Modifier.weight(1f), maxLines = 1)
            if (Skin.activeId != Skin.PRO_ID) PadButton("MAXIDO PRO", Modifier.width(110.dp), fontSize = 10) { Skin.apply(Skin.PRO_ID) }
            if (Skin.activeId.isNotEmpty()) PadButton("ORIGINAL", Modifier.width(90.dp), fontSize = 10) { Skin.apply("") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Samples: " + (Store.installedPacks().firstOrNull { it.first == Sampler.activePack }?.second ?: "Built-in"), color = Color.White, fontSize = 11.sp, modifier = Modifier.weight(1f), maxLines = 1)
            if (Sampler.activePack.isNotEmpty()) PadButton("BUILT-IN", Modifier.width(110.dp), fontSize = 10) { Sampler.useBuiltIn() }
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("ONLINE STORE", color = TextGray, fontSize = 10.sp, modifier = Modifier.weight(1f))
            PadButton(if (Store.loading) "LOADING..." else "REFRESH", Modifier.width(100.dp), enabled = !Store.loading, fontSize = 10) { Store.refresh() }
        }
        if (Store.status.isNotEmpty()) Text(Store.status, color = Color(0xFFFFB74D), fontSize = 10.sp)

        for (entry in Store.items) StoreRow(entry)

        Text(
            "Downloads need internet. Only the store catalog address is contacted, every file is checked against its checksum, and nothing is installed unless it matches.",
            color = TextGray, fontSize = 9.sp
        )
    }
}

@Composable
private fun StoreRow(item: Store.Item) {
    val busy = Store.busy[item.id]
    val have = Store.installedVersion(item)
    val installed = have > 0
    val update = installed && have < item.version
    val active = if (item.isSkin) Skin.activeId == item.id else Sampler.activePack == item.id

    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(PanelBg).padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (item.isSkin) "SKIN" else "PACK", color = Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(if (item.isSkin) DeckBLight else DeckALight).padding(horizontal = 4.dp, vertical = 1.dp))
                Text(item.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            val meta = listOfNotNull(item.author.takeIf { it.isNotEmpty() }, if (item.size > 0) sizeText(item.size) else null).joinToString("  -  ")
            if (meta.isNotEmpty()) Text(meta, color = TextGray, fontSize = 9.sp, maxLines = 1)
            if (item.desc.isNotEmpty()) Text(item.desc, color = TextGray, fontSize = 9.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        when {
            busy != null -> Text(busy.uppercase(), color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(84.dp))
            !installed || update -> PadButton(if (update) "UPDATE" else "DOWNLOAD", Modifier.width(84.dp), fontSize = 10) { Store.download(item) }
            else -> Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                PadButton(if (active) "IN USE" else "USE", Modifier.width(62.dp), active = active, fontSize = 10) {
                    if (item.isSkin) Skin.apply(item.id) else Sampler.usePack(item.id)
                }
                PadButton("X", Modifier.width(34.dp), fontSize = 10) { Store.remove(item) }
            }
        }
    }
}

private fun sizeText(b: Long) = if (b >= 1_000_000) "%.1f MB".format(b / 1_000_000.0) else "%d KB".format(maxOf(1L, b / 1000))
