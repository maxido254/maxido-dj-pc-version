package com.example.djapp

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.zip.ZipInputStream

/**
 * Online store for skins and sampler packs. The app only ever talks to ONE address: the catalog (a JSON file you host).
 * The catalog lists the downloads. Every download must be https and must match the SHA-256 listed in the catalog.
 *
 *   { "version": 1, "items": [
 *     { "id": "neon-red", "type": "skin", "name": "Neon Red", "author": "Maxido", "desc": "...", "version": 1,
 *       "url": "https://.../neon-red.json", "sha256": "<hex>", "size": 412 },
 *     { "id": "afro-hits", "type": "pack", "name": "Afro Hits", ... "url": "https://.../afro-hits.zip", "sha256": "<hex>", "size": 5230000 } ] }
 */
object Store {
    /** CHANGE THIS to the address where you host catalog.json (see server/README.md). */
    const val CATALOG_URL = "https://YOUR-NAME.github.io/maxido-store/catalog.json"

    private const val MAX_CATALOG = 1_000_000L
    private const val MAX_SKIN = 256_000L
    private const val MAX_PACK = 60_000_000L
    private const val MAX_UNZIPPED = 120_000_000L
    private val ID_OK = Regex("^[a-z0-9][a-z0-9_-]{0,39}$")
    private val AUDIO_EXT = setOf("mp3", "ogg", "wav", "m4a", "aac", "flac")

    class Item(
        val id: String, val type: String, val name: String, val author: String, val desc: String,
        val version: Int, val url: String, val sha256: String, val size: Long
    ) {
        val isSkin get() = type == "skin"
    }

    /** Set by MainActivity: the store is only checked while the app is on screen. */
    @Volatile var foreground = true
    /** Set while Settings > STORE is open: the catalog is then checked every 10 seconds instead of every 45. */
    @Volatile var watchFast = false
    /** Number shown next to STORE in Settings: new items you have not looked at + installed packs that have an update. */
    var badge by mutableIntStateOf(0)
    private var seen = HashSet<String>()
    private var watching = false
    @Volatile private var fetching = false

    val items = mutableStateListOf<Item>()
    val busy = mutableStateMapOf<String, String>()      // item id -> "42%" / "installing"
    var status by mutableStateOf("")
    var loading by mutableStateOf(false)

    private lateinit var app: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val prefs get() = app.getSharedPreferences("djstore", Context.MODE_PRIVATE)
    val packsDir: File get() = File(app.filesDir, "packs").apply { mkdirs() }

    fun init(ctx: Context) {
        app = ctx.applicationContext
        seen = HashSet(prefs.getStringSet("seen", emptySet()) ?: emptySet())
        startWatching()
    }

    /** Looks for new uploads on its own: every 45 s while the app is open (10 s while the Store page is open). */
    private fun startWatching() {
        if (watching) return
        watching = true
        scope.launch {
            var tick = 0
            while (true) {
                kotlinx.coroutines.delay(1000); tick++
                if (foreground && tick >= (if (watchFast) 10 else 45)) { tick = 0; refresh(true) }
            }
        }
    }

    fun isNew(item: Item) = !isInstalled(item) && item.id !in seen
    fun markSeen() { seen.addAll(items.map { it.id }); prefs.edit().putStringSet("seen", HashSet(seen)).apply(); recount() }
    private fun recount() {
        badge = items.count { (!isInstalled(it) && it.id !in seen) || (!it.isSkin && isInstalled(it) && installedVersion(it) < it.version) }
    }

    /** After every catalog load: remember what existed on the first run, update installed skins by themselves (they are tiny). */
    private fun afterCatalog() {
        if (!prefs.contains("seen")) markSeen()
        for (item in items.toList()) {
            val have = installedVersion(item)
            if (item.isSkin && have in 1 until item.version && !busy.containsKey(item.id)) download(item)
        }
        recount()
    }

    // ------------------------------------------------------------------ catalog
    fun refresh(silent: Boolean = false) {
        if (fetching) return
        if (CATALOG_URL.contains("YOUR-NAME")) { if (!silent) status = "Store address not set yet. See server/README.md."; return }
        fetching = true
        if (!silent) { loading = true; status = "Loading..." }
        scope.launch {
            try {
                // ?t= changes every 10 s so GitHub's 5-minute cache can never hold back a new upload
                val sep = if (CATALOG_URL.contains("?")) "&" else "?"
                val text = String(fetch(CATALOG_URL + sep + "t=" + System.currentTimeMillis() / 10000, MAX_CATALOG) { }, Charsets.UTF_8)
                val arr = JSONObject(text).getJSONArray("items")
                val list = ArrayList<Item>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.getString("id"); val type = o.getString("type")
                    val url = try { URL(URL(CATALOG_URL), o.getString("url")).toString() } catch (_: Exception) { continue }   // relative addresses work too
                    if (!ID_OK.matches(id) || (type != "skin" && type != "pack") || !url.startsWith("https://")) continue
                    list += Item(
                        id, type, o.optString("name", id), o.optString("author", ""), o.optString("desc", ""),
                        o.optInt("version", 1), url, o.getString("sha256").lowercase(), o.optLong("size", 0L)
                    )
                }
                post { items.clear(); items.addAll(list); if (!silent) status = if (list.isEmpty()) "The store is empty." else ""; afterCatalog() }
            } catch (e: Exception) {
                if (!silent) post {
                    status = if (e.message?.contains("404") == true) "The store is not published yet (is the repo public?)." else "Could not load the store: ${e.message ?: "no internet?"}"
                }
            } finally { fetching = false; post { loading = false } }
        }
    }

    // ------------------------------------------------------------------ installed state
    fun installedVersion(item: Item): Int =
        if (isInstalled(item)) prefs.getInt("inst_${item.type}_${item.id}", 1) else 0

    fun isInstalled(item: Item): Boolean =
        if (item.isSkin) File(Skin.dir, "${item.id}.json").exists() else File(packsDir, item.id).isDirectory

    /** Installed packs as id to display name. */
    fun installedPacks(): List<Pair<String, String>> =
        (packsDir.listFiles { f -> f.isDirectory && !f.name.endsWith(".tmp") } ?: emptyArray()).map { d ->
            val name = try { JSONObject(File(d, "pack.json").readText()).optString("name", d.name) } catch (_: Exception) { d.name }
            d.name to name
        }.sortedBy { it.second.lowercase() }

    fun remove(item: Item) {
        if (item.isSkin) Skin.delete(item.id) else { if (Sampler.activePack == item.id) Sampler.useBuiltIn(); File(packsDir, item.id).deleteRecursively() }
        prefs.edit().remove("inst_${item.type}_${item.id}").apply()
        recount()
    }

    // ------------------------------------------------------------------ download + install
    fun download(item: Item) {
        if (busy.containsKey(item.id)) return
        busy[item.id] = "0%"
        scope.launch {
            val tmp = File(app.cacheDir, "dl_${item.id}.part")
            try {
                val limit = if (item.isSkin) MAX_SKIN else MAX_PACK
                val bytes = fetch(item.url, limit) { pct -> post { busy[item.id] = "$pct%" } }
                val sum = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
                check(sum == item.sha256) { "file does not match the catalog checksum" }
                post { busy[item.id] = "installing" }
                if (item.isSkin) installSkin(item, bytes) else installPack(item, bytes)
                prefs.edit().putInt("inst_${item.type}_${item.id}", item.version).apply()
                post { status = "${item.name} installed"; recount() }
            } catch (e: Exception) {
                post { status = "${item.name}: ${e.message ?: "download failed"}" }
            } finally { tmp.delete(); post { busy.remove(item.id) } }
        }
    }

    private fun installSkin(item: Item, bytes: ByteArray) {
        Skin.parse(JSONObject(String(bytes, Charsets.UTF_8)))         // throws if it is not a valid skin
        val dest = File(Skin.dir, "${item.id}.json")
        val wasActive = Skin.activeId == item.id
        dest.writeBytes(bytes)
        if (wasActive) post { Skin.apply(item.id) }
    }

    private fun installPack(item: Item, bytes: ByteArray) {
        val work = File(packsDir, item.id + ".tmp").apply { deleteRecursively(); mkdirs() }
        var total = 0L; var audio = 0
        try {
            ZipInputStream(bytes.inputStream()).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    if (e.isDirectory) continue
                    val name = e.name.substringAfterLast('/')
                    val ext = name.substringAfterLast('.', "").lowercase()
                    val ok = name == "pack.json" || ext in AUDIO_EXT
                    if (!ok || name.startsWith(".")) continue                      // ignore anything that is not audio / pack.json
                    if (name == "pack.json" || ++audio <= Sampler.BANKS * Sampler.PER_BANK) {
                        val out = File(work, name)
                        check(out.canonicalPath.startsWith(work.canonicalPath + File.separator)) { "unsafe file name in pack" }
                        out.outputStream().use { o ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val n = zin.read(buf); if (n < 0) break
                                total += n; check(total <= MAX_UNZIPPED) { "pack is too big" }
                                o.write(buf, 0, n)
                            }
                        }
                    }
                }
            }
            check(audio > 0) { "pack has no audio files" }
            val dest = File(packsDir, item.id)
            val wasActive = Sampler.activePack == item.id
            dest.deleteRecursively()
            check(work.renameTo(dest)) { "could not install pack" }
            if (wasActive) post { Sampler.usePack(item.id) }
        } catch (e: Exception) { work.deleteRecursively(); throw e }
    }

    // ------------------------------------------------------------------ network
    /** Downloads [url] into memory (https only, never more than [limit] bytes). */
    private fun fetch(url: String, limit: Long, progress: (Int) -> Unit): ByteArray {
        require(url.startsWith("https://")) { "only https downloads are allowed" }
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000; c.readTimeout = 30_000; c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "MAXXIDO-DJ")
        try {
            check(c.responseCode == 200) { "server answered ${c.responseCode}" }
            val len = c.contentLengthLong
            check(len <= limit) { "file is too big" }
            val out = java.io.ByteArrayOutputStream()
            val buf = ByteArray(32 * 1024); var got = 0L; var last = -1
            c.inputStream.use { i ->
                while (true) {
                    val n = i.read(buf); if (n < 0) break
                    got += n; check(got <= limit) { "file is too big" }
                    out.write(buf, 0, n)
                    if (len > 0) { val p = (got * 100 / len).toInt(); if (p != last) { last = p; progress(p) } }
                }
            }
            return out.toByteArray()
        } finally { c.disconnect() }
    }

    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private fun post(r: () -> Unit) { main.post(r) }
}
