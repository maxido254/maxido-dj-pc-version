package com.example.djapp

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream

/**
 * Own skins and samples, no store and no internet needed. Drop files on the phone (with a file manager / USB):
 *   Android/data/<this app>/files/skins/    *.json  (skin files, same format as store skins)
 *   Android/data/<this app>/files/samples/  a folder per pack (audio files + optional pack.json), or a .zip of it
 *   Android/obb/<this app>/skins/ and /samples/  work the same way
 * They are picked up when the app opens / resumes, and when RESCAN is pressed in Settings > STORE.
 */
object MyFiles {
    private val AUDIO = setOf("mp3", "ogg", "wav", "m4a", "aac", "flac")
    var message by mutableStateOf("")
    var tick by mutableStateOf(0)             // bumps after every scan so lists redraw
    private lateinit var app: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val prefs get() = app.getSharedPreferences("djmyfiles", Context.MODE_PRIVATE)

    fun init(ctx: Context) { app = ctx.applicationContext; scan() }

    private fun roots(): List<File> = listOfNotNull(app.getExternalFilesDir(null), app.obbDir)
    val skinFolder: String get() = (app.getExternalFilesDir(null)?.absolutePath ?: "") + "/skins"
    val sampleFolder: String get() = (app.getExternalFilesDir(null)?.absolutePath ?: "") + "/samples"

    private fun slug(s: String) = s.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(30).ifEmpty { "x" }

    fun scan() {
        if (!::app.isInitialized) return
        scope.launch {
            var added = 0; val errs = ArrayList<String>()
            for (r in roots()) {
                File(r, "skins").mkdirs(); File(r, "samples").mkdirs()
                (File(r, "skins").listFiles { f -> f.isFile && f.extension.lowercase() == "json" } ?: emptyArray()).forEach { f ->
                    val key = "s:${f.absolutePath}"; val stamp = f.lastModified() + f.length()
                    if (prefs.getLong(key, -1) == stamp) return@forEach
                    try {
                        if (f.length() > 600_000) error("too big")
                        val txt = f.readText(); Skin.parse(JSONObject(txt))
                        val id = "my-" + slug(f.nameWithoutExtension)
                        val wasActive = Skin.activeId == id
                        File(Skin.dir, "$id.json").writeText(txt)
                        prefs.edit().putLong(key, stamp).apply(); added++
                        if (wasActive) android.os.Handler(android.os.Looper.getMainLooper()).post { Skin.apply(id) }
                    } catch (e: Exception) { prefs.edit().putLong(key, stamp).apply(); errs += "${f.name}: ${e.message}" }
                }
                val sdir = File(r, "samples")
                (sdir.listFiles() ?: emptyArray()).forEach { f ->
                    val isZip = f.isFile && f.extension.lowercase() == "zip"
                    if (!f.isDirectory && !isZip) return@forEach
                    val key = "p:${f.absolutePath}"
                    val stamp = if (f.isDirectory) (f.listFiles()?.sumOf { it.lastModified() + it.length() } ?: 0L) else f.lastModified() + f.length()
                    if (prefs.getLong(key, -1) == stamp) return@forEach
                    try {
                        val id = "my-" + slug(f.nameWithoutExtension)
                        val tmp = File(Store.packsDir, "$id.tmp").apply { deleteRecursively(); mkdirs() }
                        var n = 0; val max = Sampler.BANKS * Sampler.PER_BANK
                        if (isZip) ZipInputStream(f.inputStream().buffered()).use { z ->
                            while (true) {
                                val e = z.nextEntry ?: break
                                val name = e.name.substringAfterLast('/')
                                if (e.isDirectory || name.startsWith(".")) continue
                                val ok = name == "pack.json" || name.substringAfterLast('.', "").lowercase() in AUDIO
                                if (!ok || (name != "pack.json" && ++n > max)) continue
                                File(tmp, name).outputStream().use { o -> z.copyTo(o) }
                            }
                        } else f.listFiles()!!.sortedBy { it.name }.forEach { a ->
                            val ok = a.name == "pack.json" || a.extension.lowercase() in AUDIO
                            if (ok && a.isFile && (a.name == "pack.json" || ++n <= max)) a.copyTo(File(tmp, a.name), true)
                        }
                        check(n > 0) { "no audio files" }
                        val dest = File(Store.packsDir, id); val wasActive = Sampler.activePack == id
                        dest.deleteRecursively(); check(tmp.renameTo(dest)) { "could not install" }
                        prefs.edit().putLong(key, stamp).apply(); added++
                        if (wasActive) android.os.Handler(android.os.Looper.getMainLooper()).post { Sampler.usePack(id) }
                    } catch (e: Exception) { prefs.edit().putLong(key, stamp).apply(); errs += "${f.name}: ${e.message}" }
                }
            }
            val msg = (if (added > 0) "$added of your own item(s) added. " else "") + errs.joinToString("; ")
            android.os.Handler(android.os.Looper.getMainLooper()).post { if (msg.isNotEmpty()) message = msg; tick++ }
        }
    }

    fun mySkins() = Skin.installed().filter { it.first.startsWith("my-") }
    fun myPacks() = Store.installedPacks().filter { it.first.startsWith("my-") }
}
