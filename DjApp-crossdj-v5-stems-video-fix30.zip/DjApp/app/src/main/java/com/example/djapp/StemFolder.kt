package com.example.djapp

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import java.io.File

/**
 * The MAXIDO STEMS folder: prepared stems live in a normal folder on the phone (not inside the app), so they survive
 * updates, reinstalls and a changed app name. Any version of the app that finds the folder sees the same prepared songs,
 * so nothing has to be exported or imported. Needs "All files access" (asked once). Without it the app keeps working
 * and stores stems inside its own private storage, then moves them to the folder as soon as access is given.
 */
object StemFolder {
    const val NAME = "MAXIDO STEMS"
    var granted by mutableStateOf(false)
    var asking by mutableStateOf(false)
    var picking by mutableStateOf(false)         // the in-app folder browser is open
    var pendingPick by mutableStateOf(false)     // open the browser as soon as access has been given

    /** The folder chosen in the in-app browser. */
    fun useFolder(ctx: Context, f: File) = setCustom(ctx, bestRoot(f))

    /** A folder the user chose themselves (null = the default MAXIDO STEMS folder). */
    var customPath by mutableStateOf<String?>(null)
    private var customLoaded = false

    fun defaultDir(): File = File(Environment.getExternalStorageDirectory(), NAME)
    fun dir(): File = customPath?.let { File(it) } ?: defaultDir()

    private fun loadCustom(ctx: Context) {
        if (customLoaded) return
        customLoaded = true
        customPath = ctx.getSharedPreferences("maxxidodj", Context.MODE_PRIVATE).getString("stemFolder", null)
    }

    /** Turns a folder picked with the system picker into a normal path (works for the phone and for an SD card). */
    private fun treeToFile(uri: Uri): File? = try {
        val id = android.provider.DocumentsContract.getTreeDocumentId(uri)          // "primary:Music/Stems" or "1A2B-3C4D:Stems"
        val vol = id.substringBefore(':'); val rel = id.substringAfter(':', "")
        val base = if (vol.equals("primary", true)) Environment.getExternalStorageDirectory() else File("/storage/$vol")
        if (rel.isEmpty()) base else File(base, rel)
    } catch (_: Exception) { null }

    /** The user picked their own folder for the stems. Prepared songs already in the old folder are moved there. */
    fun chooseFromTree(ctx: Context, uri: Uri) {
        val picked = treeToFile(uri)
        val f = picked?.let { bestRoot(it) }
        if (f == null) { Toast.makeText(ctx.applicationContext, "That folder can't be used. Pick one on the phone or the SD card.", Toast.LENGTH_LONG).show(); return }
        setCustom(ctx, f)
    }

    fun useDefault(ctx: Context) = setCustom(ctx, null)

    private fun isPack(d: File) = d.isDirectory && File(d, "meta.json").exists()

    /** If the picked folder has no prepared songs itself but a folder inside it does (e.g. it holds MAXIDO STEMS), use that one. */
    private fun bestRoot(f: File): File {
        if (f.listFiles()?.any { isPack(it) } == true) return f
        val inner = f.listFiles()?.filter { it.isDirectory }?.firstOrNull { sub -> sub.listFiles()?.any { isPack(it) } == true }
        return inner ?: f
    }

    /** .mxs files lying in the folder (exported or copied from another phone) are turned into prepared songs automatically. */
    fun importLooseFiles(ctx: Context) {
        val app = ctx.applicationContext
        Thread({
            try {
                val prefs = app.getSharedPreferences("maxxidodj", Context.MODE_PRIVATE)
                val done = prefs.getStringSet("mxsImported", emptySet())!!.toMutableSet()
                var added = 0
                val files = (dir().listFiles()?.toList() ?: emptyList()).flatMap { if (it.isDirectory && !isPack(it)) (it.listFiles()?.toList() ?: emptyList()) else listOf(it) }
                for (f in files) {
                    if (!f.isFile || !f.name.endsWith(".mxs", true)) continue
                    val sig = f.name + "|" + f.length() + "|" + f.lastModified()
                    if (sig in done) continue
                    val ok = try { f.inputStream().use { Prepared.importPack(app, it) } } catch (_: Exception) { false }
                    if (ok) { done.add(sig); added++ }
                }
                if (added > 0) {
                    prefs.edit().putStringSet("mxsImported", done).apply()
                    android.os.Handler(android.os.Looper.getMainLooper()).post { Toast.makeText(app, "Found $added prepared song(s) in the folder", Toast.LENGTH_LONG).show() }
                }
            } catch (_: Exception) { }
        }, "stem-folder-scan").start()
    }

    private fun setCustom(ctx: Context, f: File?) {
        loadCustom(ctx)
        val old = if (granted) dir() else null
        customPath = f?.absolutePath
        ctx.getSharedPreferences("maxxidodj", Context.MODE_PRIVATE).edit().apply { if (f == null) remove("stemFolder") else putString("stemFolder", f.absolutePath) }.apply()
        if (!granted) { asking = true; return }          // access first, then the folder is used
        val app = ctx.applicationContext
        Thread({
            try {
                val nd = dir(); nd.mkdirs(); File(nd, ".nomedia").createNewFile()
                if (old != null && old.absolutePath != nd.absolutePath) old.listFiles()?.forEach { p ->
                    val target = File(nd, p.name)
                    if (p.isDirectory && !p.name.endsWith(".tmp") && !target.exists() && File(p, "meta.json").exists()) {
                        try { p.copyRecursively(target, overwrite = true); p.deleteRecursively() } catch (_: Exception) { target.deleteRecursively() }
                    }
                }
                if (!nd.canWrite()) android.os.Handler(android.os.Looper.getMainLooper()).post { Toast.makeText(app, "MAXXIDO DJ can't write to that folder. Pick another one.", Toast.LENGTH_LONG).show() }
            } catch (_: Exception) { }
            Prepared.rescan(app)
        }, "stem-folder-move").start()
    }

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    /** Call on start and every time the app comes back to the front. */
    fun refresh(ctx: Context) {
        loadCustom(ctx)
        val g = try { hasAccess(ctx) } catch (_: Exception) { false }
        val was = granted
        granted = g
        if (g && pendingPick) { pendingPick = false; picking = true }
        if (g && !was) {
            Thread({
                try {
                    val d = dir(); d.mkdirs(); File(d, ".nomedia").createNewFile()       // keeps the big raw files out of the gallery (and the folder the user chose, if any)
                    // Move stems made before access was given into the folder.
                    File(ctx.filesDir, "prep").listFiles()?.forEach { p ->
                        val target = File(d, p.name)
                        if (p.isDirectory && !p.name.endsWith(".tmp") && !target.exists() && File(p, "meta.json").exists()) {
                            try { p.copyRecursively(target, overwrite = true); p.deleteRecursively() } catch (_: Exception) { target.deleteRecursively() }
                        }
                    }
                } catch (_: Exception) { }
                Prepared.rescan(ctx)
            }, "stem-folder").start()
        } else if (g) Prepared.rescan(ctx)
    }

    fun openSettings(ctx: Context) {
        try {
            val i = if (Build.VERSION.SDK_INT >= 30)
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName))
            else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            try { ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
        }
    }
}

@Composable
fun StemFolderHost() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { StemFolder.refresh(ctx) }
    LaunchedEffect(Unit) {
        StemFolder.refresh(ctx)
        if (!StemFolder.granted) StemFolder.asking = true
    }
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) StemFolder.refresh(ctx) }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    if (StemFolder.picking && StemFolder.granted) FolderBrowser()
    if (StemFolder.asking && !StemFolder.granted) {
        AlertDialog(
            onDismissRequest = { StemFolder.asking = false },
            containerColor = PanelBg,
            title = { Text("Keep your stems safe", fontSize = 16.sp, color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("MAXXIDO DJ will create a folder called ${StemFolder.NAME} on your phone and keep every prepared song there.", color = TextGray, fontSize = 12.sp)
                    Text("The folder stays when you update or reinstall the app, and any version of the app sees it, so there is nothing to export or import.", color = TextGray, fontSize = 12.sp)
                    Text(if (Build.VERSION.SDK_INT >= 30) "Android will ask you to allow \"All files access\" once. Switch it on for MAXXIDO DJ, then come back." else "Android will ask for storage access once.", color = TextGray, fontSize = 12.sp)
                }
            },
            confirmButton = {
                Column {
                    TextButton(onClick = {
                        StemFolder.asking = false
                        if (Build.VERSION.SDK_INT >= 30) StemFolder.openSettings(ctx) else perm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    }) { Text(if (StemFolder.customPath != null) "ALLOW ACCESS" else "CREATE THE FOLDER") }
                    TextButton(onClick = {
                        StemFolder.asking = false; StemFolder.pendingPick = true
                        if (Build.VERSION.SDK_INT >= 30) StemFolder.openSettings(ctx) else perm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    }) { Text("USE MY OWN FOLDER") }
                }
            },
            dismissButton = { TextButton(onClick = { StemFolder.asking = false }) { Text("NOT NOW") } }
        )
    }
}

/** Settings row: where the prepared stems are kept, with a button to pick any folder (phone or SD card). */
@Composable
fun StemFolderRow() {
    val ctx = LocalContext.current
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("STEMS FOLDER", color = Color.White, fontSize = 10.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        Text(
            (if (StemFolder.granted) StemFolder.dir().absolutePath else "Not set up yet (needs \"All files access\"): stems are kept inside the app for now") +
                (if (StemFolder.customPath == null) "   (default)" else "") + "   ·   ${Prepared.count()} prepared song(s) found",
            color = TextGray, fontSize = 10.sp
        )
        androidx.compose.foundation.layout.Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PadButton("CHOOSE FOLDER", Modifier.width(120.dp).height(28.dp), fontSize = 10) {
                if (StemFolder.granted) StemFolder.picking = true else { StemFolder.pendingPick = true; StemFolder.asking = true }
            }
            PadButton("DEFAULT", Modifier.width(90.dp).height(28.dp), enabled = StemFolder.customPath != null, fontSize = 10) { StemFolder.useDefault(ctx) }
            if (!StemFolder.granted) PadButton("ALLOW ACCESS", Modifier.width(110.dp).height(28.dp), fontSize = 10) { StemFolder.openSettings(ctx) }
        }
        Text("Prepared songs already in the old folder are moved to the new one. The folder stays when the app is updated or reinstalled.", color = TextGray, fontSize = 9.sp)
    }
}

/** A small folder browser inside the app, so choosing a folder never depends on the phone's file picker. */
@Composable
private fun FolderBrowser() {
    val ctx = LocalContext.current
    val root = remember { Environment.getExternalStorageDirectory() }
    var cur by remember { mutableStateOf(StemFolder.dir().let { if (it.isDirectory) it else (it.parentFile ?: root) }) }
    var naming by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var tick by remember { mutableStateOf(0) }
    val subs = remember(cur, tick) { cur.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") }?.sortedBy { it.name.lowercase() } ?: emptyList() }
    val packs = remember(cur, tick) { cur.listFiles()?.count { File(it, "meta.json").exists() } ?: 0 }
    val vols = remember { File("/storage").listFiles()?.filter { it.isDirectory && it.name != "emulated" && it.name != "self" && it.canRead() } ?: emptyList() }
    val link = Color(0xFF8AB4F8)
    AlertDialog(
        onDismissRequest = { StemFolder.picking = false },
        containerColor = PanelBg,
        title = { Text("Choose the stems folder", fontSize = 16.sp, color = Color.White) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(cur.absolutePath, color = Color.White, fontSize = 11.sp)
                Text(if (packs > 0) "$packs prepared song(s) found here" else "No prepared songs in this folder yet", color = TextGray, fontSize = 10.sp)
                androidx.compose.foundation.layout.Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    TextButton(enabled = cur.absolutePath != root.absolutePath, onClick = { cur = cur.parentFile?.takeIf { it.canRead() } ?: root }) { Text("UP", fontSize = 11.sp) }
                    TextButton(onClick = { cur = root }) { Text("PHONE", fontSize = 11.sp) }
                    vols.forEach { v -> TextButton(onClick = { cur = v }) { Text("SD ${v.name.take(9)}", fontSize = 11.sp) } }
                    TextButton(onClick = { naming = !naming }) { Text("NEW FOLDER", fontSize = 11.sp) }
                }
                if (naming) androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    androidx.compose.material3.OutlinedTextField(
                        value = name, onValueChange = { name = it.filter { c -> c != '/' } }, singleLine = true,
                        placeholder = { Text("Folder name", fontSize = 12.sp) }, modifier = Modifier.width(170.dp)
                    )
                    TextButton(enabled = name.isNotBlank(), onClick = {
                        val nf = File(cur, name.trim())
                        if (nf.mkdirs() || nf.isDirectory) { cur = nf; name = ""; naming = false } else Toast.makeText(ctx.applicationContext, "Couldn't create that folder here", Toast.LENGTH_SHORT).show()
                    }) { Text("CREATE") }
                }
                Column(Modifier.heightIn(max = 190.dp).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                    if (subs.isEmpty()) Text("No folders here", color = TextGray, fontSize = 11.sp)
                    subs.forEach { f ->
                        Text("\u25b8  ${f.name}", color = link, fontSize = 13.sp, maxLines = 1,
                            modifier = Modifier.fillMaxWidth().clickable { cur = f }.padding(vertical = 7.dp))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                StemFolder.picking = false
                StemFolder.useFolder(ctx, cur)
                Toast.makeText(ctx.applicationContext, "Stems folder: ${cur.absolutePath}", Toast.LENGTH_LONG).show()
            }) { Text("USE THIS FOLDER") }
        },
        dismissButton = { TextButton(onClick = { StemFolder.picking = false }) { Text("CANCEL") } }
    )
}
