package com.example.djapp

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Auto DJ for the PC version. Decks A and B take turns: one plays, the next queued track is loaded on the other,
 * and [fadeSec] before the end it starts (tempo matched when the BPMs are close) while the crossfader glides over.
 */
object AutoDj {
    val queue = mutableStateListOf<LibTrack>()
    var on by mutableStateOf(false)
    var fadeSec by mutableFloatStateOf(12f)
    var status by mutableStateOf("Off")

    private var cur = -1
    private var nextOn = false
    private var startPending = false
    private var fading = false
    private var fadeStart = 0L
    private var fadeLen = 12f
    private var forceMix = false
    private var lastTick = 0L

    private fun deck(i: Int) = if (i == 0) Decks.a else Decks.b

    fun start() { on = true; cur = -1; nextOn = false; startPending = false; fading = false; forceMix = false; status = "Starting..." }
    fun stop() { on = false; fading = false; startPending = false; status = "Off" }
    fun skip() { if (on && nextOn && !fading) forceMix = true }
    fun add(t: LibTrack) { queue.add(t) }
    // ---- saved playlists: ~/.maxido-dj/playlists/<name>.txt, one file path per line
    val playlists = mutableStateListOf<String>()
    private val plDir = java.io.File(System.getProperty("user.home"), ".maxido-dj/playlists").apply { mkdirs() }
    fun refreshPlaylists() {
        playlists.clear()
        (plDir.listFiles { f -> f.extension == "txt" } ?: emptyArray()).map { it.nameWithoutExtension }.sorted().forEach { playlists.add(it) }
    }
    fun savePlaylist() {
        if (queue.isEmpty()) return
        val name = "Playlist " + java.text.SimpleDateFormat("d MMM HH-mm", java.util.Locale.US).format(java.util.Date())
        try { java.io.File(plDir, "$name.txt").writeText(queue.joinToString("\n") { it.file.absolutePath }) } catch (_: Exception) {}
        refreshPlaylists()
    }
    fun loadPlaylist(name: String) {
        val f = java.io.File(plDir, "$name.txt")
        if (!f.isFile) return
        for (line in f.readLines()) {
            val file = java.io.File(line.trim())
            if (file.isFile) queue.add(Library.tracks.firstOrNull { it.file == file } ?: LibTrack(file))
        }
    }
    fun deletePlaylist(name: String) { java.io.File(plDir, "$name.txt").delete(); refreshPlaylists() }
    fun clearQueue() { queue.clear() }
    fun removeAt(i: Int) { if (i in queue.indices) queue.removeAt(i) }

    /** Called from the main loop (every 40 ms); does its work about 5 times a second. */
    fun tick() {
        if (!on) return
        val now = System.currentTimeMillis()
        if (now - lastTick < 200) return
        lastTick = now
        val a = Decks.a; val b = Decks.b
        if (a.loading || b.loading) return

        if (fading) {
            val out = deck(cur)
            val f = ((now - fadeStart) / (fadeLen * 1000f)).coerceIn(0f, 1f)
            Mix.applyCross(if (cur == 0) f else 1f - f)
            if (f >= 1f || !out.playing) {
                if (out.playing) out.togglePlay()
                fading = false
                cur = 1 - cur
                deck(cur).synced = false
                Mix.applyCross(if (cur == 0) 0f else 1f)
                status = "Playing ${deck(cur).title}"
            }
            return
        }

        if (cur < 0) {
            val going = listOf(a, b).firstOrNull { it.playing && it.dur > 0f }
            if (going != null) {
                cur = going.id; Mix.applyCross(if (cur == 0) 0f else 1f); nextOn = false
                status = "Playing ${going.title}"
            } else if (queue.isEmpty()) {
                status = "Add tracks with the Q button"
            } else {
                val t = queue.removeAt(0)
                a.load(t.file)
                cur = 0; startPending = true; Mix.applyCross(0f); status = "Loading ${t.title}..."
            }
            return
        }

        val d = deck(cur)
        if (startPending) {
            if (d.dur > 0f) { if (!d.playing) d.togglePlay(); startPending = false; status = "Playing ${d.title}" }
            return
        }
        if (d.dur <= 0f) { cur = -1; return }

        val atEnd = d.dur - d.pos < 0.6f
        val other = deck(1 - cur)

        if (!nextOn) {
            if (queue.isEmpty()) {
                status = "Playing ${d.title}, queue is empty"
                if (!d.playing && atEnd) stop()
                return
            }
            val t = queue.removeAt(0)
            other.load(t.file)
            nextOn = true
            status = "Next: ${t.title}"
            return
        }

        val remain = (d.dur - d.pos) / (1f + d.tempoPct)
        val due = d.playing && remain <= fadeSec + 0.2f
        if (forceMix || due || (!d.playing && atEnd)) {
            if (other.dur <= 0f) return
            if (d.bpm > 0f && other.bpm > 0f && abs(other.bpm / d.bpm - 1f) < 0.08f) other.syncTo(d)
            if (!other.playing) other.togglePlay()
            nextOn = false; forceMix = false
            fadeLen = if (d.playing) min(fadeSec, max(remain, 2f)) else 2f
            fadeStart = now; fading = true
            status = "Mixing into ${other.title}"
        }
    }
}
