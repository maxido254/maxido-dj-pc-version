package com.example.djapp

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Auto DJ: plays the queue by itself. One deck plays, the next track is loaded on the other deck, and when
 * the first one is [fadeSec] from its end the second starts (tempo matched when the BPMs are close) while
 * the crossfader glides across. Called every 200 ms from the main screen.
 */
object AutoDj {
    val queue = mutableStateListOf<Track>()
    var on by mutableStateOf(false)
    var fadeSec by mutableFloatStateOf(12f)
    var status by mutableStateOf("Off")

    private var cur = -1                 // deck that is playing for Auto DJ
    private var nextOn = false           // the next track has been loaded onto the other deck
    private var startPending = false     // first track is loading and must be started
    private var fading = false
    private var fadeStart = 0L
    private var fadeLen = 12f
    private var forceMix = false

    fun start() { on = true; cur = -1; nextOn = false; startPending = false; fading = false; forceMix = false; status = "Starting…" }
    fun stop() { on = false; fading = false; startPending = false; status = "Off" }
    /** Mix into the next track right now. */
    fun skip() { if (on && nextOn && !fading) forceMix = true }
    fun add(t: Track) { queue.add(t) }
    fun removeAt(i: Int) { if (i in queue.indices) queue.removeAt(i) }
    fun moveUp(i: Int) { if (i in 1 until queue.size) { val t = queue.removeAt(i); queue.add(i - 1, t) } }

    // ---- saved playlists (the queue can be saved and loaded again)
    val playlists = mutableStateListOf<String>()
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("maxxidodj", Context.MODE_PRIVATE)
    private fun readAll(ctx: Context): JSONObject = try { JSONObject(prefs(ctx).getString("playlists", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    fun refreshPlaylists(ctx: Context) {
        val o = readAll(ctx)
        playlists.clear()
        o.keys().asSequence().sorted().forEach { playlists.add(it) }
    }
    fun savePlaylist(ctx: Context): Boolean {
        if (queue.isEmpty()) return false
        val o = readAll(ctx)
        o.put("Playlist " + SimpleDateFormat("d MMM HH:mm", Locale.US).format(Date()), JSONArray(queue.map { it.uri.toString() }))
        prefs(ctx).edit().putString("playlists", o.toString()).apply()
        refreshPlaylists(ctx)
        return true
    }
    /** Adds the saved tracks that are still in the library to the end of the queue. */
    fun loadPlaylist(ctx: Context, name: String) {
        val a = readAll(ctx).optJSONArray(name) ?: return
        for (i in 0 until a.length()) {
            val u = a.optString(i)
            Library.tracks.firstOrNull { it.uri.toString() == u }?.let { queue.add(it) }
        }
    }
    fun deletePlaylist(ctx: Context, name: String) {
        val o = readAll(ctx)
        o.remove(name)
        prefs(ctx).edit().putString("playlists", o.toString()).apply()
        refreshPlaylists(ctx)
    }
    fun clearQueue() { queue.clear() }

    fun tick(ctx: Context, scope: CoroutineScope, decks: List<DeckState>, setCross: (Float) -> Unit) {
        if (!on) return
        if (decks.any { it.loading }) return

        if (fading) {
            val out = decks[cur]
            val f = ((System.currentTimeMillis() - fadeStart) / (fadeLen * 1000f)).coerceIn(0f, 1f)
            setCross(if (cur == 0) f else 1f - f)
            if (f >= 1f || !out.playing) {
                if (out.playing) out.togglePlay()
                fading = false
                cur = 1 - cur
                decks[cur].stopSync()
                setCross(if (cur == 0) 0f else 1f)
                status = "Playing ${decks[cur].curTitle}"
            }
            return
        }

        if (cur < 0) {
            val going = decks.firstOrNull { it.playing && it.loaded }
            if (going != null) {
                cur = going.id; setCross(if (cur == 0) 0f else 1f); nextOn = false
                status = "Playing ${going.curTitle}"
            } else if (queue.isEmpty()) {
                status = "Add tracks to the queue"
            } else {
                val t = queue.removeAt(0)
                decks[0].load(ctx, scope, t.uri)
                cur = 0; startPending = true; setCross(0f); status = "Loading ${t.title}…"
            }
            return
        }

        val d = decks[cur]
        if (startPending) {
            if (d.loaded) { if (!d.playing) d.togglePlay(); startPending = false; status = "Playing ${d.curTitle}" }
            return
        }
        if (!d.loaded) { cur = -1; return }

        val atEnd = (d.duration > 0 && d.duration - d.posSec < 0.6) || d.endedFlag
        val other = decks[1 - cur]

        if (!nextOn) {
            if (queue.isEmpty()) {
                status = "Playing ${d.curTitle} · queue is empty"
                if (!d.playing && atEnd) stop()
                return
            }
            val t = queue.removeAt(0)
            other.load(ctx, scope, t.uri)
            nextOn = true
            status = "Next: ${t.title}"
            return
        }

        val remain = ((d.duration - d.posSec) / (1f + d.tempoPct)).toFloat()
        val due = d.playing && remain <= fadeSec + 0.2f
        if (forceMix || due || (!d.playing && atEnd)) {
            if (!other.loaded) return
            if (d.bpm > 0f && other.bpm > 0f && abs(other.bpm / d.bpm - 1f) < 0.08f) other.syncTo(d)
            if (!other.playing) other.togglePlay()
            nextOn = false; forceMix = false
            fadeLen = if (d.playing) min(fadeSec, max(remain, 2f)) else 2f
            fadeStart = System.currentTimeMillis(); fading = true
            status = "Mixing into ${other.curTitle}"
        }
    }
}
