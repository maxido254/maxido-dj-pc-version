package com.example.djapp

import android.content.Context
import android.content.Intent
import android.os.Build
import android.net.Uri
import android.widget.Toast
import kotlin.math.abs
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.runtime.setValue
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class Panel(val title: String) {
    None(""), Stems("STEMS"), Loop("LOOP"), Mixer("MIXER"), Fx("EFFECTS"), Pads("HOT CUES"), Library("LIBRARY"), Sampler("SAMPLER"), Video("VIDEO MIXER"), Auto("AUTO DJ"), Settings("SETTINGS")
}

@Composable
fun PanelHost(
    panel: Panel, decks: List<DeckState>, onLoad: (Int, android.net.Uri) -> Unit, onBrowse: (Int) -> Unit,
    onPickVideo: (Int) -> Unit, onLoadPack: (Int, String) -> Unit, modifier: Modifier = Modifier.fillMaxSize(), onClose: () -> Unit
) {
    val full = panel == Panel.Library || panel == Panel.Settings   // full-screen pages: edge to edge, no card frame
    val frame = RoundedCornerShape(if (full) 0.dp else 16.dp)
    Column(
        modifier.padding(horizontal = if (full) 0.dp else 12.dp, vertical = if (full) 0.dp else 6.dp)
            .clip(frame).background((if (full) PanelBg else PanelBg.copy(alpha = 0.98f))).border(if (full) 0.dp else 1.dp, Cardline, frame)
            .pointerInput(Unit) {   // swallow touches so nothing leaks to the platters underneath
                awaitPointerEventScope { while (true) awaitPointerEvent().changes.forEach { it.consume() } }
            }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        // The sampler has no title bar (more room for the pads); the SMP button or Back closes it.
        if (panel != Panel.Sampler) Row(Modifier.fillMaxWidth().height(28.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(panel.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 2.sp)
            Spacer(Modifier.weight(1f))
            Box(Modifier.size(28.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                Text("✕", color = TextGray, fontSize = 15.sp)
            }
        }
        if (panel == Panel.Settings) {
            Box(Modifier.weight(1f).fillMaxWidth()) { SettingsPanel(decks) }
        } else if (panel == Panel.Library) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                LibraryPanel(onLoad, onBrowse, onLoadPack)
            }
        } else if (panel == Panel.Sampler) {
            Box(Modifier.weight(1f).fillMaxWidth()) { SamplerPanel() }
        } else if (panel == Panel.Auto) {
            Box(Modifier.weight(1f).fillMaxWidth()) { AutoDjPanel() }
        } else if (panel == Panel.Video) {
            Box(Modifier.weight(1f).fillMaxWidth()) { VideoPanel(onPickVideo, onBrowse) }
        } else {
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                for (d in decks) Column(Modifier.weight(1f).fillMaxHeight()) {
                    Text(
                        if (d.loaded) d.name else (if (d.id == 0) "DECK A" else "DECK B"),
                        color = d.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                    when (panel) {
                        Panel.Stems -> StemsPanel(d)
                        Panel.Loop -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) { LoopPanel(d) }
                        Panel.Mixer -> MixerPanel(d)
                        Panel.Fx -> FxPanel(d)
                        Panel.Pads -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) { PadsPanel(d) }
                        else -> {}
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Stems
/** Mixer order (engine index): VOCAL, MELODY, BASS, DRUMS. */
private val STEM_UI_ORDER = listOf(0, 3, 2, 1)

@Composable
private fun ColumnScope.StemsPanel(d: DeckState) {
    val ctx = LocalContext.current
    val ready = d.stemsReady
    val uri = d.curUri
    val queued = uri != null && PrepQueue.queue.any { it.uri == uri }
    val status = when {
        !d.loaded -> "Load a track first"
        ready -> (if (uri != null && Prepared.has(uri)) "Stems ready · prepared track" else "Stems ready") + " · " + when {
            d.stemEngine.startsWith("AI") -> "${d.stemEngine} ✓ (clean)"
            d.stemEngine == "older pack" -> "older pack: prepare again with AI"
            d.stemEngine.isEmpty() -> "engine unknown"
            else -> "${d.stemEngine}: NOT AI, bleed is normal. Use AI"
        }
        d.stemProg in 0f..1f -> "Preparing stems… ${(d.stemProg * 100).toInt()}%  (full mix keeps playing)"
        queued -> "Preparing in the background… ${if (PrepQueue.current == d.curTitle) "${(PrepQueue.progress * 100).toInt()}%" else "queued"}"
        !AppSettings.stemAuto -> "No stems yet: PREPARE it (best quality, in the background) or PLAY LIVE (uses the CPU now)"
        else -> "Stems unavailable"
    }
    Text(status, color = TextGray, fontSize = 10.sp, maxLines = 1)
    Row(Modifier.weight(1f).fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (i in STEM_UI_ORDER) Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
            PadButton(STEM_LABELS[i], Modifier.fillMaxWidth().height(28.dp), active = d.stemOn[i] && ready, color = d.accent, enabled = ready, fontSize = 9) { d.toggleStem(i) }
            VFader(d.stemLevel[i], d.accent, ready, Modifier.weight(1f).fillMaxWidth()) { d.setStemLevel(i, it) }
        }
    }
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        PadButton("ACAPELLA", Modifier.weight(1f).height(28.dp), enabled = ready, fontSize = 9) { d.soloStem(0) }
        PadButton("INSTRUMENTAL", Modifier.weight(1.3f).height(28.dp), enabled = ready, fontSize = 9) { d.muteOnly(0) }
        PadButton("BEATLESS", Modifier.weight(1f).height(28.dp), enabled = ready, fontSize = 9) { d.muteOnly(1) }
        PadButton("RESET", Modifier.weight(1f).height(28.dp), enabled = ready, fontSize = 9) { d.resetStems() }
    }
    if (d.loaded && !ready && uri != null) {
        val busy = d.stemProg in 0f..1f
        val liveName = when (AppSettings.stemQuality) { 0 -> "FAST"; 2 -> "PRO"; 3 -> if (AppSettings.ramOkForAi(ctx)) "AI" else "BETTER"; else -> "BETTER" }
        val scope = rememberCoroutineScope()
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PadButton(
                if (queued) "PREPARING…" else "PREPARE (best)", Modifier.weight(1f).height(28.dp),
                active = true, color = Accent, enabled = !queued && !busy, fontSize = 10
            ) { if (Pro.gate(Pro.STEMS)) PrepQueue.add(ctx, uri, d.curTitle.ifEmpty { d.name }, urgent = true) }
            PadButton(
                if (busy) "LIVE ${(d.stemProg * 100).toInt()}%" else "PLAY LIVE ($liveName)", Modifier.weight(1f).height(28.dp),
                enabled = !busy, fontSize = 10
            ) { if (Pro.gate(Pro.STEMS)) d.startLiveStems(ctx, scope) }
        }
    }
}

// ------------------------------------------------------------------ Loop
private val BEATS = listOf(0.25f to "1/4", 0.5f to "1/2", 1f to "1", 2f to "2", 4f to "4", 8f to "8", 16f to "16", 32f to "32", 64f to "64")

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LoopPanel(d: DeckState) {
    val hasBpm = d.bpm > 0f
    Text(
        when {
            !d.loaded -> "Load a track first"
            d.loopActive && d.loopBeats > 0 -> "LOOP ON · ${BEATS.firstOrNull { it.first == d.loopBeats }?.second ?: "%.2f".format(d.loopBeats)} beats"
            d.loopActive -> "LOOP ON · %.2f s".format(d.loopOut - d.loopIn)
            !hasBpm -> "Detecting BPM… (manual IN/OUT works now)"
            else -> "Tap a beat length to loop from the current position"
        },
        color = if (d.loopActive) d.accent else TextGray, fontSize = 10.sp, maxLines = 1
    )
    Spacer(Modifier.height(6.dp))
    val bctx = androidx.compose.ui.platform.LocalContext.current
    Text("BPM READING" + if (hasBpm) "  ·  %.2f".format(d.bpm) else "", color = TextGray, fontSize = 9.sp)
    Row(Modifier.fillMaxWidth().padding(top = 3.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        PadButton("½  HALF TIME", Modifier.weight(1f), enabled = d.loaded && hasBpm) { d.scaleBpm(bctx, 0.5) }
        PadButton("×2  DOUBLE TIME", Modifier.weight(1f), enabled = d.loaded && hasBpm) { d.scaleBpm(bctx, 2.0) }
    }
    Text("AUTO LOOP (beats)", color = TextGray, fontSize = 9.sp)
    Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        for ((b, label) in BEATS)
            PadButton(label, Modifier.weight(1f), active = d.loopActive && d.loopBeats == b, color = d.accent, enabled = d.loaded && hasBpm) { d.beatLoop(b) }
    }
    Spacer(Modifier.height(8.dp))
    Text("MANUAL", color = TextGray, fontSize = 9.sp)
    Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        PadButton("LOOP IN", Modifier.weight(1f), enabled = d.loaded) { d.loopInSet() }
        PadButton("LOOP OUT", Modifier.weight(1f), active = d.loopActive && d.loopBeats == 0f, color = d.accent, enabled = d.loaded) { d.loopOutSet() }
        PadButton(if (d.loopActive) "EXIT" else "RELOOP", Modifier.weight(1f), enabled = d.loaded && (d.loopActive || d.loopOut > d.loopIn)) {
            if (d.loopActive) d.exitLoop() else d.reloop()
        }
    }
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        PadButton("½  SHORTER", Modifier.weight(1f), enabled = d.loopActive) { d.halveLoop() }
        PadButton("×2  LONGER", Modifier.weight(1f), enabled = d.loopActive) { d.doubleLoop() }
    }
    Spacer(Modifier.height(10.dp))
    Text("QUANTIZE AND SLIP", color = TextGray, fontSize = 9.sp)
    Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        PadButton("QUANTIZE", Modifier.weight(1f), active = d.quantize, color = d.accent, enabled = d.loaded && hasBpm) { d.quantize = !d.quantize }
        PadButton("SLIP", Modifier.weight(1f), active = d.slip, color = d.accent, enabled = d.loaded) { d.slip = !d.slip }
    }
    Text(
        (if (d.quantize) "Cues and loops snap to the beat. " else "") + (if (d.slip) "Slip: the track keeps moving under a loop and you rejoin it." else ""),
        color = TextGray, fontSize = 9.sp, maxLines = 2, modifier = Modifier.padding(top = 2.dp)
    )
    Spacer(Modifier.height(8.dp))
    Text("BEAT JUMP", color = TextGray, fontSize = 9.sp)
    Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        for (b in listOf(1f, 2f, 4f, 8f, 16f, 32f))
            PadButton(if (b == b.toInt().toFloat()) "${b.toInt()}" else "$b", Modifier.weight(1f), active = d.jumpBeats == b, color = d.accent, enabled = d.loaded, fontSize = 11) { d.jumpBeats = b }
    }
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        PadButton("◀  BACK", Modifier.weight(1f), enabled = d.loaded && hasBpm) { d.beatJump(-d.jumpBeats) }
        PadButton("FORWARD  ▶", Modifier.weight(1f), enabled = d.loaded && hasBpm) { d.beatJump(d.jumpBeats) }
    }
    Spacer(Modifier.height(8.dp))
    Text("LOOP ROLL (hold)", color = TextGray, fontSize = 9.sp)
    Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        for ((b, label) in listOf(0.125f to "1/8", 0.25f to "1/4", 0.5f to "1/2", 1f to "1"))
            HoldButton(label, Modifier.weight(1f), active = d.rolling && d.loopBeats == b, color = d.accent, enabled = d.loaded && hasBpm && d.playing, onDown = { d.rollDown(b) }, onUp = { d.rollUp() })
    }
    Spacer(Modifier.height(8.dp))
    Text("SAVED LOOPS (tap: save the current loop or play it · long-press: clear)", color = TextGray, fontSize = 9.sp)
    for (row in 0..1) Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        for (col in 0..3) {
            val i = row * 4 + col
            val has = d.loopSlotIn[i] >= 0.0
            Box(
                Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(10.dp))
                    .background(if (has) PAD_COLORS8[i] else BtnBottom)
                    .combinedClickable(enabled = d.loaded, onClick = { d.loopSlot(i) }, onLongClick = { d.clearLoopSlot(i) }),
                contentAlignment = Alignment.Center
            ) { Text("L${i + 1}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (has) Color.Black else Color(0xFFE6E7EA)) }
        }
    }
    Spacer(Modifier.height(8.dp))
    Text("BEAT GRID EDITOR", color = TextGray, fontSize = 9.sp)
    Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        PadButton("◀ 10 ms", Modifier.weight(1f), enabled = d.loaded && hasBpm, fontSize = 11) { d.gridShift(bctx, -10) }
        PadButton("GRID = HERE", Modifier.weight(1.3f), enabled = d.loaded && hasBpm, fontSize = 11) { d.gridHere(bctx) }
        PadButton("10 ms ▶", Modifier.weight(1f), enabled = d.loaded && hasBpm, fontSize = 11) { d.gridShift(bctx, 10) }
    }
    Text("Play the track, pause on a kick, press GRID = HERE. The grid is saved with the track.", color = TextGray, fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
    Spacer(Modifier.height(8.dp))
    Text("TEMPO BEND (hold) AND TAP", color = TextGray, fontSize = 9.sp)
    Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        HoldButton("−  SLOWER", Modifier.weight(1f), active = d.bending < 0, color = d.accent, enabled = d.loaded && !d.syncOn, onDown = { d.bend(-1) }, onUp = { d.bend(0) })
        HoldButton("FASTER  +", Modifier.weight(1f), active = d.bending > 0, color = d.accent, enabled = d.loaded && !d.syncOn, onDown = { d.bend(1) }, onUp = { d.bend(0) })
    }
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        PadButton(if (d.tapCount in 1..3) "TAP BPM  (${d.tapCount}/4)" else "TAP BPM", Modifier.weight(1f), enabled = d.loaded) { d.tapBpm(bctx) }
    }
    Text("Tap four or more times on the beat to set the BPM and line up the beat grid.", color = TextGray, fontSize = 9.sp, modifier = Modifier.padding(top = 2.dp))
    Spacer(Modifier.height(12.dp))
}

// ------------------------------------------------------------------ Mixer
@Composable
private fun MixerPanel(d: DeckState) {
    FxSlider("VOLUME", d.vol, 0f..1f, d.accent, "${(d.vol * 100).toInt()}%") { d.vol = it; d.pushVolume() }
    FxSlider("FILTER", d.filter, -1f..1f, d.accent, filterText(d.filter), centered = true) { d.filter = it; d.pushFilter() }
    Text("◄ low-pass          high-pass ►", color = TextGray, fontSize = 9.sp, modifier = Modifier.padding(start = 56.dp))
    Spacer(Modifier.height(4.dp))
    for ((i, name) in listOf("BASS", "MID", "TREBLE").withIndex())
        FxSlider(name, eqToFrac(d.eq[i]), 0f..1f, d.accent, eqText(d.eq[i]), centered = true) { d.setEq(i, eqFromFrac(if (abs(it - 0.5f) < 0.03f) 0.5f else it)) }
    Spacer(Modifier.height(4.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        PadButton("FILTER OFF", Modifier.width(100.dp), enabled = d.filter != 0f) { d.filter = 0f; d.pushFilter() }
        PadButton("EQ FLAT", Modifier.width(90.dp), enabled = d.eq.any { it != 0f }) { for (b in 0..2) d.setEq(b, 0f) }
        PadButton("BASS KILL", Modifier.width(100.dp), active = d.eq[0] < -25f) { d.setEq(0, if (d.eq[0] < -25f) 0f else -26f) }
    }
}

private fun filterText(v: Float) = when {
    v < -0.02f -> "LP ${(-v * 100).toInt()}"
    v > 0.02f -> "HP ${(v * 100).toInt()}"
    else -> "OFF"
}

// ------------------------------------------------------------------ Effects
@Composable
private fun FxPanel(d: DeckState) {
    FxSlider("FILTER", d.filter, -1f..1f, d.accent, filterText(d.filter), centered = true) { d.filter = it; d.pushFilter() }
    FxSlider("REVERB", d.reverb, 0f..1f, d.accent, "${(d.reverb * 100).toInt()}%") { d.reverb = it; d.pushReverb() }
    FxSlider("ROOM", d.room, 0f..1f, d.accent, "${(d.room * 100).toInt()}%") { d.room = it; d.pushReverb() }
    FxSlider("PHASER", d.phaser, 0f..1f, d.accent, "${(d.phaser * 100).toInt()}%") { d.phaser = it; d.pushPhaser() }
    FxSlider("RATE", d.phRate, 0.1f..4f, d.accent, "%.1f Hz".format(d.phRate)) { d.phRate = it; d.pushPhaser() }
    Spacer(Modifier.height(4.dp))
    PadButton("ALL FX OFF", Modifier.width(110.dp), enabled = d.filter != 0f || d.reverb > 0f || d.phaser > 0f) { d.resetFx() }
}

// ------------------------------------------------------------------ Hot cues
private val PAD_COLORS = listOf(Color(0xFFFF5C7A), Color(0xFFFFB74D), Color(0xFF64B5F6), Color(0xFFBA68C8))
private val PAD_COLORS8 = listOf(Color(0xFFFF5C7A), Color(0xFFFFB74D), Color(0xFF64B5F6), Color(0xFFBA68C8), Color(0xFF4DD0A1), Color(0xFFFFEE58), Color(0xFFFF8A65), Color(0xFF90A4AE))

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PadsPanel(d: DeckState) {
    Text("Tap: set / jump · Long-press: clear", color = TextGray, fontSize = 10.sp)
    Spacer(Modifier.height(6.dp))
    for (row in 0..3) Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (col in 0..1) {
            val i = row * 2 + col
            val set = d.hotcues[i] >= 0
            Box(
                Modifier.weight(1f).height(46.dp).clip(RoundedCornerShape(8.dp))
                    .background(if (set) PAD_COLORS8[i] else Color(0xFF1A2640))
                    .combinedClickable(enabled = d.loaded, onClick = { d.hotcue(i) }, onLongClick = { d.clearHotcue(i) }),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (set) "${i + 1}  ·  %d:%02d".format(d.hotcues[i].toInt() / 60, d.hotcues[i].toInt() % 60) else "${i + 1}  SET",
                    color = if (set) Color.Black else TextGray, fontSize = 12.sp, fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ------------------------------------------------------------------ Settings
@Composable
private fun SettingsPanel(decks: List<DeckState>) {
    var page by remember { mutableStateOf(0) }
    val tabs = listOf("MIXER", "STEMS", "PERFORMANCE", "SAMPLER", "VIDEO", "DISPLAY", "LAYOUT", "CONTROLS", "STORE", "DEVELOPERS", "PRO")
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.width(136.dp).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            tabs.forEachIndexed { i, t ->
                val on = page == i
                Box(
                    Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(10.dp))
                        .background(if (on) Color(0xFF0F2540) else Color.Transparent).clickable { page = i }.padding(horizontal = 12.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        t, color = if (on) Accent else Color(0xFFC9D4E8), fontSize = 11.sp,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Medium, letterSpacing = 0.5.sp, maxLines = 1
                    )
                }
            }
        }
        Box(Modifier.width(1.dp).fillMaxHeight().background(Cardline))
        Box(Modifier.weight(1f).fillMaxHeight()) {
            when (page) {
                0 -> MixerSettings(decks)
                1 -> StemSettings()
                2 -> PerfSettings()
                3 -> SamplerSettings()
                4 -> VideoSettings()
                5 -> DisplaySettings()
                6 -> LayoutSettings()
                7 -> MapSettings()
                8 -> StorePage()
                9 -> DeveloperPage()
                else -> ProSettingsPage()
            }
        }
    }
}

internal const val WHATSAPP_NUMBER = "254115710055"   // +254 115 710 055

internal fun openWhatsApp(ctx: Context, message: String = "Hi, I'm using MAXIDO DJ") {
    try {
        val url = "https://wa.me/$WHATSAPP_NUMBER?text=" + Uri.encode(message)
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        Toast.makeText(ctx, "Could not open WhatsApp", Toast.LENGTH_SHORT).show()
    }
}

private fun openLink(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        Toast.makeText(ctx, "Could not open the link", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun LinkRow(label: String, value: String, url: String) {
    val ctx = LocalContext.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFF111B2E))
            .clickable { openLink(ctx, url) }.padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextGray, fontSize = 10.sp, modifier = Modifier.width(64.dp))
        Text(value, color = Color.White, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
private fun SocialRow(icon: Int, label: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFF111B2E))
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(painterResource(icon), contentDescription = label, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = TextGray, fontSize = 9.sp)
            Text(value, color = Color.White, fontSize = 12.sp, maxLines = 1)
        }
    }
}

@Composable
private fun DeveloperPage() {
    val ctx = LocalContext.current
    val version = remember { try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (_: Exception) { "" } }
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(
            Modifier.width(196.dp).fillMaxHeight().clip(RoundedCornerShape(16.dp)).background(Color(0xFF111B2E)).padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painterResource(R.drawable.developer), contentDescription = "Developer",
                contentScale = ContentScale.Crop, modifier = Modifier.size(84.dp).clip(CircleShape).border(2.dp, DeckA, CircleShape)
            )
            Spacer(Modifier.height(8.dp))
            Text("Maxido Ent.", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("MUSIC · TECH · CREATIVITY", color = TextGray, fontSize = 8.sp, letterSpacing = 1.sp, maxLines = 1)
            Spacer(Modifier.height(6.dp))
            Text("Built by music lovers, for music lovers.", color = Color(0xFFC9D4E8), fontSize = 10.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.weight(1f))
            PadButton("CHAT ON WHATSAPP", Modifier.fillMaxWidth(), active = true, color = Color(0xFF25D366), fontSize = 10) { openWhatsApp(ctx) }
            Spacer(Modifier.height(4.dp))
            Text("+254 115 710 055", color = TextGray, fontSize = 10.sp)
        }
        Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("CONTACT", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            SocialRow(R.drawable.ic_whatsapp, "WhatsApp", "(+254) 115 710 055") { openWhatsApp(ctx) }
            SocialRow(R.drawable.ic_instagram, "Instagram", "maxtech_058") { openLink(ctx, "https://www.instagram.com/maxtech_058") }
            SocialRow(R.drawable.ic_tiktok, "TikTok", "maxtech_058") { openLink(ctx, "https://www.tiktok.com/@maxtech_058") }
            LinkRow("Email", "maxidoent@gmail.com", "mailto:maxidoent@gmail.com")
            LinkRow("YouTube", "@MaxidoEnt", "https://www.youtube.com/@MaxidoEnt")
            LinkRow("Website", "www.maxidoent.co.ke", "https://www.maxidoent.co.ke")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PadButton("REPORT A PROBLEM", Modifier.weight(1f), fontSize = 10) {
                    openWhatsApp(ctx, "Bug report. MAXIDO DJ $version, ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}:\n")
                }
                PadButton("SUGGEST A FEATURE", Modifier.weight(1f), active = true, color = Accent, fontSize = 10) {
                    openWhatsApp(ctx, "Feature idea for MAXIDO DJ:\n")
                }
            }
            Text("ABOUT THIS BUILD", color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.padding(top = 4.dp))
            Text("Version $version  ·  Android 8.0 and newer", color = Color.White, fontSize = 11.sp)
            Text("Kotlin, Jetpack Compose, C++ audio engine (Oboe), ONNX Runtime with SCNet for offline stems.", color = TextGray, fontSize = 10.sp)
            Text("Works offline. The internet is used only by Settings > STORE, to download skins and sampler packs.", color = TextGray, fontSize = 10.sp)
            Text("© 2025 Maxido Ent. All rights reserved.", color = TextGray, fontSize = 9.sp)
        }
    }
}

@Composable
private fun ToggleRow(label: String, desc: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF111B2E)).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(desc, color = TextGray, fontSize = 10.sp)
        }
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier.width(46.dp).height(26.dp).clip(RoundedCornerShape(13.dp))
                .background(if (on) Accent else Color(0xFF26344F)).clickable { onChange(!on) }.padding(3.dp),
            contentAlignment = if (on) Alignment.CenterEnd else Alignment.CenterStart
        ) { Box(Modifier.size(20.dp).clip(CircleShape).background(if (on) Color(0xFF06101C) else TextGray)) }
    }
}

@Composable
private fun SettingsPage(content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)

@Composable
private fun Choice(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        labels.forEachIndexed { i, l -> PadButton(l, Modifier.width(92.dp), active = selected == i) { onSelect(i) } }
    }
}

@Composable
private fun MixerSettings(decks: List<DeckState>) = SettingsPage {
    Text("TEMPO RANGE", color = TextGray, fontSize = 10.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for ((r, label) in listOf(0.08f to "±8%", 0.16f to "±16%", 0.5f to "±50%"))
            PadButton(label, Modifier.width(80.dp), active = AppSettings.tempoRange == r) {
                AppSettings.tempoRange = r; decks.forEach { it.applyTempo(it.tempoPct) }; AppSettings.save()
            }
    }
    Text("CROSSFADER CURVE", color = TextGray, fontSize = 10.sp)
    Choice(listOf("SMOOTH", "SHARP (CUT)", "LINEAR"), AppSettings.crossCurve) {
        AppSettings.crossCurve = it; NativeEngine.setCrossfaderCurve(it); AppSettings.save()
    }
    Text(
        when (AppSettings.crossCurve) {
            1 -> "Sharp: both decks stay at full volume, then cut quickly at the ends. Made for scratching and fast cuts."
            2 -> "Linear: straight volume ramp, dips slightly in the middle."
            else -> "Smooth: constant-power blend, no volume dip in the middle. Best for long mixes."
        }, color = TextGray, fontSize = 10.sp
    )
    FxSlider("MASTER", AppSettings.masterGain, 0.25f..1.25f, Accent, "${(AppSettings.masterGain * 100).toInt()}%") {
        AppSettings.masterGain = it; NativeEngine.setMasterGain(it); AppSettings.save()
    }
    FxSlider("BASS AMP", AppSettings.bassAmp, 0f..1f, Accent, "${(AppSettings.bassAmp * 100).toInt()}%") {
        AppSettings.bassAmp = it; NativeEngine.setBassAmp(it); AppSettings.save()
    }
    Text(
        "Adds punch you can hear on any speaker (phone, laptop, PA) and removes inaudible sub-24 Hz rumble so the bass is tighter and louder before the limiter. 0% = off.",
        color = TextGray, fontSize = 10.sp
    )
}

@Composable
private fun StemSettings() {
    val ctx = LocalContext.current
    var usage by remember { mutableStateOf(0L) }
    var refresh by remember { mutableStateOf(0) }
    LaunchedEffect(refresh) { usage = withContext(Dispatchers.IO) { Prepared.usageBytes(ctx) } }
    SettingsPage {
        Text("PREPARED TRACKS  (recommended on budget phones)", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(
            "Prepare a track ahead of time (Library > P, or the STEMS panel). The phone then does all the heavy work once, in the background, " +
                "and saves vocal / melody / bass / drums, the beat grid and the key. Loading a prepared track is instant and uses almost no CPU while you play.",
            color = TextGray, fontSize = 10.sp
        )
        val modelOk = remember {
            java.io.File(ctx.filesDir, "scnet.int8.onnx").exists() || java.io.File(ctx.filesDir, "scnet-large.int8.onnx").exists() ||
                try { ctx.assets.list("")?.contains("scnet.int8.onnx") == true } catch (_: Exception) { false }
        }
        Text(
            if (modelOk) "AI model: included in this app ✓"
            else "AI model: NOT in this build ✗  AI cannot run, so PRO (with bleed) is used. Rebuild the app with internet access so the model downloads.",
            color = if (modelOk) Accent else Color(0xFFFFB4A9), fontSize = 10.sp, fontWeight = FontWeight.Bold
        )
        Text("PREPARE QUALITY", color = TextGray, fontSize = 10.sp)
        Choice(listOf("BETTER", "PRO", "AI", "AI MAX"), AppSettings.prepQuality) { AppSettings.prepQuality = it; AppSettings.save() }
        Text(
            when (AppSettings.prepQuality) {
                3 -> "AI MAX: slow but best. The neural network runs 5 times on the song with the start moved each time, plus double overlap, and the results are averaged. This removes most leftovers and joining artefacts. It works on every phone: weak phones automatically retry with a lighter, slower setting instead of falling back to PRO. About 7x slower than AI (a song can take hours on a weak phone, which is why AI is the default) and needs free storage while it works. Prepare once, overnight on charge, play forever."
                2 -> "AI: neural-network separation (SCNet), the cleanest result. It uses a compact SCNet model (small 13 MB on budget phones, large 45 MB on 6 GB+ phones) and runs in a separate, memory-light process, so it works on weak phones too (slower on a budget phone: expect some minutes per song). If a phone really cannot run it, PRO is used for that track."
                1 -> "PRO: finest classical separation (4096 FFT, 4-way masks). Some bleed is normal: it is signal processing, not a neural network."
                else -> "BETTER: faster to prepare, more bleed."
            },
            color = TextGray, fontSize = 10.sp
        )
        Text("WHILE A DECK PLAYS", color = TextGray, fontSize = 10.sp)
        Choice(listOf("PAUSE PREP", "KEEP GOING"), if (AppSettings.prepPause) 0 else 1) { AppSettings.prepPause = it == 0; AppSettings.save() }
        ToggleRow("Auto-prepare loaded tracks", "Like VirtualDJ on a weak phone: load any song and play it at once. If it is not prepared yet it is prepared in the background (it goes first in the queue) and its stems switch on by themselves when ready. Prepared tracks give the same live stems as on a strong phone.", AppSettings.autoPrep) { AppSettings.autoPrep = it; AppSettings.save() }
        Text("STORAGE  ·  prepared tracks use ${usage / 1_048_576} MB  (about 170 MB per 4-minute song)", color = TextGray, fontSize = 10.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((mb, label) in listOf(1000 to "1 GB", 3000 to "3 GB", 8000 to "8 GB"))
                PadButton("CAP $label", Modifier.width(80.dp), active = AppSettings.prepCapMb == mb) { AppSettings.prepCapMb = mb; AppSettings.save() }
            PadButton("DELETE ALL", Modifier.width(92.dp)) { Prepared.deleteAll(ctx); refresh++ }
        }
        Text("When the cap is reached the least recently used prepared tracks are deleted first.", color = TextGray, fontSize = 10.sp)


        Text("LIVE STEMS  (tracks that are not prepared)", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        ToggleRow(
            "Make stems on load",
            if (AppSettings.stemAuto) "Stems are made in the background right after you load a track. This uses the CPU while you play."
            else "Off: no stem work while you play. Only prepared tracks get stems. Best for smooth playback on budget phones.",
            AppSettings.stemAuto
        ) { AppSettings.stemAuto = it; AppSettings.save() }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("FAST", "BETTER", "PRO", "AI").forEachIndexed { i, l ->
                PadButton(l, Modifier.width(76.dp), active = AppSettings.stemQuality == i, enabled = AppSettings.stemAuto) { AppSettings.stemQuality = i; AppSettings.save() }
            }
        }
        Text(
            if (AppSettings.stemQuality == 3 && !AppSettings.ramOkForAi(ctx)) "AI live needs about 6 GB of RAM. This phone has less, so BETTER is used instead. Use PREPARED tracks here for clean stems."
            else when (AppSettings.stemQuality) {
                3 -> "AI: neural network (SCNet), fully offline, runs in a separate process so it can't crash the app. Automatic on strong phones; falls back to BETTER if it can't run."
                2 -> "PRO live: very slow on a budget phone. Prefer preparing the track ahead of time."
                1 -> "Better: STFT percussive/harmonic + centre-channel split."
                else -> "Fast: simple filters. Ready in seconds, rougher separation."
            },
            color = TextGray, fontSize = 10.sp
        )
    }
}

@Composable
private fun PerfSettings() {
    val ctx = LocalContext.current
    val low = remember { AppSettings.lowEnd(ctx) }
    SettingsPage {
        Text(if (low) "This phone is detected as a budget device: gentle defaults are already applied." else "Performance options (this phone has plenty of RAM).", color = TextGray, fontSize = 10.sp)
        Text("AUDIO BUFFER", color = TextGray, fontSize = 10.sp)
        Choice(listOf("FAST", "BALANCED", "SAFE"), AppSettings.audioMode) {
            AppSettings.audioMode = it; AppSettings.save()
            if (!NativeEngine.setAudioMode(it)) Toast.makeText(ctx, "Could not restart audio", Toast.LENGTH_SHORT).show()
        }
        Text(
            when (AppSettings.audioMode) {
                0 -> "Fast: lowest delay. Can crackle on weak phones."
                1 -> "Balanced: a little more delay, much safer on budget chips."
                else -> "Safe: biggest buffer. Use this if you still hear crackling or dropouts."
            }, color = TextGray, fontSize = 10.sp
        )
        Text("LOOP OUT EFFECT", color = TextGray, fontSize = 10.sp)
        Text("The LOOP OUT button repeats the last LENGTH of audio COUNT times, then fades out and stops the deck.", color = TextGray, fontSize = 10.sp)
        Text("LENGTH (beats)", color = TextGray, fontSize = 10.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (b in listOf(1f, 2f, 4f, 8f, 16f, 32f))
                PadButton("${b.toInt()}", Modifier.width(56.dp), active = AppSettings.loopOutBeats == b) { AppSettings.loopOutBeats = b; AppSettings.save() }
        }
        Text("COUNT (repeats)", color = TextGray, fontSize = 10.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (c in listOf(1, 2, 4, 8, 16))
                PadButton("$c", Modifier.width(56.dp), active = AppSettings.loopOutCount == c) { AppSettings.loopOutCount = c; AppSettings.save() }
        }
        Text("MODE (how it ends)", color = TextGray, fontSize = 10.sp)
        Choice(listOf("VOLUME", "FILTER", "CUT"), AppSettings.loopOutMode) { AppSettings.loopOutMode = it; AppSettings.save() }
        Text(
            "${AppSettings.loopOutBeats.toInt()} beats x ${AppSettings.loopOutCount} = ${(AppSettings.loopOutBeats * AppSettings.loopOutCount).toInt()} beats, then " +
                when (AppSettings.loopOutMode) { 0 -> "the volume fades out."; 1 -> "a low-pass filter closes."; else -> "it stops straight away." } +
                " Press LOOP OUT again to cancel.", color = TextGray, fontSize = 10.sp
        )
        ToggleRow("Key lock by default", "Keeps the pitch when you change the tempo. Each deck also has its own KEYLOCK button.", AppSettings.keylock) {
            AppSettings.keylock = it; AppSettings.save()
        }
    }
}

@Composable
private fun SamplerSettings() = SettingsPage {
    Text("PAD MODE", color = TextGray, fontSize = 10.sp)
    Choice(listOf("ONE-SHOT", "HOLD", "LOOP"), AppSettings.padMode) { AppSettings.padMode = it; AppSettings.save() }
    Text(
        when (AppSettings.padMode) {
            1 -> "Hold: the sample plays only while you keep the pad pressed."
            2 -> "Loop: tap to start a looping sample, tap again to stop."
            else -> "One-shot: tap to play the sample once. Tap again to restart it."
        }, color = TextGray, fontSize = 10.sp
    )
    FxSlider("VOLUME", AppSettings.sampleVol, 0f..1f, Accent, "${(AppSettings.sampleVol * 100).toInt()}%") {
        AppSettings.sampleVol = it; NativeEngine.setSampleVolume(it); AppSettings.save()
    }
    Text("The SAMPLER plays the built-in free samples (2 banks of 8) or a sampler pack you downloaded. Get more packs in Settings > STORE.", color = TextGray, fontSize = 10.sp)
    PadButton("STOP ALL SAMPLES", Modifier.width(150.dp)) { Sampler.stopAll() }
}

@Composable
private fun VideoSettings() = SettingsPage {
    Text("TRANSITION", color = TextGray, fontSize = 10.sp)
    Choice(listOf("BLEND", "DIP TO BLACK", "CUT"), AppSettings.videoBlend) { AppSettings.videoBlend = it; AppSettings.save() }
    Text("VIDEO FADER SOURCE", color = TextGray, fontSize = 10.sp)
    Choice(listOf("CROSSFADER", "MANUAL"), if (AppSettings.videoFollowCross) 0 else 1) {
        if (it == 1) VideoMixer.manualCross = VideoMixer.audioCross
        AppSettings.videoFollowCross = it == 0; AppSettings.save()
    }
    Text("VIDEO SPEED", color = TextGray, fontSize = 10.sp)
    Choice(listOf("FOLLOW TEMPO", "FIXED 1x"), if (AppSettings.videoFollowTempo) 0 else 1) { AppSettings.videoFollowTempo = it == 0; AppSettings.save() }
    FxSlider("BRIGHT", AppSettings.videoBright, 0f..1f, Accent, "${(AppSettings.videoBright * 100).toInt()}%") { AppSettings.videoBright = it; AppSettings.save() }
    Text("Load a video file as a track (FILE A / FILE B) and its picture stays locked to the deck. Extra looping clips go on the VIDEO panel.", color = TextGray, fontSize = 10.sp)
}

@Composable
private fun DisplaySettings() {
    val ctx = LocalContext.current
    SettingsPage {
        ToggleRow("Stay awake", "Keeps the screen on while MAXIDO DJ is open, which you want during a set.", AppSettings.keepAwake) {
            AppSettings.keepAwake = it; AppSettings.save()
            var c = ctx
            while (c is android.content.ContextWrapper && c !is android.app.Activity) c = c.baseContext
            (c as? android.app.Activity)?.window?.let { w ->
                if (AppSettings.keepAwake) w.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }
}

// ------------------------------------------------------------------ Controls: custom key / MIDI mappings
@Composable
private fun MapSettings() {
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { Mappings.learning = null } }
    SettingsPage {
        Text(
            "Map a keyboard, gamepad or USB MIDI controller (OTG cable). Tap LEARN on a row, then press the key / pad, or turn the knob.",
            color = TextGray, fontSize = 10.sp
        )
        Text(
            "MIDI devices connected: ${Mappings.midiDevices}     Last MIDI message: ${if (Mappings.lastMidi.isEmpty()) "none yet" else Mappings.lastMidi}",
            color = Accent, fontSize = 10.sp
        )
        Text(
            "Knob rows take a MIDI knob or fader (CC). Other rows take a key, a pad (note) or a MIDI button. Back, Home and the volume keys are never taken.",
            color = TextGray, fontSize = 10.sp
        )
        var group = ""
        for (a in Mappings.actions) {
            if (a.group != group) {
                group = a.group
                Text(group, color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
            }
            val on = Mappings.learning == a.id
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(a.label, color = Color(0xFFE6E7EA), fontSize = 11.sp, maxLines = 1, modifier = Modifier.weight(1f))
                Text(
                    if (on) (if (a.knob) "turn a MIDI knob..." else "press a key / pad...") else Mappings.describe(a.id),
                    color = if (on) Accent else TextGray, fontSize = 10.sp, maxLines = 1, modifier = Modifier.width(170.dp)
                )
                PadButton(if (on) "CANCEL" else "LEARN", Modifier.width(78.dp), active = on, fontSize = 10) { Mappings.learning = if (on) null else a.id }
                PadButton("CLEAR", Modifier.width(60.dp), fontSize = 10) { Mappings.clear(a.id) }
            }
        }
        PadButton("CLEAR ALL MAPPINGS", Modifier.width(170.dp).padding(top = 8.dp), fontSize = 10) { Mappings.clearAll() }
    }
}

// ------------------------------------------------------------------ Layout: show / hide and resize
@Composable
private fun LayoutSettings() = SettingsPage {
    Text("Choose what is on the main screen and how big it is. Changes show straight away and are saved on this phone.", color = TextGray, fontSize = 10.sp)
    Text("SHOW OR HIDE", color = TextGray, fontSize = 10.sp)
    ToggleRow("Deck info", "Big BPM, key, pitch and time readout beside each platter.", LayoutPrefs.showInfo) { LayoutPrefs.showInfo = it; LayoutPrefs.save() }
    ToggleRow("Hot-cue pads", "Four colored pads under each platter: tap to set or jump, long-press to clear.", LayoutPrefs.showPads) { LayoutPrefs.showPads = it; LayoutPrefs.save() }
    ToggleRow("Channel strips", "HI / MID / LOW and volume faders for both decks in the centre.", LayoutPrefs.showMixer) { LayoutPrefs.showMixer = it; LayoutPrefs.save() }
    ToggleRow("Waveform overview", "The thin full-track strip under each scrolling waveform.", LayoutPrefs.showOverview) { LayoutPrefs.showOverview = it; LayoutPrefs.save() }
    ToggleRow("Filter fader", "The filter fader on the left of each platter.", LayoutPrefs.showFilter) { LayoutPrefs.showFilter = it; LayoutPrefs.save() }
    ToggleRow("Bass fader", "The bass fader next to the filter fader.", LayoutPrefs.showBass) { LayoutPrefs.showBass = it; LayoutPrefs.save() }
    ToggleRow("Stem buttons", "VOCAL / MELODY / BASS / INSTR under each platter.", LayoutPrefs.showStems) { LayoutPrefs.showStems = it; LayoutPrefs.save() }
    ToggleRow("Stem swap pads", "Vocal pads under the stem buttons (needs the stem buttons on).", LayoutPrefs.showSwap) { LayoutPrefs.showSwap = it; LayoutPrefs.save() }
    ToggleRow("Performance effects", "LOOP OUT / ECHO OUT / BACKSPIN on the right of each platter.", LayoutPrefs.showFxCol) { LayoutPrefs.showFxCol = it; LayoutPrefs.save() }
    ToggleRow("Level meter", "The master level bar in the centre.", LayoutPrefs.showMeter) { LayoutPrefs.showMeter = it; LayoutPrefs.save() }
    ToggleRow("SYNC buttons", "The SYNC buttons next to CUE and PLAY.", LayoutPrefs.showSync) { LayoutPrefs.showSync = it; LayoutPrefs.save() }
    ToggleRow("Waveforms at the very top", "Small waveforms above everything else. Drag a waveform to scratch; touch the thin strip under it to jump to any point of the song.", LayoutPrefs.wavesOnTop) { LayoutPrefs.wavesOnTop = it; LayoutPrefs.save() }
    Text("SIZES", color = TextGray, fontSize = 10.sp)
    if (LayoutPrefs.wavesOnTop) FxSlider("TOP WAVES", LayoutPrefs.topWavePct, 14f..45f, Accent, "${LayoutPrefs.topWavePct.toInt()}%") { LayoutPrefs.topWavePct = it; LayoutPrefs.save() }
    else FxSlider("WAVES", LayoutPrefs.wavePct, 28f..62f, Accent, "${LayoutPrefs.wavePct.toInt()}%") { LayoutPrefs.wavePct = it; LayoutPrefs.save() }
    FxSlider("PLATTER", LayoutPrefs.deckPct, 26f..37f, Accent, "${LayoutPrefs.deckPct.toInt()}") { LayoutPrefs.deckPct = it; LayoutPrefs.save() }
    FxSlider("BOTTOM", LayoutPrefs.bottomPct, 8f..26f, Accent, "${LayoutPrefs.bottomPct.toInt()}") { LayoutPrefs.bottomPct = it; LayoutPrefs.save() }
    FxSlider("BUTTONS", LayoutPrefs.iconDp, 26f..60f, Accent, "${LayoutPrefs.iconDp.toInt()} dp") { LayoutPrefs.iconDp = it; LayoutPrefs.save() }
    FxSlider("PADS", LayoutPrefs.padDp, 24f..64f, Accent, "${LayoutPrefs.padDp.toInt()} dp") { LayoutPrefs.padDp = it; LayoutPrefs.save() }
    FxSlider("FADERS", LayoutPrefs.faderDp, 26f..64f, Accent, "${LayoutPrefs.faderDp.toInt()} dp") { LayoutPrefs.faderDp = it; LayoutPrefs.save() }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        PadButton("CLEAN SCREEN", Modifier.width(130.dp), fontSize = 10) { LayoutPrefs.minimal() }
        PadButton("RESET LAYOUT", Modifier.width(130.dp), fontSize = 10) { LayoutPrefs.reset() }
    }
    Text("Settings, LIB, FX, SMP, VID, CUE and PLAY are always shown, so you can always get back here. 'Clean screen' is good for screen recordings.", color = TextGray, fontSize = 10.sp)
}
